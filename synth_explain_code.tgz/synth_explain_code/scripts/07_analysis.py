"""Stage 07: RQ1-RQ3 tables and the generator-dependence analyses (Spec 9, 16.7)."""
import json

import pandas as pd

from _cli import parser
from src.analysis import (displaced_overlap, mixed_model, person_predictors, rq1_table, rq2_table, rq3_models,
                          subgroup_gaps, variance_decomposition, worked_example)
from src.common import columns_info, load_config, load_meta, out_dir, setup_logging, write_json
from src.common import read_json as _read_json
from src.metrics import decisions, explanations_path, load_explanations

p = parser("analysis")
p.add_argument("--rule", default=None)
args = p.parse_args()
cfg = load_config(args.config)
log = setup_logging(cfg, "07_analysis")
rule = args.rule or cfg["decision"]["main_rule"]
rc = cfg["reasons"]
METRIC, OVERLAP = f"jaccard_k{rc['k_main']}", f"overlap_k{rc['k_main']}"
tdir = out_dir(cfg, "tables", args.variant)
rq2_all = []
for ds in args.dataset or cfg["datasets"]:
    cols, meta = columns_info(cfg, ds), load_meta(cfg, ds)
    mdir = out_dir(cfg, "metrics", ds, args.variant)
    pairs = pd.read_parquet(out_dir(cfg, "pairs") / f"{ds}_{args.variant}_{rule}.parquet")
    person = pd.read_parquet(out_dir(cfg, "person") / f"{ds}_{args.variant}_{rule}.parquet")
    disp = pd.read_parquet(mdir / f"displaced_{rule}_BR.parquet")
    disp_seed = pd.read_parquet(mdir / f"displaced_{rule}_RR.parquet")
    disp_by_seed = pd.read_parquet(mdir / f"displaced_by_seed_{rule}.parquet")
    flips = pd.read_parquet(mdir / f"flips_{rule}.parquet")
    quality = pd.read_parquet(mdir / "quality.parquet")
    cov = pd.read_parquet(mdir / "coverage.parquet") if (mdir / "coverage.parquet").exists() else None
    rpath = out_dir(cfg, "recourse", ds, args.variant) / f"summary_{rule}.parquet"
    recourse = pd.read_parquet(rpath) if rpath.exists() else None
    expl = load_explanations(cfg, ds, args.variant)

    # RQ1
    t1 = rq1_table(person, disp, disp_seed, flips, quality, recourse, METRIC, OVERLAP)
    t1.insert(0, "dataset", ds)
    t1.to_csv(tdir / f"table2_main_{ds}_{rule}.csv", index=False)
    log.info("RQ1 %s:\n%s", ds, t1.round(3).to_string())
    for m in [METRIC, "jaccard_k1", "jaccard_k4", "jaccard_family", "rbo", "top1"]:
        eff, contrasts = mixed_model(pairs, m)
        eff.to_csv(tdir / f"mixed_{ds}_{rule}_{m}.csv", index=False)
        contrasts.to_csv(tdir / f"contrasts_{ds}_{rule}_{m}.csv", index=False)
    log.info("mixed model (%s) fixed effects vs BR:\n%s", METRIC, pd.read_csv(tdir / f"mixed_{ds}_{rule}_{METRIC}.csv").round(4).to_string())

    # RQ2
    t2, rho, info = rq2_table(quality, disp_by_seed, cfg)
    t2.insert(0, "dataset", ds)
    rq2_all.append(t2)
    rho.to_csv(tdir / f"rq2_spearman_{ds}_{rule}.csv", index=False)
    write_json(info, tdir / f"rq2_hidden_failures_{ds}_{rule}.json")
    log.info("RQ2 %s: %s\nhidden failures: %d of %d", ds, rho.round(3).to_dict("records"), info["n_hidden_failures"], info["n_conditions"])

    # RQ3
    preds = person_predictors(cfg, ds, cols, meta, expl, cov)
    preds.to_parquet(out_dir(cfg, "person") / f"{ds}_{args.variant}_predictors.parquet", index=False)
    r3 = rq3_models(disp, person, preds, METRIC)
    r3["main"].to_csv(tdir / f"table3_h3_{ds}_{rule}.csv", index=False)
    r3["interactions"].to_csv(tdir / f"table3_h3_interactions_{ds}_{rule}.csv", index=False)
    r3["spearman_by_generator"].to_csv(tdir / f"h3_spearman_by_generator_{ds}_{rule}.csv", index=False)
    r3["long"].to_parquet(out_dir(cfg, "person") / f"{ds}_{args.variant}_{rule}_h3long.parquet", index=False)
    sg = subgroup_gaps(disp, preds, cfg)
    sg.to_csv(tdir / f"subgroups_{ds}_{rule}.csv", index=False)
    log.info("RQ3 %s main OLS (R2=%.3f):\n%s", ds, r3["r2_main"], r3["main"].round(4).to_string())

    # generator dependence (16.7)
    ov = displaced_overlap(disp)
    ov.to_csv(tdir / f"table5_overlap_{ds}_{rule}.csv")
    vd = variance_decomposition(person, METRIC)
    write_json(vd, tdir / f"table5_variance_{ds}_{rule}.json")
    log.info("variance decomposition %s: %s", ds, {k: (round(v, 3) if isinstance(v, float) else v) for k, v in vd.items() if k != "generator_means"})
    thr = _read_json(explanations_path(cfg, ds, args.variant).parent / "thresholds.json")
    adv = decisions(expl["prob"], list(expl["model_ids"]), thr, rule)
    write_json(worked_example(expl, disp, rc["k_main"], adv), tdir / f"worked_example_{ds}_{rule}.json")

    # RQ2 unit also needs the other robustness tables: write everything compact
pd.concat(rq2_all, ignore_index=True).to_csv(tdir / f"rq2_points_{rule}.csv", index=False)
# pooled Spearman across datasets (the 30-point version)
from scipy.stats import spearmanr
pool = pd.concat(rq2_all, ignore_index=True)
rows = []
for c in ["tstr_auc_gap", "global_shap_distance", "sdmetrics_score", "detection_auc", "pgi", "class_ratio_gap"]:
    if c not in pool:
        continue
    s = pool[[c, "displaced_share"]].dropna()
    rho_, p_ = spearmanr(s[c], s.displaced_share) if len(s) > 2 else (float("nan"), float("nan"))
    rows.append({"check": c, "spearman_rho": rho_, "p": p_, "n": len(s)})
pd.DataFrame(rows).to_csv(tdir / f"rq2_spearman_pooled_{rule}.csv", index=False)
log.info("RQ2 pooled: %s", pd.DataFrame(rows).round(3).to_dict("records"))
log.info("stage 07 done")
