"""Stage 04: probabilities, thresholds, SHAP values and reason codes for every model on the audit set (Spec 7.1)."""
import numpy as np
import pandas as pd
from joblib import Parallel, delayed

from _cli import parser
from src.common import columns_info, load_config, load_meta, load_split, out_dir, setup_logging, write_json
from src.explain import background, merge_indicators, reason_table, shap_values, thresholds
from src.metrics import decisions, explanations_path, model_performance
from src.models import load_model, load_registry, predict_proba
from src.sanity import check_auc_range, check_reasons_are_inputs, check_shap_additivity, report

p = parser("explain")
p.add_argument("--n-jobs", type=int, default=4)
args = p.parse_args()
cfg = load_config(args.config)
log = setup_logging(cfg, "04_explain")


def one(path, X, bg, cols):
    model = load_model(path)
    prob = predict_proba(model, X)
    vals, ev = shap_values(model, X, bg, cols, cfg)
    return prob, vals, ev


for ds in args.dataset or cfg["datasets"]:
    out = explanations_path(cfg, ds, args.variant)
    if out.exists() and not args.force:
        log.info("cached %s", out)
        continue
    cols, meta = columns_info(cfg, ds), load_meta(cfg, ds)
    reg = load_registry(cfg, ds, args.variant)
    audit = load_split(cfg, ds, "audit")
    X = audit[cols["inputs"]]
    bg = background(cfg, ds, cols)
    res = Parallel(n_jobs=args.n_jobs, verbose=5)(delayed(one)(r.path, X, bg, cols) for _, r in reg.iterrows())
    prob = np.stack([r[0] for r in res])
    vals_in = np.stack([r[1] for r in res])
    expected = np.array([r[2] for r in res])
    model_ids = reg.model_id.tolist()
    # sanity 5: additivity on a random sample of (model, row)
    rng = np.random.default_rng(0)
    checks = []
    for mi in rng.choice(len(model_ids), size=min(5, len(model_ids)), replace=False):
        model = load_model(reg.path.iloc[mi])
        idx = rng.choice(len(X), size=min(50, len(X)), replace=False)
        pr = np.clip(predict_proba(model, X.iloc[idx]), 1e-12, 1 - 1e-12)
        checks.append(check_shap_additivity(vals_in[mi, idx], expected[mi], np.log(pr / (1 - pr)), cfg["shap"]["additivity_tol"]))
    vals = np.stack([merge_indicators(v, cols, cfg) for v in vals_in])
    thr = thresholds({m: prob[i] for i, m in enumerate(model_ids)}, reg, cfg)
    write_json(thr, out.parent / "thresholds.json")
    np.savez_compressed(out, values=vals, values_inputs=vals_in, prob=prob, expected=expected,
                        model_ids=np.array(model_ids), person_ids=audit["id"].to_numpy(),
                        features=np.array(cols["features"]), y=audit["y"].to_numpy())
    # reason codes (long format, main k, main rule)
    rule = cfg["decision"]["main_rule"]
    adv = decisions(prob, model_ids, thr, rule)
    rc = cfg["reasons"]
    reasons = pd.concat([reason_table(vals[i], adv[i], audit["id"].to_numpy(), cols["features"], rc["k_main"], rc["min_shap"], m)
                         for i, m in enumerate(model_ids)], ignore_index=True)
    rdir = out_dir(cfg, "reasons")
    reasons.to_parquet(rdir / f"{ds}_{args.variant}.parquet", index=False)
    short = reasons.groupby(["model_id", "person"]).size()
    log.info("%s: %d reason rows; %.1f%% adverse (model,person) cells have fewer than k reasons", ds, len(reasons),
             100 * (short < rc["k_main"]).mean())
    perf = model_performance(prob, adv, audit["y"].to_numpy(), model_ids)
    perf.to_parquet(out.parent / f"performance_{rule}.parquet", index=False)
    log.info("mean audit AUC by condition:\n%s", perf.groupby(["condition", "generator"], dropna=False).auc.mean())
    checks += [check_auc_range(perf), check_reasons_are_inputs(reasons, cols)]
    report(checks, strict=not args.no_strict)
log.info("stage 04 done")
