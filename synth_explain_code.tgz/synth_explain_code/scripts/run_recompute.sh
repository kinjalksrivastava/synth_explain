#!/usr/bin/env bash
# Full recompute after the 2 Nov 2026 review (Spec 16.13): replacement TabDDPM seed for Taiwan, then every stage
# from model training onward for all variants on ONE machine, then the review quantities.
set -uo pipefail
cd "$(dirname "$0")/.."
PY=${PY:-.venv/bin/python}
PY_TABDDPM=${PY_TABDDPM:-.venv-ddpm/bin/python}
NJ=${NJ:-20}
mkdir -p outputs/logs
echo "=== $(date +%H:%M:%S) generate taiwan tabddpm seed 3" | tee -a outputs/logs/recompute.out
$PY_TABDDPM scripts/02_generate.py --dataset taiwan --generators tabddpm --seeds 3 > outputs/logs/02_generate_taiwan_tabddpm_s3.out 2>&1 || { echo "FAILED generate"; exit 1; }
echo "=== $(date +%H:%M:%S) verify synthetic" | tee -a outputs/logs/recompute.out
$PY scripts/verify_synthetic.py > outputs/logs/verify_synthetic_recompute.out 2>&1 || { echo "FAILED verify_synthetic (see outputs/logs/verify_synthetic_recompute.out)"; exit 1; }
echo "=== $(date +%H:%M:%S) stages 03-08, all variants, forced" | tee -a outputs/logs/recompute.out
FORCE=--force NJ=$NJ PY=$PY bash scripts/run_after_generate.sh || exit 1
for V in main rebal; do
  echo "=== $(date +%H:%M:%S) 09 review quantities $V" | tee -a outputs/logs/recompute.out
  $PY scripts/09_review_quantities.py --variant $V > outputs/logs/09_review_quantities_$V.out 2>&1 || echo "FAILED 09 $V" | tee -a outputs/logs/recompute.out
done
$PY -c "import importlib.metadata as m; print('\n'.join(sorted(f\"{d.metadata['Name']}=={d.version}\" for d in m.distributions())))" > outputs/logs/pip_freeze_recompute.txt
echo "=== RECOMPUTE DONE $(date +%H:%M:%S)" | tee -a outputs/logs/recompute.out
