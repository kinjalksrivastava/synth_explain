"""Stage 03: tune once on real data, then train all R, B, S models (Spec 4, 6, 16.9)."""
import pandas as pd
from sklearn.metrics import roc_auc_score

from _cli import parser
from src.common import columns_info, git_hash, load_config, load_meta, load_split, out_dir, setup_logging
from src.models import fit_model, get_tuned, iter_training_sets, predict_proba, registry_path, save_model

args = parser("train models").parse_args()
cfg = load_config(args.config)
log = setup_logging(cfg, "03_train_models")
for ds in args.dataset or cfg["datasets"]:
    cols, meta = columns_info(cfg, ds), load_meta(cfg, ds)
    tuned = get_tuned(cfg, ds, args.variant, cols, meta, force=args.force)
    audit = load_split(cfg, ds, "audit")
    rows = []
    mdir = out_dir(cfg, "models", ds, args.variant)
    for mid, info, X, y in iter_training_sets(cfg, ds, cols, variant=args.variant):
        path = mdir / mid
        existing = list(mdir.glob(mid + ".*"))
        if existing and not args.force:
            rows.append({"model_id": mid, **info, "path": str(existing[0]), "variant": args.variant, "git": git_hash()})
            continue
        model = fit_model(cfg, args.variant, tuned, cols, meta, X, y, seed=info["model_seed"])
        saved = save_model(model, path)
        auc = roc_auc_score(audit["y"], predict_proba(model, audit[cols["inputs"]]))
        log.info("%s %s %s n=%d audit AUC %.4f", ds, args.variant, mid, len(X), auc)
        rows.append({"model_id": mid, **info, "path": str(saved), "variant": args.variant, "git": git_hash(),
                     "n_train_rows": len(X), "train_class_ratio": float(y.mean())})
    reg = pd.DataFrame(rows)
    reg.to_parquet(registry_path(cfg, ds, args.variant), index=False)
    log.info("%s: %d models registered", ds, len(reg))
log.info("stage 03 done")
