"""Stage 08: figures 2-6 (Spec 13, 16.7)."""
import json

import pandas as pd

from _cli import parser
from src.common import load_config, out_dir, read_json, setup_logging
from src.plots import fig_displacement, fig_distributions, fig_generator_dependence, fig_h3, fig_money, fig_worked_example

p = parser("figures")
p.add_argument("--rule", default=None)
args = p.parse_args()
cfg = load_config(args.config)
log = setup_logging(cfg, "08_figures")
rule = args.rule or cfg["decision"]["main_rule"]
METRIC = f"jaccard_k{cfg['reasons']['k_main']}"
tdir = out_dir(cfg, "tables", args.variant)
fdir = out_dir(cfg, "figures", args.variant)
fig_money(pd.read_csv(tdir / f"rq2_points_{rule}.csv"), cfg, fdir / "fig2_displaced_vs_tstr")
for ds in args.dataset or cfg["datasets"]:
    person = pd.read_parquet(out_dir(cfg, "person") / f"{ds}_{args.variant}_{rule}.parquet")
    fig_distributions(person, METRIC, fdir / f"fig3_distributions_{ds}", ds)
    fig_displacement(person, METRIC, fdir / f"fig_displacement_{ds}", ds)
    long = pd.read_parquet(out_dir(cfg, "person") / f"{ds}_{args.variant}_{rule}_h3long.parquet")
    sg = pd.read_csv(tdir / f"subgroups_{ds}_{rule}.csv")
    fig_h3(long, sg, fdir / f"fig4_h3_{ds}", ds)
    fig_worked_example(read_json(tdir / f"worked_example_{ds}_{rule}.json"), fdir / f"fig5_example_{ds}", ds)
    ov = pd.read_csv(tdir / f"table5_overlap_{ds}_{rule}.csv", index_col=0)
    slopes = pd.read_csv(tdir / f"h3_spearman_by_generator_{ds}_{rule}.csv")
    fig_generator_dependence(ov, slopes, fdir / f"fig6_generator_dependence_{ds}", ds)
log.info("stage 08 done")
