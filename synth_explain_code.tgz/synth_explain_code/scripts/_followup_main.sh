#!/usr/bin/env bash
cd "$(dirname "$0")/.."
PY=.venv/bin/python; LOG=outputs/logs/recompute.out
while ! grep -q "RECOMPUTE DONE" $LOG; do sleep 120; done
run() { echo "=== $(date +%H:%M:%S) $*" >> $LOG; $PY scripts/$1.py --variant "$2" ${3:-} > "outputs/logs/${1}_${2}_recompute.out" 2>&1; rc=$?; echo "=== $(date +%H:%M:%S) $1 $2 exit $rc" >> $LOG; [ $rc -ne 0 ] && echo "FAILED $1 $2" >> $LOG; return $rc; }
run 05_recourse main --force && run 07_analysis main && run 08_figures main
echo "=== FOLLOWUP DONE $(date +%H:%M:%S)" >> $LOG
