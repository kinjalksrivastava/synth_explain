"""Stage 05: DiCE counterfactuals from every source model and transfer to real models (Spec 7.2, 16.4)."""
from _cli import parser
from src.common import columns_info, load_config, load_meta, load_split, out_dir, read_json, setup_logging
from src.metrics import explanations_path, load_explanations
from src.models import load_registry
from src.recourse import generate_all, recourse_sample, recourse_summary, transfer_test
from src.sanity import check_recourse_constraints, report

p = parser("recourse")
p.add_argument("--rule", default=None, help="decision rule (default: config decision.main_rule)")
args = p.parse_args()
cfg = load_config(args.config)
log = setup_logging(cfg, "05_recourse")
rule = args.rule or cfg["decision"]["main_rule"]
for ds in args.dataset or cfg["datasets"]:
    rdir = out_dir(cfg, "recourse", ds, args.variant)
    cf_path = rdir / f"counterfactuals_{rule}.parquet"
    cols, meta = columns_info(cfg, ds), load_meta(cfg, ds)
    expl = load_explanations(cfg, ds, args.variant)
    thr = read_json(explanations_path(cfg, ds, args.variant).parent / "thresholds.json")
    reg = load_registry(cfg, ds, args.variant)
    if cf_path.exists() and not args.force:
        import pandas as pd
        cfs = pd.read_parquet(cf_path)
        log.info("cached %s", cf_path)
    else:
        persons = recourse_sample(expl, thr, rule, cfg)
        log.info("%s: %d persons in recourse sample", ds, len(persons))
        cfs = generate_all(cfg, ds, reg, persons, thr, rule, cols, meta)
        cfs.to_parquet(cf_path, index=False)
    log.info("status counts:\n%s", cfs.status.value_counts())
    report([check_recourse_constraints(cfs)], strict=False)
    tr = transfer_test(cfs, reg, thr, rule, cols, load_split(cfg, ds, "train"), load_split(cfg, ds, "audit"))
    tr.to_parquet(rdir / f"transfer_{rule}.parquet", index=False)
    summ = recourse_summary(cfs, tr)
    summ.to_parquet(rdir / f"summary_{rule}.parquet", index=False)
    log.info("recourse summary:\n%s", summ.to_string())
log.info("stage 05 done")
