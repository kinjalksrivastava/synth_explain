"""Stage 02 (GPU): fit generators on real Train and sample synthetic datasets (Spec 5)."""
import pandas as pd

from _cli import parser
from src.common import columns_info, generator_seeds, load_config, load_meta, load_split, out_dir, provenance, setup_logging, write_json
from src.generators import run_generator
from src.sanity import check_no_audit_leakage, check_synthetic_schema, report

p = parser("generate synthetic data")
p.add_argument("--generators", nargs="*", default=None)
p.add_argument("--seeds", nargs="*", type=int, default=None)
args = p.parse_args()
cfg = load_config(args.config)
log = setup_logging(cfg, "02_generate")
gens = args.generators or cfg["generators"]["list"]
for ds in args.dataset or cfg["datasets"]:
    cols, meta = columns_info(cfg, ds), load_meta(cfg, ds)
    train = load_split(cfg, ds, "train")
    frames = []
    for g in gens:
        for s in (args.seeds if args.seeds is not None else generator_seeds(cfg, ds, g)):
            d = out_dir(cfg, "synthetic", ds, g)
            path = d / f"seed{s}.parquet"
            if path.exists() and not args.force:
                log.info("cached %s", path)
                frames.append(pd.read_parquet(path))
                continue
            log.info("fit %s %s seed %d", ds, g, s)
            try:
                synth, info = run_generator(g, train, cols, meta, cfg, s)
            except ImportError as e:
                log.error("%s", e)
                continue
            synth.to_parquet(path, index=False)
            write_json(provenance(cfg, dataset=ds, **info), d / f"seed{s}.json")
            log.info("%s %s seed %d: %.0fs, class ratio real %.3f synth %.3f, %d values post-processed", ds, g, s,
                     info["total_seconds"], info["real_class_ratio"], info["synthetic_class_ratio"], info["n_values_changed"])
            report([check_synthetic_schema(synth, train, cols)], strict=not args.no_strict)
            frames.append(synth)
    report([check_no_audit_leakage(cfg, ds, cols, frames)], strict=not args.no_strict)
log.info("stage 02 done")
