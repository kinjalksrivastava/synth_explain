"""Stage 06: pair agreement, person aggregates, displaced test, decision flips, and the standard quality checks (Spec 8)."""
import numpy as np
import pandas as pd

from _cli import parser
from src.common import columns_info, generator_seeds, load_config, load_meta, load_split, out_dir, read_json, setup_logging, write_json
from src.explain import background
from src.generators import build_sdv_metadata, generator_table
from src.metrics import (decision_flip_rates, decisions, detection_auc, displaced_test, explanations_path,
                         global_shap_distance, load_explanations, model_performance, pair_agreement, person_aggregates,
                         pgi, sdmetrics_score, tstr_table)
from src.models import load_model, load_registry
from src.sanity import check_r_models_differ, report

p = parser("metrics and quality checks")
p.add_argument("--skip-sdmetrics", action="store_true")
args = p.parse_args()
cfg = load_config(args.config)
log = setup_logging(cfg, "06_quality_checks")
rc = cfg["reasons"]
METRIC, OVERLAP = f"jaccard_k{rc['k_main']}", f"overlap_k{rc['k_main']}"

for ds in args.dataset or cfg["datasets"]:
    cols, meta = columns_info(cfg, ds), load_meta(cfg, ds)
    expl = load_explanations(cfg, ds, args.variant)
    thr = read_json(explanations_path(cfg, ds, args.variant).parent / "thresholds.json")
    model_ids = list(expl["model_ids"])
    families = {f: meta["features"][f]["family"] for f in cols["features"]}
    mdir = out_dir(cfg, "metrics", ds, args.variant)

    # ---- 8.2 / 8.3 for every decision rule
    for rule in cfg["decision"]["rules"]:
        pp = out_dir(cfg, "pairs") / f"{ds}_{args.variant}_{rule}.parquet"
        adv = decisions(expl["prob"], model_ids, thr, rule)
        if pp.exists() and not args.force:
            pairs = pd.read_parquet(pp)
        else:
            pairs = pair_agreement(expl["values"], adv, model_ids, expl["person_ids"], list(expl["features"]), cfg, families)
            pairs.to_parquet(pp, index=False)
        log.info("%s %s: %d valid pair-person rows", ds, rule, len(pairs))
        person = person_aggregates(pairs, cfg)
        person.to_parquet(out_dir(cfg, "person") / f"{ds}_{args.variant}_{rule}.parquet", index=False)
        for base in ("BR", "RR"):
            d = displaced_test(pairs, model_ids, cfg, METRIC, OVERLAP, baseline=base)
            d.to_parquet(mdir / f"displaced_{rule}_{base}.parquet", index=False)
        for kk in rc["k_list"]:                       # sensitivity of the displaced share to k (Spec 16.13)
            if kk != rc["k_main"]:
                d = displaced_test(pairs, model_ids, cfg, f"jaccard_k{kk}", f"overlap_k{kk}", baseline="BR")
                d.to_parquet(mdir / f"displaced_k{kk}_{rule}_BR.parquet", index=False)
        # per generator seed (RQ2 unit): restrict S models to one seed at a time
        by_seed = []
        for g in sorted(set(pairs.loc[pairs.pair_type == "SR", "generator"])):
            for s in generator_seeds(cfg, ds, g):
                keep = ~((pairs.pair_type == "SR") & ~((pairs.generator == g) & pairs.model_a.str.contains(f"_g{s}_")))
                sub_ids = [m for m in model_ids if not m.startswith("S_") or (m.startswith(f"S_{g}_g{s}_"))]
                d = displaced_test(pairs[keep], sub_ids, cfg, METRIC, OVERLAP, baseline="BR")
                d["gen_seed"] = s
                by_seed.append(d)
        pd.concat(by_seed, ignore_index=True).to_parquet(mdir / f"displaced_by_seed_{rule}.parquet", index=False)
        flips = decision_flip_rates(adv, model_ids)
        flips.to_parquet(mdir / f"flips_{rule}.parquet", index=False)
        perf = model_performance(expl["prob"], adv, expl["y"], model_ids)
        perf.to_parquet(mdir / f"performance_{rule}.parquet", index=False)
        if rule == cfg["decision"]["main_rule"]:
            vc = cfg["variants"][args.variant]
            deterministic = vc["family"] == "logistic" or (float(vc.get("subsample", 0.8)) >= 1.0 and float(vc.get("colsample_bytree", 0.8)) >= 1.0)
            if deterministic:
                log.info("sanity [2] skipped: this variant is deterministic given the data (logistic regression, or "
                         "subsample = colsample = 1.0), so R models coincide by design and only the bootstrap baseline "
                         "(B-R) is informative; D_seed equals 1 - A_SR here")
            else:
                report([check_r_models_differ(person, f"{METRIC}__RR")], strict=not args.no_strict)

    # ---- 8.1 standard checks per generator seed (threshold-free except PGI, which uses the main rule)
    qp = mdir / "quality.parquet"
    if qp.exists() and not args.force:
        log.info("cached %s", qp)
        continue
    rule = cfg["decision"]["main_rule"]
    adv = decisions(expl["prob"], model_ids, thr, rule)
    perf = model_performance(expl["prob"], adv, expl["y"], model_ids)
    q = tstr_table(perf)
    q = q.merge(global_shap_distance(expl["values"], model_ids), on=["generator", "gen_seed"])
    train, audit = load_split(cfg, ds, "train"), load_split(cfg, ds, "audit")
    real_tab = generator_table(train, cols)
    md = build_sdv_metadata(cols, meta)
    reg = load_registry(cfg, ds, args.variant)
    bg = background(cfg, ds, cols)
    X = audit[cols["inputs"]]
    cov = pd.DataFrame({"person": expl["person_ids"]})
    pgi_R = float(np.mean([pgi(load_model(r.path), X, expl["values"][model_ids.index(r.model_id)], adv[model_ids.index(r.model_id)],
                                expl["prob"][model_ids.index(r.model_id)], bg, cols, cfg["quality"]["pgi_k"])
                           for _, r in reg[reg.condition == "R"].iterrows()]))
    extra = []
    for _, row in q.iterrows():
        g, s = row.generator, int(row.gen_seed)
        synth = pd.read_parquet(out_dir(cfg, "synthetic", ds, g) / f"seed{s}.parquet")
        info = read_json(out_dir(cfg, "synthetic", ds, g) / f"seed{s}.json")
        sd = np.nan if args.skip_sdmetrics else sdmetrics_score(real_tab, synth[real_tab.columns], md)
        auc_det, p_real = detection_auc(real_tab.drop(columns=["y"]), synth.drop(columns=["y"]), audit, cfg)
        cov[f"coverage_{g}_s{s}"] = p_real
        pg = []
        for _, r in reg[(reg.generator == g) & (reg.gen_seed == s)].iterrows():
            i = model_ids.index(r.model_id)
            pg.append(pgi(load_model(r.path), X, expl["values"][i], adv[i], expl["prob"][i], bg, cols, cfg["quality"]["pgi_k"]))
        extra.append({"generator": g, "gen_seed": s, "sdmetrics_score": sd, "detection_auc": auc_det, "pgi": float(np.mean(pg)),
                      "pgi_R": pgi_R, "synthetic_class_ratio": info.get("synthetic_class_ratio"),
                      "real_class_ratio": info.get("real_class_ratio"), "fit_seconds": info.get("fit_seconds")})
        log.info("%s %s seed %d: TSTR gap %.4f sdmetrics %.3f detection %.3f gsd %.4f pgi %.4f", ds, g, s, row.tstr_auc_gap,
                 sd, auc_det, row.global_shap_distance, extra[-1]["pgi"])
    q = q.merge(pd.DataFrame(extra), on=["generator", "gen_seed"])
    q.to_parquet(qp, index=False)
    for g in sorted(q.generator.unique()):
        cov[f"coverage_{g}"] = cov[[c for c in cov.columns if c.startswith(f"coverage_{g}_s")]].mean(axis=1)
    cov.to_parquet(mdir / "coverage.parquet", index=False)
log.info("stage 06 done")
