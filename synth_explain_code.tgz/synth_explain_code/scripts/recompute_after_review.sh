#!/usr/bin/env bash
# Recompute after the 19 Oct 2026 code review: threshold-relative recourse margin, shared-R seed-baseline bootstrap,
# min-pairs mixed model, rebalance resampling, worked example. Runs locally.
set -uo pipefail
cd "$(dirname "$0")/.."
PY=.venv/bin/python; LOG=outputs/logs/recompute.out
run() { echo "=== $(date +%H:%M:%S) $*" >> $LOG; $PY scripts/$1.py --variant "$2" ${3:-} > "outputs/logs/${1}_${2}_recompute.out" 2>&1; rc=$?; echo "=== $(date +%H:%M:%S) $1 $2 exit $rc" >> $LOG; [ $rc -ne 0 ] && echo "FAILED $1 $2" >> $LOG; return $rc; }
run 06_quality_checks main && run 05_recourse main --force && run 07_analysis main && run 08_figures main
run 03_train_models rebal --force && run 04_explain rebal "--force --n-jobs 8" && run 06_quality_checks rebal --force && run 05_recourse rebal --force && run 07_analysis rebal && run 08_figures rebal
for V in sub06 sub10 lr; do run 06_quality_checks $V && run 07_analysis $V && run 08_figures $V; done
echo "=== RECOMPUTE DONE $(date +%H:%M:%S)" >> $LOG
