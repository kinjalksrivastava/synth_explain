#!/usr/bin/env bash
# One-shot setup + launch on a fresh CUDA box (Ubuntu, vast.ai pytorch image). Run from the project root:
#   bash scripts/box_bootstrap.sh            # builds .venv (py3.11, pinned) and .venv-ddpm, then starts the recompute
# Versions are pinned to the environment of the first box run (outputs/logs/pip_freeze_*.txt); torch for the
# main env is CPU-only (stages 03-09 do not use the GPU); TabDDPM runs in .venv-ddpm with CUDA torch 2.4.1.
set -euo pipefail
cd "$(dirname "$0")/.."
export DEBIAN_FRONTEND=noninteractive
command -v uv >/dev/null || { curl -LsSf https://astral.sh/uv/install.sh | sh; export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"; }
export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"
echo "=== main env"
[ -x .venv/bin/python ] || uv venv --python 3.11 .venv
uv pip install --python .venv/bin/python -r requirements-lock.txt
uv pip install --python .venv/bin/python --index-url https://download.pytorch.org/whl/cpu "torch==2.14.1" || uv pip install --python .venv/bin/python --index-url https://download.pytorch.org/whl/cpu torch
echo "=== tabddpm env"
[ -x .venv-ddpm/bin/python ] || uv venv --python 3.12 .venv-ddpm
uv pip install --python .venv-ddpm/bin/python -r requirements-tabddpm.txt
uv pip install --python .venv-ddpm/bin/python --no-deps torch==2.4.1 torchvision==0.19.1 torchaudio==2.4.1 opacus==1.5.2
echo "=== checks"
.venv/bin/python -c 'import importlib.metadata,numpy,pandas,xgboost,shap,sdv,sdmetrics,dice_ml,statsmodels; print("main ok", numpy.__version__, pandas.__version__, xgboost.__version__, shap.__version__, sdv.__version__, sdmetrics.__version__, importlib.metadata.version("dice-ml"))'
.venv-ddpm/bin/python -c "import torch,synthcity; print('ddpm ok torch', torch.__version__, 'cuda', torch.cuda.is_available())"
mkdir -p outputs/logs
echo "=== launching recompute (nohup); follow with: tail -f outputs/logs/recompute.out outputs/logs/chain.out"
NJ=${NJ:-$(nproc)} nohup bash scripts/run_recompute.sh > outputs/logs/recompute_nohup.out 2>&1 &
echo "pid $!" | tee outputs/logs/recompute.pid
