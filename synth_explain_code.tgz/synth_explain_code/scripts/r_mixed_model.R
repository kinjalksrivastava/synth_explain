# Optional: full crossed-effects mixed model on the pair-level table (Spec 9.1 / 16.8).
#   Rscript scripts/r_mixed_model.R outputs/pairs/heloc_main_quantile.parquet
# Requires: install.packages(c("arrow", "lme4", "dplyr"))
suppressPackageStartupMessages({library(arrow); library(lme4); library(dplyr)})
args <- commandArgs(trailingOnly = TRUE)
pairs <- read_parquet(args[1]) %>%
  mutate(key = ifelse(pair_type == "SR", paste0("SR_", generator), as.character(pair_type)),
         key = relevel(factor(key), ref = "BR"))
m <- lmer(jaccard_k3 ~ key + (1 | person) + (1 | model_a) + (1 | model_b), data = pairs, REML = TRUE)
print(summary(m))
ci <- confint(m, method = "Wald")
print(ci)
