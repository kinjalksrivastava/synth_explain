"""Verify every synthetic dataset against real Train: columns, dtypes, row count, NaN, ranges/domains, value sets,
indicator consistency, class ratio, duplicates, marginal distances, and known deterministic relations.
Writes outputs/quality/synthetic_verification.csv and prints a report. Exit code 1 if any hard check fails."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import ks_2samp

from _cli import parser
from src.common import columns_info, generator_seeds, load_config, load_meta, load_split, out_dir, read_json, row_hashes

args = parser("verify synthetic data").parse_args()
cfg = load_config(args.config)
rows, hard_fail = [], []
RELATIONS = {"heloc": [("NumInqLast6M", ">=", "NumInqLast6Mexcl7days"), ("NumTrades60Ever2DerogPubRec", ">=", "NumTrades90Ever2DerogPubRec"),
                       ("NumTotalTrades", ">=", "NumSatisfactoryTrades"), ("MSinceOldestTradeOpen", ">=", "MSinceMostRecentTradeOpen")],
             "taiwan": []}
for ds in args.dataset or cfg["datasets"]:
    cols, meta = columns_info(cfg, ds), load_meta(cfg, ds)
    train, audit = load_split(cfg, ds, "train"), load_split(cfg, ds, "audit")
    want = cols["inputs"] + ["y"]
    h_audit = set(row_hashes(audit, cols["inputs"]))
    h_train = set(row_hashes(train, cols["inputs"]))
    for g in cfg["generators"]["list"]:
        for s in generator_seeds(cfg, ds, g):
            p = out_dir(cfg, "synthetic", ds, g) / f"seed{s}.parquet"
            if not p.exists():
                rows.append({"dataset": ds, "generator": g, "seed": s, "status": "MISSING"}); continue
            syn = pd.read_parquet(p)
            info = read_json(p.with_suffix(".json")) if p.with_suffix(".json").exists() else {}
            r = {"dataset": ds, "generator": g, "seed": s, "status": "ok", "n_rows": len(syn), "n_cols": syn.shape[1]}
            problems = []
            if list(syn.columns) != want: problems.append(f"columns differ: {set(syn.columns) ^ set(want)}")
            if len(syn) != len(train): problems.append(f"rows {len(syn)} != n_train {len(train)}")
            bad_dt = [c for c in want if c in syn and syn[c].dtype != train[c].dtype]
            if bad_dt: problems.append(f"dtype differs: {bad_dt}")
            n_nan = int(syn[want].isna().sum().sum()) if set(want) <= set(syn.columns) else -1
            if n_nan: problems.append(f"{n_nan} NaN cells")
            r["n_nan"] = n_nan
            # ranges / domains
            out_of_range = {}
            for c, rg in cols["ranges"].items():
                if c not in syn: continue
                if "domain" in rg:
                    extra = set(syn[c].unique()) - set(rg["domain"])
                    if extra: out_of_range[c] = f"domain extra {sorted(extra)}"
                elif syn[c].min() < rg["min"] - 1e-9 or syn[c].max() > rg["max"] + 1e-9:
                    out_of_range[c] = f"[{syn[c].min()},{syn[c].max()}] vs [{rg['min']},{rg['max']}]"
            if out_of_range: problems.append(f"out of range: {out_of_range}")
            # integer-ness
            non_int = [c for c in cols["features"] if meta["features"][c]["type"] in ("integer", "ordinal", "categorical")
                       and not np.allclose(syn[c].to_numpy(dtype=float), np.round(syn[c].to_numpy(dtype=float)))]
            if non_int: problems.append(f"non-integer values in integer columns: {non_int}")
            # indicator consistency
            for ind in cols["indicators"]:
                f = ind[:-3]
                fill = train.loc[train[ind] == 1, f]
                if fill.empty: continue
                m = syn[ind] == 1
                bad = int((m & ~np.isclose(syn[f], float(fill.iloc[0]))).sum())
                if bad: problems.append(f"{ind}: {bad} rows with indicator=1 but value != imputed")
                if not (set(syn[ind].unique()) <= {0, 1}): problems.append(f"{ind} not binary")
            # value sets for categorical/ordinal, missing levels
            missing_levels = {}
            for c in cols["features"]:
                if meta["features"][c]["type"] in ("categorical", "ordinal"):
                    real_lv, syn_lv = set(train[c].unique()), set(syn[c].unique())
                    if syn_lv - real_lv: problems.append(f"{c}: unseen levels {sorted(syn_lv - real_lv)}")
                    lost = real_lv - syn_lv
                    if lost: missing_levels[c] = sorted(lost)
            r["levels_missing"] = str(missing_levels) if missing_levels else ""
            # class ratio, duplicates, copies of real rows
            r["class_ratio_real"] = float(train["y"].mean()); r["class_ratio_synth"] = float(syn["y"].mean())
            h_syn = row_hashes(syn, cols["inputs"])
            r["dup_rows_within"] = int(h_syn.duplicated().sum())
            r["rows_identical_to_train"] = int(len(set(h_syn) & h_train))
            r["rows_identical_to_audit"] = int(len(set(h_syn) & h_audit))
            r["share_identical_to_train"] = r["rows_identical_to_train"] / len(syn)
            # marginal fidelity: mean KS statistic over features, worst feature
            ks = {c: ks_2samp(train[c], syn[c]).statistic for c in cols["features"]}
            r["ks_mean"] = float(np.mean(list(ks.values()))); worst = max(ks, key=ks.get); r["ks_worst"] = f"{worst}={ks[worst]:.3f}"
            # means ratio sanity: any feature whose mean is off by > 50% of real std
            off = [c for c in cols["features"] if abs(syn[c].mean() - train[c].mean()) > 0.5 * (train[c].std() or 1)]
            r["features_mean_off"] = ",".join(off)
            # deterministic relations
            rel = {}
            for a, op, b in RELATIONS.get(ds, []):
                real_ok = float(np.mean(train[a] >= train[b])); syn_ok = float(np.mean(syn[a] >= syn[b]))
                rel[f"{a}>={b}"] = f"real {real_ok:.2f} synth {syn_ok:.2f}"
            r["relations"] = str(rel)
            r["fit_seconds"] = info.get("fit_seconds"); r["values_postprocessed"] = info.get("n_values_changed")
            # collapse gate (Spec 16.13): a generator run is discarded, before any downstream analysis, if more than 5% of
            # its rows are exact duplicates of each other or any numeric feature with >= 10 real levels has < 3 levels
            dup_share = r["dup_rows_within"] / len(syn)
            if dup_share > 0.05: problems.append(f"collapsed: {dup_share:.1%} duplicate rows")
            flat = [c for c in cols["features"] if train[c].nunique() >= 10 and syn[c].nunique() < 3]
            if flat: problems.append(f"collapsed: constant features {flat}")
            if problems:
                r["status"] = "FAIL"; r["problems"] = " | ".join(problems); hard_fail.append((ds, g, s, problems))
            rows.append(r)
df = pd.DataFrame(rows)
out = out_dir(cfg, "quality") / "synthetic_verification.csv"
df.to_csv(out, index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 60)
print(df[["dataset", "generator", "seed", "status", "n_rows", "n_cols", "n_nan", "class_ratio_synth", "dup_rows_within",
          "rows_identical_to_train", "ks_mean", "ks_worst", "features_mean_off", "levels_missing"]].to_string(index=False))
print("\nrelations (HELOC):")
for _, r in df[df.dataset == "heloc"].iterrows():
    if r.get("status") != "MISSING": print(f"  {r.generator} s{r.seed}: {r.relations}")
if hard_fail:
    print("\nHARD FAILURES:")
    for f in hard_fail: print(" ", f)
    sys.exit(1)
print("\nall hard checks passed; written", out)
