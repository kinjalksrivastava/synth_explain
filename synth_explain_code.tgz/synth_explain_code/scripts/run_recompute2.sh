#!/usr/bin/env bash
# Second recompute pass after Spec 16.14 (3 Nov 2026): recourse search with plausibility bounds and closest-candidate
# selection (05), displaced-test statistics for all persons and CI tolerance (06), tuned configuration frozen across
# tree variants (03 for sub06/sub10), stage 09 changes. Runs after run_recompute.sh has finished.
set -uo pipefail
cd "$(dirname "$0")/.."
PY=${PY:-.venv/bin/python}
NJ=${NJ:-20}
L=outputs/logs/recompute2.out
mkdir -p outputs/logs
run() { echo "=== $(date +%H:%M:%S) $*" | tee -a $L; T=8; [ "$1" = "05_recourse" ] && T=1; OMP_NUM_THREADS=$T $PY scripts/$1.py --variant $2 --force ${3:-} > outputs/logs/${1}_${2}_r2.out 2>&1; rc=$?; echo "=== $(date +%H:%M:%S) $1 $2 exit $rc" | tee -a $L; [ $rc -ne 0 ] && { echo "FAILED $1 $2" | tee -a $L; exit 1; }; return 0; }
for V in main rebal; do
  run 06_quality_checks $V; run 05_recourse $V; run 07_analysis $V; run 08_figures $V; run 09_review_quantities $V
done
# recourse workers run single-threaded (32 workers x 1 thread); 8 OMP threads per worker oversubscribed the 32-CPU cap 8x
# sub06 / sub10 / lr were produced by run_after_generate.sh after the 16.14 code was in place (no recourse stage).
$PY -c "import importlib.metadata as m; print('\n'.join(sorted(f\"{d.metadata['Name']}=={d.version}\" for d in m.distributions())))" > outputs/logs/pip_freeze_recompute.txt
echo "=== RECOMPUTE2 DONE $(date +%H:%M:%S)" | tee -a $L
