"""Stage 01: download, clean, split, preprocess (Spec 2, 3, 16.1)."""
from _cli import parser
from src.common import columns_info, load_config, setup_logging
from src.data import prepare_dataset
from src.sanity import check_no_audit_leakage, report

args = parser("prepare data").parse_args()
cfg = load_config(args.config)
log = setup_logging(cfg, "01_prepare_data")
for ds in args.dataset or cfg["datasets"]:
    prepare_dataset(cfg, ds, force=args.force)
    cols = columns_info(cfg, ds)
    report([check_no_audit_leakage(cfg, ds, cols)], strict=not args.no_strict)
log.info("stage 01 done")
