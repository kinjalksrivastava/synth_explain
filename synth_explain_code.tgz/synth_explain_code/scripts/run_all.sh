#!/usr/bin/env bash
# Full pipeline. Stage 02 needs a GPU for the GAN/VAE generators; TabDDPM runs from .venv-ddpm (see README).
set -euo pipefail
cd "$(dirname "$0")/.."
PY=${PY:-.venv/bin/python}
VARIANT=${VARIANT:-main}
$PY scripts/01_prepare_data.py
$PY scripts/02_generate.py --generators gaussian_copula copulagan ctgan tvae
if [ -x .venv-ddpm/bin/python ]; then .venv-ddpm/bin/python scripts/02_generate.py --generators tabddpm; fi
$PY scripts/03_train_models.py --variant "$VARIANT"
$PY scripts/04_explain.py --variant "$VARIANT"
$PY scripts/06_quality_checks.py --variant "$VARIANT"
$PY scripts/05_recourse.py --variant "$VARIANT"
$PY scripts/07_analysis.py --variant "$VARIANT"
$PY scripts/08_figures.py --variant "$VARIANT"
