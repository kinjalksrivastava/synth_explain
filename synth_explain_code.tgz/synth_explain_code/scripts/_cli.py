"""Shared argparse for stage scripts."""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def parser(desc: str) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=desc)
    p.add_argument("--config", default=None)
    p.add_argument("--dataset", nargs="*", default=None, help="subset of datasets (default: all in config)")
    p.add_argument("--variant", default="main", help="main | sub06 | sub10 | lr")
    p.add_argument("--force", action="store_true", help="recompute even if outputs exist")
    p.add_argument("--no-strict", action="store_true", help="continue after a failed sanity check")
    return p
