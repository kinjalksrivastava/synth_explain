"""Stage 09: quantities the paper reports beyond the stage-07 tables, computed from stored outputs (Spec 16.13).
- generator-level mean displacement with model-bootstrap 95% intervals (shared R draw, Spec 16.3)
- generator-level Spearman correlations between displaced share and each check (5 per dataset, 10 pooled)
- recourse validity with bootstrap intervals over sampled persons, and at alternative margins (rescoring only)
- sensitivity of the displaced share to the analysis choices (criterion, minimum pairs, k, hidden-failure gate)
- worked example chosen by a stated rule
- figures: validity by condition; overlap of displaced sets
Writes outputs/tables/<variant>/review_<ds>_<rule>.json, sensitivity_<ds>_<rule>.csv and the figures."""
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

from _cli import parser
from src.common import load_config, out_dir, read_json, setup_logging, write_json
from src.metrics import CI_TOL, _pair_matrix, decisions, explanations_path, load_explanations, model_groups
from src.models import load_model, load_registry
from src.plots import fig_overlap, fig_validity

p = parser("review quantities")
p.add_argument("--rule", default=None)
args = p.parse_args()
cfg = load_config(args.config)
log = setup_logging(cfg, "09_review_quantities")
rule = args.rule or cfg["decision"]["main_rule"]
rc, acfg = cfg["reasons"], cfg["agreement"]
K = rc["k_main"]
METRIC, OVERLAP = f"jaccard_k{K}", f"overlap_k{K}"
tdir = out_dir(cfg, "tables", args.variant)
fdir = out_dir(cfg, "figures", args.variant)
CHECKS = ["tstr_auc_gap", "sdmetrics_score", "detection_auc", "global_shap_distance", "pgi"]


def gen_level_mean_ci(pairs, model_ids, metric, nboot, seed):
    """Mean over testable persons of D_g = mean(BR) - mean(SR_g); bootstrap over models with a shared R draw."""
    groups = model_groups(model_ids)
    R = [model_ids[i] for i in groups["R"]]
    B = [model_ids[i] for i in groups["B"]]
    persons = np.array(sorted(pairs.person.unique()))
    Jb = _pair_matrix(pairs, persons, B, R, metric)
    rng = np.random.default_rng(seed)
    out = {}
    with np.errstate(all="ignore"):
        for g, S_idx in groups["S"].items():
            S = [model_ids[i] for i in S_idx]
            Js = _pair_matrix(pairs, persons, S, R, metric)
            ok = ((~np.isnan(Jb)).sum(axis=(1, 2)) >= acfg["min_valid_pairs"]) & ((~np.isnan(Js)).sum(axis=(1, 2)) >= acfg["min_valid_pairs"])
            point = float(np.nanmean(np.nanmean(Jb[ok], axis=(1, 2)) - np.nanmean(Js[ok], axis=(1, 2))))
            boots = np.empty(nboot)
            for it in range(nboot):
                rR = rng.integers(0, len(R), len(R)); rB = rng.integers(0, len(B), len(B)); rS = rng.integers(0, len(S), len(S))
                mb = np.nanmean(Jb[ok][:, rB][:, :, rR], axis=(1, 2)); ms = np.nanmean(Js[ok][:, rS][:, :, rR], axis=(1, 2))
                boots[it] = np.nanmean(mb - ms)
            out[g] = {"D_mean": point, "ci_low": float(np.quantile(boots, 0.025)), "ci_high": float(np.quantile(boots, 0.975)),
                      "n_testable": int(ok.sum())}
    return out


def displaced_sensitivity(disp, pairs, model_ids):
    """Displaced share under alternative criteria. Rows: criterion x generator."""
    rows = []
    min_drop = acfg["displaced_min_overlap_drop"]
    for g, d in disp.groupby("generator"):
        t = d[d.testable]
        base = float(t.displaced.mean())
        rows.append({"generator": g, "choice": "main (CI>0 and drop>=%.1f)" % min_drop, "displaced_share": base, "n_testable": len(t)})
        rows.append({"generator": g, "choice": "CI>0 only", "displaced_share": float((t.ci_low > CI_TOL).mean()), "n_testable": len(t)})
        rows.append({"generator": g, "choice": "drop>=%.1f only" % min_drop, "displaced_share": float((t.overlap_drop >= min_drop).mean()), "n_testable": len(t)})
        rows.append({"generator": g, "choice": "CI>0 and drop>=1.0", "displaced_share": float(((t.ci_low > CI_TOL) & (t.overlap_drop >= 1.0)).mean()), "n_testable": len(t)})
        rows.append({"generator": g, "choice": "BH-adjusted", "displaced_share": float(t.displaced_bh.mean()), "n_testable": len(t)})
        for mp in (3, 10):
            ok = (d.n_valid_baseline >= mp) & (d.n_valid_sr >= mp)
            sub = d[ok]
            share = float(((sub.ci_low > CI_TOL) & (sub.overlap_drop >= min_drop)).mean()) if len(sub) else np.nan
            rows.append({"generator": g, "choice": f"min pairs {mp}", "displaced_share": share, "n_testable": int(ok.sum())})
    return pd.DataFrame(rows)


def validity_with_ci(transfer, nboot=1000, seed=0):
    """Validity among found per condition, with a two-way cluster bootstrap interval: persons and source models are
    resampled independently in every draw, since counterfactuals share both (Spec 16.14)."""
    rng = np.random.default_rng(seed)
    out = {}
    for (cond, gen), t in transfer.groupby(["condition", "generator"]):
        key = cond if cond != "S" else gen
        S = t.pivot_table(index="person", columns="source_id", values="valid_share", aggfunc="sum", fill_value=0.0).to_numpy()
        C = t.pivot_table(index="person", columns="source_id", values="valid_share", aggfunc="size", fill_value=0).to_numpy()
        n_p, n_m = S.shape
        boots = np.empty(nboot)
        for b in range(nboot):
            ip = rng.integers(0, n_p, n_p); im = rng.integers(0, n_m, n_m)
            boots[b] = S[ip][:, im].sum() / max(C[ip][:, im].sum(), 1)
        out[key] = {"validity": float(t.valid_share.mean()), "ci_low": float(np.quantile(boots, 0.025)),
                    "ci_high": float(np.quantile(boots, 0.975)), "n_cfs": int(len(t)), "n_persons": int(n_p), "n_sources": int(n_m)}
    return out


def expected_jaccard(n, k):
    """E[Jaccard] of two independent uniform random k-subsets of n features (the uniform null)."""
    from math import comb
    return sum(comb(k, m) * comb(n - k, k - m) / comb(n, k) * (m / (2 * k - m)) for m in range(0, k + 1))


def permutation_null(expl, adverse, R_idx, k, seed=0, n_perm=5):
    """Chance agreement that respects how concentrated reasons are: the Jaccard between applicant i's reasons under one
    real model and ANOTHER rejected applicant's reasons under a second real model, averaged over R pairs and permutations
    (Spec 16.14). Compared with the uniform null E[J] for random k-subsets of the feature set."""
    rng = np.random.default_rng(seed)
    vals = expl["values"]
    tops = {}
    for mi in R_idx:
        v = vals[mi]
        order = np.argsort(-v, axis=1)[:, :k]
        tops[mi] = [frozenset(order[p][v[p, order[p]] > 0]) for p in range(v.shape[0])]
    js = []
    for a in R_idx:
        for b in R_idx:
            if b <= a:
                continue
            both = np.where(adverse[a] & adverse[b])[0]
            if len(both) < 2:
                continue
            for _ in range(n_perm):
                perm = rng.permutation(both)
                for i, j in zip(both, perm):
                    if i == j:
                        continue
                    A, B = tops[a][i], tops[b][j]
                    u = len(A | B)
                    js.append(len(A & B) / u if u else np.nan)
    return float(np.nanmean(js))


def validity_at_margins(cfs, registry, thr, cols_inputs, ratios):
    """Rescore stored counterfactuals: a counterfactual counts at ratio r if p_source_after <= r x source threshold;
    transfer validity among those, per condition."""
    R = registry[registry.condition == "R"]
    targets = {r.model_id: load_model(r.path) for _, r in R.iterrows()}
    cand = cfs[cfs.status.isin(["ok", "margin_fail"])].copy()
    if cand.empty:
        return {}
    Xcf = pd.DataFrame(cand[[f"cf_{f}" for f in cols_inputs]].to_numpy(dtype=float), columns=cols_inputs)
    preds = {tid: m.predict_proba(Xcf)[:, 1] for tid, m in targets.items()}
    valid = np.zeros(len(cand)); n_t = np.zeros(len(cand))
    for tid, p_ in preds.items():
        mask = (cand.source_id != tid).to_numpy()
        valid += (p_ < float(thr[rule][tid])) * mask; n_t += mask
    cand["valid_share"] = valid / np.maximum(n_t, 1)
    info = cand.source_id.str.extract(r"^(R|B|S)(?:_([a-z_]+?))?_(?:m|b|g)\d")
    cand["condition"] = info[0]; cand["generator"] = info[1].fillna("")
    out = {}
    for r in ratios:
        ok = cand[cand.p_source_after <= r * cand.source_threshold]
        v = ok.groupby(["condition", "generator"]).valid_share.mean()
        out[str(r)] = {(c if c != "S" else g): float(x) for (c, g), x in v.items()}
    return out


def hidden_failure_grid(points):
    out = {}
    for gap in (0.01, 0.02, 0.03):
        for share in (0.05, 0.10, 0.20):
            out[f"gap<{gap}&share>{share}"] = int(((points.tstr_auc_gap < gap) & (points.displaced_share > share)).sum())
    return out


def choose_example(expl, disp, adverse, k):
    """Rule: among applicants displaced under the generator with the largest mean D, take the one with the largest D
    for whom every real model rejects and gives the same k reasons, and show the synthetic model with the most
    reasons not shared with that list. Falls back to the largest D with any rejecting pair."""
    model_ids = list(expl["model_ids"]); feats = list(expl["features"])
    gmean = disp[disp.testable].groupby("generator").D.mean()
    g = gmean.idxmax()
    cand = disp[(disp.generator == g) & disp.displaced].sort_values("D", ascending=False)
    R = [i for i, m in enumerate(model_ids) if m.startswith("R_")]
    S = [i for i, m in enumerate(model_ids) if m.startswith(f"S_{g}_")]
    def reasons(mi, pi):
        v = expl["values"][mi, pi]; order = np.argsort(-v)[:k]
        return [(feats[j], float(v[j])) for j in order if v[j] > 0]
    fallback = None
    for _, row in cand.iterrows():
        pi = int(np.where(expl["person_ids"] == row.person)[0][0])
        r_ok = [i for i in R if adverse[i, pi]]; s_ok = [i for i in S if adverse[i, pi]]
        if not r_ok or not s_ok:
            continue
        rsets = [tuple(sorted(f for f, _ in reasons(i, pi))) for i in r_ok]
        rec = {"person": int(row.person), "generator": g, "D": float(row.D), "ci": [float(row.ci_low), float(row.ci_high)],
               "n_real_rejecting": len(r_ok), "n_synth_rejecting": len(s_ok)}
        if fallback is None:
            fallback = rec
        if len(r_ok) == len(R) and len(set(rsets)) == 1:
            rset = set(rsets[0])
            best = max(s_ok, key=lambda i: len(set(f for f, _ in reasons(i, pi)) - rset))
            rec["real"] = {"model": model_ids[r_ok[0]], "prob": float(expl["prob"][r_ok[0], pi]), "reasons": reasons(r_ok[0], pi)}
            rec["synthetic"] = {"model": model_ids[best], "prob": float(expl["prob"][best, pi]), "reasons": reasons(best, pi)}
            rec["shared_reasons"] = len(rset & set(f for f, _ in rec["synthetic"]["reasons"]))
            rec["rule"] = "all real models reject with identical reasons; synthetic model with fewest shared reasons"
            return rec
    if fallback:
        pi = int(np.where(expl["person_ids"] == fallback["person"])[0][0])
        r_ok = [i for i in R if adverse[i, pi]]; s_ok = [i for i in S if adverse[i, pi]]
        fallback["real"] = {"model": model_ids[r_ok[0]], "prob": float(expl["prob"][r_ok[0], pi]), "reasons": reasons(r_ok[0], pi)}
        fallback["synthetic"] = {"model": model_ids[s_ok[0]], "prob": float(expl["prob"][s_ok[0], pi]), "reasons": reasons(s_ok[0], pi)}
        fallback["rule"] = "fallback: largest D with a rejecting real and synthetic model"
    return fallback or {}


gen_rows = []
for ds in args.dataset or cfg["datasets"]:
    mdir = out_dir(cfg, "metrics", ds, args.variant)
    pairs = pd.read_parquet(out_dir(cfg, "pairs") / f"{ds}_{args.variant}_{rule}.parquet")
    disp = pd.read_parquet(mdir / f"displaced_{rule}_BR.parquet")
    expl = load_explanations(cfg, ds, args.variant)
    model_ids = list(expl["model_ids"])
    thr = read_json(explanations_path(cfg, ds, args.variant).parent / "thresholds.json")
    adv = decisions(expl["prob"], model_ids, thr, rule)
    points = pd.read_csv(tdir / f"rq2_points_{rule}.csv"); points = points[points.dataset == ds]
    review = {"dataset": ds, "variant": args.variant, "rule": rule}

    review["gen_mean_D_ci"] = gen_level_mean_ci(pairs, model_ids, METRIC, acfg["n_bootstrap"], acfg["bootstrap_seed"])
    log.info("%s generator-level mean D with 95%% CI: %s", ds, {g: (round(v["D_mean"], 3), round(v["ci_low"], 3), round(v["ci_high"], 3)) for g, v in review["gen_mean_D_ci"].items()})

    # generator-level correlations: per-generator means of the per-seed checks against the generator-level displaced
    # share of Table 2 (the nine-model test), not the mean of the per-seed three-model shares (Spec 16.14)
    gm = points.groupby("generator")[CHECKS].mean().reset_index()
    t2 = pd.read_csv(tdir / f"table2_main_{ds}_{rule}.csv")[["generator", "displaced_share"]]
    gm = gm.merge(t2, on="generator", how="left")
    gm["dataset"] = ds; gen_rows.append(gm)
    groups = model_groups(model_ids)
    review["null_uniform"] = float(expected_jaccard(len(expl["features"]), K))
    review["null_permutation"] = permutation_null(expl, adv, groups["R"], K, acfg["bootstrap_seed"])
    log.info("%s chance agreement: uniform %.3f, permutation %.3f", ds, review["null_uniform"], review["null_permutation"])
    review["gen_level_rho"] = {c: float(spearmanr(gm[c], gm.displaced_share)[0]) for c in CHECKS}
    review["hidden_failure_grid"] = hidden_failure_grid(points)

    sens = displaced_sensitivity(disp, pairs, model_ids)
    # k = 1 and 4 shares from the stored displaced tables, if present
    for kk in rc["k_list"]:
        f = mdir / f"displaced_k{kk}_{rule}_BR.parquet"
        if kk != K and f.exists():
            dk = pd.read_parquet(f)
            for g, d in dk[dk.testable].groupby("generator"):
                sens.loc[len(sens)] = {"generator": g, "choice": f"k={kk}", "displaced_share": float(d.displaced.mean()), "n_testable": len(d)}
    sens.insert(0, "dataset", ds)
    sens.to_csv(tdir / f"sensitivity_{ds}_{rule}.csv", index=False)
    log.info("%s sensitivity:\n%s", ds, sens.pivot(index="choice", columns="generator", values="displaced_share").round(3).to_string())

    rdir = out_dir(cfg, "recourse", ds, args.variant)
    if (rdir / f"transfer_{rule}.parquet").exists():
        transfer = pd.read_parquet(rdir / f"transfer_{rule}.parquet")
        cfs = pd.read_parquet(rdir / f"counterfactuals_{rule}.parquet")
        summ = pd.read_parquet(rdir / f"summary_{rule}.parquet")
        review["validity"] = validity_with_ci(transfer, acfg["n_bootstrap"], acfg["bootstrap_seed"])
        if "validity_strict" not in summ:   # summaries written before Spec 16.13: strict = found validity x share ok
            summ["validity_strict"] = summ["validity"].fillna(0.0) * summ["share_ok"]
        review["validity_strict"] = {(r.condition if r.condition != "S" else r.generator): float(r.validity_strict) for r in summ.itertuples()}
        review["status_shares"] = {(r.condition if r.condition != "S" else r.generator): {"no_cf": float(r.share_no_cf), "margin_fail": float(r.share_margin_fail), "ok": float(r.share_ok), "n_attempted": int(r.n_attempted)} for r in summ.itertuples()}
        from src.common import columns_info
        cols = columns_info(cfg, ds)
        review["validity_at_margin_ratio"] = validity_at_margins(cfs, load_registry(cfg, ds, args.variant), thr, cols["inputs"], (0.7, 0.8))
        fig_validity(review["validity"], review["validity_strict"], fdir / f"fig_validity_{ds}", ds)
        log.info("%s validity (found / strict): %s", ds, {k: (round(v["validity"], 3), round(review["validity_strict"].get(k, float("nan")), 3)) for k, v in review["validity"].items()})

    ov = pd.read_csv(tdir / f"table5_overlap_{ds}_{rule}.csv", index_col=0)
    fig_overlap(ov, fdir / f"fig_overlap_{ds}", ds)
    review["example"] = choose_example(expl, disp, adv, K)
    log.info("%s example: %s", ds, {k: v for k, v in review["example"].items() if k in ("person", "generator", "D", "rule", "shared_reasons")})
    write_json(review, tdir / f"review_{ds}_{rule}.json")

if gen_rows:
    allg = pd.concat(gen_rows, ignore_index=True)
    pooled = {c: float(spearmanr(allg[c], allg.displaced_share)[0]) for c in CHECKS}
    write_json({"n": len(allg), "spearman": pooled}, tdir / f"review_gen_level_pooled_{rule}.json")
    log.info("pooled generator-level rho (n=%d): %s", len(allg), {k: round(v, 3) for k, v in pooled.items()})
log.info("stage 09 done")
