#!/usr/bin/env bash
# Stages 03-08 for the main variant, then the robustness variants. Run after stage 02 has produced all synthetic data.
set -uo pipefail
cd "$(dirname "$0")/.."
PY=${PY:-.venv/bin/python}
NJ=${NJ:-20}
FORCE=${FORCE:-}          # set FORCE=--force to recompute every stage
VARIANTS=${VARIANTS:-"main rebal sub06 sub10 lr"}
RECOURSE_VARIANTS=${RECOURSE_VARIANTS:-"main rebal"}   # DiCE is the slowest stage; robustness variants do not need it (Spec 9.4)
mkdir -p outputs/logs
for V in $VARIANTS; do
  for S in 03_train_models 04_explain 06_quality_checks 05_recourse 07_analysis 08_figures; do
    if [ "$S" = "05_recourse" ] && ! echo " $RECOURSE_VARIANTS " | grep -q " $V "; then echo "=== skip $V $S" | tee -a outputs/logs/chain.out; continue; fi
    echo "=== $(date +%H:%M:%S) $V $S" | tee -a outputs/logs/chain.out
    extra=""; [ "$S" = "04_explain" ] && extra="--n-jobs $NJ"
    $PY scripts/$S.py --variant "$V" $extra $FORCE > "outputs/logs/${S}_${V}.out" 2>&1
    rc=$?
    echo "=== $(date +%H:%M:%S) $V $S exit $rc" | tee -a outputs/logs/chain.out
    if [ $rc -ne 0 ]; then echo "FAILED $V $S" | tee -a outputs/logs/chain.out; [ "$V" = "main" ] && exit 1; break; fi
  done
done
echo "=== ALL DONE $(date +%H:%M:%S)" | tee -a outputs/logs/chain.out
