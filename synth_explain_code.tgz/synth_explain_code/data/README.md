# Data sources and licenses

Raw files live in `data/raw/` and are not committed. `scripts/01_prepare_data.py` downloads them.

## HELOC (FICO Explainable Machine Learning Challenge)
- Original release: FICO xML Challenge, https://community.fico.com/s/explainable-machine-learning-challenge.
  The original license requires accepting FICO's data usage agreement on that site. Record the date you accepted it here: ________.
- The loader tries, in order: a local `data/raw/heloc_dataset_v1.csv`, then the Hugging Face mirror `mstz/heloc` (`risk/train.csv`, license tag CC),
  which is the full 10,459-row release with columns renamed in the original order; the loader restores the FICO names positionally and
  maps `is_at_risk` 1 -> Bad (5,459 Bad / 5,000 Good, matching FICO's counts).
  If you obtained the file from FICO directly, place it at `data/raw/heloc_dataset_v1.csv` so no mirror is used.
- Not used: OpenML ids 45023 and 45026 are modified 10,000-row balanced subsets without `MaxDelqEver`.
- 10,459 rows, 23 integer features, target `RiskPerformance` in {Good, Bad}. Adverse = Bad.
- Special values: -9 no bureau record, -8 no usable values, -7 condition not met. Handling: Spec 2.1 and 16.1.

## Taiwan default of credit card clients
- UCI Machine Learning Repository id 350, https://archive.ics.uci.edu/dataset/350 (CC BY 4.0).
  Yeh, I-C., Lien, C.-H. (2009). The comparisons of data mining techniques for the predictive accuracy of probability of default of credit card clients.
- Loaded via `ucimlrepo` (id 350) with a fallback to the UCI static zip (`default of credit card clients.xls`).
- 30,000 rows, 23 features, target `default payment next month`. Adverse = 1.
- Cleaning: EDUCATION {0,5,6} -> 4, MARRIAGE 0 -> 3. SEX and MARRIAGE are not model inputs.

## Processed outputs (stage 01)
`data/<dataset>/{train,validation,audit}.parquet` with columns: `id`, model-input features (including `<feature>_na` indicators), aux columns, `y`.
`data/<dataset>/columns.json` lists which columns are inputs, aux, and target. `data/<dataset>/preprocess.json` stores train medians.
