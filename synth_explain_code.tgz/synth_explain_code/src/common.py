"""Shared helpers: config, paths, logging, seeding, provenance, caching."""
from __future__ import annotations

import hashlib
import json
import logging
import os
import random
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]


def load_config(path: str | Path | None = None) -> dict:
    path = Path(path) if path else ROOT / "config.yaml"
    with open(path) as f:
        cfg = yaml.safe_load(f)
    cfg["_root"] = str(ROOT)
    return cfg


def out_dir(cfg: dict, *parts: str) -> Path:
    p = ROOT / cfg["paths"]["outputs"]
    for part in parts:
        p = p / part
    p.mkdir(parents=True, exist_ok=True)
    return p


def data_dir(cfg: dict, dataset: str | None = None) -> Path:
    p = ROOT / cfg["paths"]["data"]
    if dataset:
        p = p / dataset
    p.mkdir(parents=True, exist_ok=True)
    return p


def setup_logging(cfg: dict, stage: str) -> logging.Logger:
    log_dir = out_dir(cfg, "logs")
    fmt = "%(asctime)s %(levelname)s %(name)s: %(message)s"
    handlers = [logging.StreamHandler(sys.stdout),
                logging.FileHandler(log_dir / f"{stage}_{time.strftime('%Y%m%d_%H%M%S')}.log")]
    logging.basicConfig(level=getattr(logging, cfg.get("logging", {}).get("level", "INFO")),
                        format=fmt, handlers=handlers, force=True)
    log = logging.getLogger(stage)
    log.info("python %s", sys.version.split()[0])
    log.info("git %s", git_hash())
    try:   # environment record without relying on pip (uv venvs have none): installed distributions via importlib
        import importlib.metadata as md
        freeze = "\n".join(sorted(f"{d.metadata['Name']}=={d.version}" for d in md.distributions() if d.metadata["Name"])) + "\n"
        (log_dir / f"pip_freeze_{stage}.txt").write_text(freeze)
    except Exception as e:  # pragma: no cover
        log.warning("environment freeze failed: %s", e)
    return log


def git_hash() -> str:
    try:
        return subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=ROOT, capture_output=True,
                              text=True, timeout=10).stdout.strip() or "nogit"
    except Exception:
        return "nogit"


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass


def provenance(cfg: dict, **kw: Any) -> dict:
    d = {"git": git_hash(), "time": time.strftime("%Y-%m-%dT%H:%M:%S")}
    d.update(kw)
    return d


def write_json(obj: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2, default=_json_default)


def read_json(path: Path) -> Any:
    with open(path) as f:
        return json.load(f)


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, Path):
        return str(o)
    return str(o)


def exists_and_not_forced(path: Path, force: bool, log: logging.Logger | None = None) -> bool:
    if path.exists() and not force:
        if log:
            log.info("cached: %s", path)
        return True
    return False


def row_hashes(df: pd.DataFrame, cols: list[str]) -> pd.Series:
    """Stable per-row hash over the given columns (used for leakage checks)."""
    sub = df[cols].astype(float).round(6)
    return pd.util.hash_pandas_object(sub, index=False)


def load_meta(cfg: dict, dataset: str) -> dict:
    with open(data_dir(cfg, dataset) / "meta.yaml") as f:
        return yaml.safe_load(f)


def columns_info(cfg: dict, dataset: str) -> dict:
    return read_json(data_dir(cfg, dataset) / "columns.json")


def load_split(cfg: dict, dataset: str, split: str) -> pd.DataFrame:
    return pd.read_parquet(data_dir(cfg, dataset) / f"{split}.parquet")


def model_id(condition: str, generator: str | None = None, gen_seed: int | None = None, model_seed: int = 0,
             bootstrap_seed: int | None = None) -> str:
    if condition == "R":
        return f"R_m{model_seed}"
    if condition == "B":
        return f"B_b{bootstrap_seed}_m{model_seed}"
    return f"S_{generator}_g{gen_seed}_m{model_seed}"


def parse_model_id(mid: str) -> dict:
    parts = mid.split("_")
    if parts[0] == "R":
        return {"condition": "R", "generator": None, "gen_seed": None, "model_seed": int(parts[1][1:]), "bootstrap_seed": None}
    if parts[0] == "B":
        return {"condition": "B", "generator": None, "gen_seed": None, "model_seed": int(parts[2][1:]),
                "bootstrap_seed": int(parts[1][1:])}
    gen = "_".join(parts[1:-2])
    return {"condition": "S", "generator": gen, "gen_seed": int(parts[-2][1:]), "model_seed": int(parts[-1][1:]),
            "bootstrap_seed": None}


class Timer:
    def __enter__(self):
        self.t0 = time.time()
        return self

    def __exit__(self, *a):
        self.seconds = time.time() - self.t0


def generator_seeds(cfg: dict, dataset: str, generator: str) -> list[int]:
    """Generator seeds used for one dataset/generator (Spec 16.13). Default range(n_generator_seeds); a per-dataset
    override replaces a generator seed whose run collapsed (the failed set stays on disk and is not used)."""
    over = cfg["generators"].get("seed_overrides", {}) or {}
    if dataset in over and generator in over[dataset]:
        return [int(x) for x in over[dataset][generator]]
    return list(range(cfg["conditions"]["n_generator_seeds"]))
