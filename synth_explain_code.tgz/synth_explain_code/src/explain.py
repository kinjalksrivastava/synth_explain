"""Stage 04: SHAP values, decisions, reason codes (Spec 7.1, 16.1, 16.2)."""
from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import pandas as pd
import shap
from xgboost import XGBClassifier

from .common import load_split, out_dir

log = logging.getLogger("explain")


def background(cfg: dict, dataset: str, cols: dict) -> pd.DataFrame:
    """200 rows from real Train, seed 42, shared by every model (Spec 7.1)."""
    train = load_split(cfg, dataset, "train")
    s = cfg["shap"]
    return train[cols["inputs"]].sample(n=min(s["background_size"], len(train)), random_state=s["background_seed"])


def shap_xgb(model: XGBClassifier, X: pd.DataFrame, bg: pd.DataFrame, cfg: dict) -> tuple[np.ndarray, float]:
    """Interventional TreeSHAP in log-odds. Returns (n, p) values and the expected value."""
    if cfg["shap"].get("fallback_native_pred_contribs"):
        import xgboost as xgb
        contrib = model.get_booster().predict(xgb.DMatrix(X), pred_contribs=True)
        return contrib[:, :-1], float(contrib[0, -1])
    # shap.Explainer wraps a DataFrame background in maskers.Independent(max_samples=100), which would silently drop
    # half of the 200 configured rows; pass the masker explicitly with the cap at the background size (Spec 16.13).
    masker = shap.maskers.Independent(bg, max_samples=len(bg))
    ex = shap.TreeExplainer(model, data=masker, feature_perturbation=cfg["shap"]["feature_perturbation"],
                            model_output="raw")
    vals = ex.shap_values(X, check_additivity=False)
    if isinstance(vals, list):
        vals = vals[-1]
    ev = ex.expected_value
    ev = float(np.atleast_1d(ev)[-1])
    return np.asarray(vals), ev


def shap_lr(pipe, X: pd.DataFrame, bg: pd.DataFrame, cols: dict) -> tuple[np.ndarray, float]:
    """Exact linear SHAP: coef * (x - mean_background) in the transformed space, summed back to original inputs."""
    prep, lr = pipe.named_steps["prep"], pipe.named_steps["lr"]
    Xt = prep.transform(X)
    Bt = prep.transform(bg)
    names = list(prep.get_feature_names_out())
    coef = lr.coef_.ravel()
    mu = Bt.mean(axis=0)
    contrib = (Xt - mu) * coef  # (n, p_transformed)
    ev = float(lr.intercept_[0] + mu @ coef)
    out = np.zeros((len(X), len(cols["inputs"])))
    pos = {c: i for i, c in enumerate(cols["inputs"])}
    for j, nm in enumerate(names):
        parent = nm if nm in pos else next(c for c in cols["inputs"] if nm.startswith(c + "_"))
        out[:, pos[parent]] += contrib[:, j]
    return out, ev


def shap_values(model, X: pd.DataFrame, bg: pd.DataFrame, cols: dict, cfg: dict) -> tuple[np.ndarray, float]:
    if isinstance(model, XGBClassifier):
        return shap_xgb(model, X, bg, cfg)
    return shap_lr(model, X, bg, cols)


def merge_indicators(vals: np.ndarray, cols: dict, cfg: dict) -> np.ndarray:
    """(n, n_inputs) -> (n, n_features): add each <f>_na column's SHAP to its parent f (Spec 16.1)."""
    feats, inputs = cols["features"], cols["inputs"]
    out = np.zeros((vals.shape[0], len(feats)))
    fpos = {f: i for i, f in enumerate(feats)}
    for j, c in enumerate(inputs):
        if c in fpos:
            out[:, fpos[c]] += vals[:, j]
        elif cfg["reasons"]["merge_missing_indicators"]:
            out[:, fpos[c[:-3]]] += vals[:, j]
        # else: indicator dropped from reason ranking
    return out


def reason_membership(vals: np.ndarray, k: int, min_shap: float = 0.0) -> np.ndarray:
    """Boolean (n, p): feature is among the top-k positive SHAP features (Spec 7.1)."""
    n, p = vals.shape
    order = np.argsort(-vals, axis=1)[:, :k]
    member = np.zeros((n, p), dtype=bool)
    rows = np.repeat(np.arange(n), k)
    member[rows, order.ravel()] = True
    member &= vals > min_shap
    return member


def reason_table(vals: np.ndarray, adverse: np.ndarray, person_ids: np.ndarray, features: list[str], k: int,
                 min_shap: float, mid: str) -> pd.DataFrame:
    """Long format reason codes for adverse persons under one model."""
    idx = np.where(adverse)[0]
    order = np.argsort(-vals[idx], axis=1)[:, :k]
    rows = []
    for r, i in enumerate(idx):
        for rank in range(k):
            j = order[r, rank]
            if vals[i, j] > min_shap:
                rows.append((mid, int(person_ids[i]), rank + 1, features[j], float(vals[i, j])))
    return pd.DataFrame(rows, columns=["model_id", "person", "rank", "feature", "shap"])


# ----------------------------------------------------------------------------- decisions
def thresholds(prob: dict[str, np.ndarray], registry: pd.DataFrame, cfg: dict) -> dict[str, dict[str, float]]:
    """Per rule, per model threshold. quantile: every model rejects the mean R share at 0.5 (Spec 16.2)."""
    t_fixed = float(cfg["decision"]["fixed_threshold"])
    r_ids = registry.loc[registry.condition == "R", "model_id"].tolist()
    reject_share = float(np.mean([np.mean(prob[m] >= t_fixed) for m in r_ids]))
    out = {"fixed": {m: t_fixed for m in prob}, "quantile": {}}
    for m, p in prob.items():
        out["quantile"][m] = float(np.quantile(p, 1.0 - reject_share)) if reject_share > 0 else np.inf
    out["_reject_share_R"] = reject_share
    return out


def shap_dir(cfg: dict, dataset: str, variant: str) -> Path:
    return out_dir(cfg, "shap", dataset, variant)
