"""Stage 03: tuning on real data, then training R, B and S models under one frozen setting (Spec 4, 6, 16.9)."""
from __future__ import annotations

import itertools
import logging
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from xgboost import XGBClassifier

from .common import generator_seeds, load_split, model_id, out_dir, read_json, write_json

log = logging.getLogger("models")


def variant_cfg(cfg: dict, variant: str) -> dict:
    return cfg["variants"][variant]


def categorical_inputs(cols: dict, meta: dict) -> list[str]:
    return [c for c in cols["features"] if meta["features"][c]["type"] == "categorical"]


# ----------------------------------------------------------------------------- XGBoost
def xgb_params(cfg: dict, variant: str, tuned: dict, seed: int) -> dict:
    v = variant_cfg(cfg, variant)
    return dict(objective=cfg["xgboost"]["objective"], tree_method=cfg["xgboost"]["tree_method"],
                subsample=float(v["subsample"]), colsample_bytree=float(v["colsample_bytree"]),
                max_depth=int(tuned["max_depth"]), learning_rate=float(tuned["learning_rate"]),
                n_estimators=int(tuned["n_estimators"]), random_state=int(seed), n_jobs=4, verbosity=0)


def tune_xgb(cfg: dict, dataset: str, variant: str, cols: dict) -> dict:
    train, val = load_split(cfg, dataset, "train"), load_split(cfg, dataset, "validation")
    X, y = train[cols["inputs"]], train["y"]
    Xv, yv = val[cols["inputs"]], val["y"]
    grid = cfg["xgboost"]["grid"]
    rows = []
    for md, lr, ne in itertools.product(grid["max_depth"], grid["learning_rate"], grid["n_estimators"]):
        tuned = {"max_depth": md, "learning_rate": lr, "n_estimators": ne}
        clf = XGBClassifier(**xgb_params(cfg, variant, tuned, seed=0))
        clf.fit(X, y)
        auc = roc_auc_score(yv, clf.predict_proba(Xv)[:, 1])
        rows.append({**tuned, "val_auc": auc})
        log.info("tune %s %s %s -> val AUC %.4f", dataset, variant, tuned, auc)
    df = pd.DataFrame(rows).sort_values("val_auc", ascending=False)
    best = df.iloc[0][["max_depth", "learning_rate", "n_estimators"]].to_dict()
    best = {"max_depth": int(best["max_depth"]), "learning_rate": float(best["learning_rate"]),
            "n_estimators": int(best["n_estimators"]), "val_auc": float(df.iloc[0]["val_auc"])}
    df.to_csv(out_dir(cfg, "models", dataset) / f"tuning_grid_{variant}.csv", index=False)
    return best


def train_xgb(cfg: dict, variant: str, tuned: dict, X: pd.DataFrame, y: pd.Series, seed: int) -> XGBClassifier:
    clf = XGBClassifier(**xgb_params(cfg, variant, tuned, seed))
    clf.fit(X, y)
    return clf


# ----------------------------------------------------------------------------- Logistic regression
def lr_pipeline(cols: dict, meta: dict, C: float, seed: int) -> Pipeline:
    cats = categorical_inputs(cols, meta)
    nums = [c for c in cols["inputs"] if c not in cats]
    ct = ColumnTransformer([("num", StandardScaler(), nums),
                            ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), cats)],
                           verbose_feature_names_out=False)
    return Pipeline([("prep", ct), ("lr", LogisticRegression(C=C, penalty="l2", max_iter=2000, random_state=seed))])


def tune_lr(cfg: dict, dataset: str, cols: dict, meta: dict) -> dict:
    train, val = load_split(cfg, dataset, "train"), load_split(cfg, dataset, "validation")
    rows = []
    for C in cfg["logistic"]["grid"]["C"]:
        pipe = lr_pipeline(cols, meta, C, seed=0).fit(train[cols["inputs"]], train["y"])
        auc = roc_auc_score(val["y"], pipe.predict_proba(val[cols["inputs"]])[:, 1])
        rows.append({"C": C, "val_auc": auc})
        log.info("tune LR %s C=%s -> val AUC %.4f", dataset, C, auc)
    df = pd.DataFrame(rows).sort_values("val_auc", ascending=False)
    df.to_csv(out_dir(cfg, "models", dataset) / "tuning_grid_lr.csv", index=False)
    return {"C": float(df.iloc[0]["C"]), "val_auc": float(df.iloc[0]["val_auc"])}


def train_lr(cols: dict, meta: dict, tuned: dict, X: pd.DataFrame, y: pd.Series, seed: int) -> Pipeline:
    """LR is deterministic given the data; the seed only enters through the data (B, S conditions)."""
    return lr_pipeline(cols, meta, tuned["C"], seed).fit(X, y)


# ----------------------------------------------------------------------------- generic
def tuned_params_path(cfg: dict, dataset: str, variant: str) -> Path:
    return out_dir(cfg, "models", dataset) / f"tuned_{variant}.json"


def get_tuned(cfg: dict, dataset: str, variant: str, cols: dict, meta: dict, force: bool = False) -> dict:
    p = tuned_params_path(cfg, dataset, variant)
    if p.exists() and not force:
        return read_json(p)
    fam = variant_cfg(cfg, variant)["family"]
    if fam != "logistic" and variant != "main":
        # Spec 16.14: the tree configuration is chosen once per dataset (main variant) and frozen for every tree variant,
        # so that variants differ only in the setting under study
        pm = tuned_params_path(cfg, dataset, "main")
        tuned = read_json(pm) if pm.exists() else tune_xgb(cfg, dataset, "main", cols)
    else:
        tuned = tune_lr(cfg, dataset, cols, meta) if fam == "logistic" else tune_xgb(cfg, dataset, variant, cols)
    write_json(tuned, p)
    log.info("frozen hyperparameters %s %s: %s", dataset, variant, tuned)
    return tuned


def fit_model(cfg: dict, variant: str, tuned: dict, cols: dict, meta: dict, X: pd.DataFrame, y: pd.Series, seed: int):
    fam = variant_cfg(cfg, variant)["family"]
    if fam == "logistic":
        return train_lr(cols, meta, tuned, X, y, seed)
    return train_xgb(cfg, variant, tuned, X, y, seed)


def save_model(model, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(model, XGBClassifier):
        path = path.with_suffix(".json")
        model.save_model(path)
    else:
        path = path.with_suffix(".joblib")
        joblib.dump(model, path)
    return path


def resolve_output_path(path: str | Path) -> Path:
    """Registry paths may be absolute paths from another machine; remap anything under 'outputs/' to this repo."""
    from .common import ROOT
    path = Path(path)
    if path.exists():
        return path
    parts = path.parts
    if "outputs" in parts:
        cand = ROOT.joinpath(*parts[parts.index("outputs"):])
        if cand.exists():
            return cand
    return path


def load_model(path: str | Path):
    path = resolve_output_path(path)
    if path.suffix == ".json":
        m = XGBClassifier()
        m.load_model(path)
        return m
    return joblib.load(path)


def predict_proba(model, X: pd.DataFrame) -> np.ndarray:
    return model.predict_proba(X)[:, 1]


# ----------------------------------------------------------------------------- training sets
def rebalance_to(df: pd.DataFrame, target_ratio: float, n: int, seed: int) -> tuple[pd.DataFrame, dict]:
    """Resample a synthetic set to n rows at the real class ratio (Spec 16.11). Without replacement within a class
    when it has enough rows, with replacement otherwise; the share of duplicated rows is returned."""
    rng = np.random.default_rng(seed)
    n_pos = int(round(target_ratio * n))
    parts, dup = [], 0
    for label, k in ((1, n_pos), (0, n - n_pos)):
        pool = df[df["y"] == label]
        if len(pool) >= k:
            idx = rng.choice(len(pool), size=k, replace=False)
        else:  # keep every unique row, then top up with replacement; every topped-up row is a duplicate
            idx = np.concatenate([np.arange(len(pool)), rng.choice(len(pool), size=k - len(pool), replace=True)])
            dup += k - len(pool)
        parts.append(pool.iloc[idx])
    out = pd.concat(parts).sample(frac=1.0, random_state=seed).reset_index(drop=True)
    return out, {"rebalanced_from_ratio": float(df["y"].mean()), "rebalanced_to_ratio": float(out["y"].mean()),
                 "share_duplicated_rows": dup / n}


def iter_training_sets(cfg: dict, dataset: str, cols: dict, generators: list[str] | None = None, variant: str = "main"):
    """Yield (model_id, info, X, y) for every model in every condition (Spec 4)."""
    ccfg = cfg["conditions"]
    rebalance = bool(cfg["variants"][variant].get("rebalance_synthetic", False))
    train = load_split(cfg, dataset, "train")
    Xtr, ytr = train[cols["inputs"]], train["y"]
    for s in range(ccfg["n_real_seeds"]):
        yield model_id("R", model_seed=s), {"condition": "R", "generator": None, "gen_seed": None, "model_seed": s,
                                             "bootstrap_seed": None}, Xtr, ytr
    for b in range(ccfg["n_bootstrap"]):
        rng = np.random.default_rng(b)
        idx = rng.integers(0, len(train), size=len(train))
        yield model_id("B", bootstrap_seed=b, model_seed=b), {"condition": "B", "generator": None, "gen_seed": None,
                                                              "model_seed": b, "bootstrap_seed": b}, \
            Xtr.iloc[idx].reset_index(drop=True), ytr.iloc[idx].reset_index(drop=True)
    gens = generators or cfg["generators"]["list"]
    for g in gens:
        for gs in generator_seeds(cfg, dataset, g):
            p = out_dir(cfg, "synthetic", dataset, g) / f"seed{gs}.parquet"
            if not p.exists():
                log.warning("missing synthetic data %s; skipping", p)
                continue
            synth = pd.read_parquet(p)
            extra = {}
            if rebalance:
                synth, extra = rebalance_to(synth, float(ytr.mean()), len(train), seed=gs)
                log.info("%s %s seed %d rebalanced: %s", dataset, g, gs, extra)
            for ms in range(ccfg["n_model_seeds_per_generator"]):
                yield model_id("S", generator=g, gen_seed=gs, model_seed=ms), \
                    {"condition": "S", "generator": g, "gen_seed": gs, "model_seed": ms, "bootstrap_seed": None, **extra}, \
                    synth[cols["inputs"]], synth["y"]


def registry_path(cfg: dict, dataset: str, variant: str) -> Path:
    return out_dir(cfg, "models", dataset) / f"registry_{variant}.parquet"


def load_registry(cfg: dict, dataset: str, variant: str) -> pd.DataFrame:
    return pd.read_parquet(registry_path(cfg, dataset, variant))
