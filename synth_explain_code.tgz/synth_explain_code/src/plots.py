"""Stage 08: paper figures (Spec 13, 16.7). Matplotlib, print-safe, one axis per panel.
Generator hues are assigned in a fixed order from a colorblind-validated palette; baselines are gray."""
from __future__ import annotations

import logging
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import numpy as np
import pandas as pd

log = logging.getLogger("plots")

GEN_ORDER = ["gaussian_copula", "copulagan", "ctgan", "tvae", "tabddpm"]
GEN_COLORS = {"gaussian_copula": "#2a78d6", "copulagan": "#eb6834", "ctgan": "#1baf7a", "tvae": "#eda100",
              "tabddpm": "#e87ba4"}
GEN_LABEL = {"gaussian_copula": "GaussianCopula", "copulagan": "CopulaGAN", "ctgan": "CTGAN", "tvae": "TVAE",
             "tabddpm": "TabDDPM"}
DATASET_MARKER = {"heloc": "o", "taiwan": "s"}
GRAY_R, GRAY_B, INK, MUTED, GRID = "#52514e", "#898781", "#0b0b0b", "#898781", "#e1e0d9"
# light sequential palette for heatmaps: text stays black on every cell
LIGHT_SEQ = LinearSegmentedColormap.from_list("light_seq", ["#f6fbfd", "#d5ecf3", "#a9d6e5", "#7fc0d6"])

plt.rcParams.update({"font.size": 9, "axes.edgecolor": "#c3c2b7", "axes.labelcolor": INK, "xtick.color": MUTED,
                     "ytick.color": MUTED, "axes.spines.top": False, "axes.spines.right": False,
                     "grid.color": GRID, "grid.linewidth": 0.6, "legend.frameon": False, "figure.dpi": 150})


def _gens(df: pd.DataFrame) -> list[str]:
    present = set(df.generator.unique())
    return [g for g in GEN_ORDER if g in present] + sorted(present - set(GEN_ORDER))


def _save(fig, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(path.with_suffix(".png"), bbox_inches="tight")
    plt.close(fig)
    log.info("wrote %s", path)


def _heat(ax, M: np.ndarray, labels: list[str], fontsize: float = 7):
    """Light heatmap with black cell labels and white separators."""
    ax.imshow(M, cmap=LIGHT_SEQ, vmin=0, vmax=1, aspect="equal")
    n = len(labels)
    ax.set_xticks(range(n)); ax.set_yticks(range(n))
    ax.set_xticklabels(labels, rotation=45, ha="right", fontsize=fontsize)
    ax.set_yticklabels(labels, fontsize=fontsize)
    ax.set_xticks(np.arange(-0.5, n, 1), minor=True); ax.set_yticks(np.arange(-0.5, n, 1), minor=True)
    ax.grid(which="minor", color="white", lw=1.5); ax.grid(which="major", visible=False)
    ax.tick_params(which="both", length=0, colors=INK)
    for i in range(n):
        for j in range(n):
            ax.text(j, i, f"{M[i, j]:.2f}", ha="center", va="center", fontsize=fontsize, color="black")
    for sp in ax.spines.values():
        sp.set_visible(False)


def fig_money(rq2: pd.DataFrame, cfg: dict, path: Path):
    """Figure 2: displaced share vs TSTR AUC gap; color = generator, marker = dataset."""
    fig, ax = plt.subplots(figsize=(5.2, 3.6))
    for g in _gens(rq2):
        for ds, sub in rq2[rq2.generator == g].groupby("dataset"):
            ax.scatter(sub.tstr_auc_gap, sub.displaced_share, s=42, color=GEN_COLORS.get(g, INK),
                       marker=DATASET_MARKER.get(ds, "o"), edgecolor="white", linewidth=0.8, label=f"{GEN_LABEL.get(g, g)} / {ds}")
    r2 = cfg["rq2"]
    ax.axvline(r2["hidden_failure_auc_gap"], color=GRID, lw=1, ls="--")
    ax.axhline(r2["hidden_failure_displaced_share"], color=GRID, lw=1, ls="--")
    ax.text(r2["hidden_failure_auc_gap"], ax.get_ylim()[1], " passes TSTR gate", color=MUTED, va="top", fontsize=7)
    ax.set_xlabel("TSTR AUC gap (real minus synthetic-trained)")
    ax.set_ylabel("Displaced share of rejected applicants")
    ax.grid(True, axis="y")
    ax.legend(fontsize=6.5, ncol=2, loc="upper left", bbox_to_anchor=(1.0, 1.0))
    _save(fig, path)


def fig_distributions(person: pd.DataFrame, metric: str, path: Path, dataset: str):
    """Figure 3: distribution of agreement under R-R, B-R and each S-R, and of D_g."""
    gens = [g for g in GEN_ORDER if f"{metric}__SR_{g}" in person]
    fig, axes = plt.subplots(1, 2, figsize=(8, 3.2))
    ax = axes[0]
    series = [("R-R", person[f"{metric}__RR"], GRAY_R), ("B-R", person[f"{metric}__BR"], GRAY_B)]
    series += [(GEN_LABEL[g], person[f"{metric}__SR_{g}"], GEN_COLORS[g]) for g in gens]
    bins = np.linspace(0, 1, 21)
    for label, s, c in series:
        ax.hist(s.dropna(), bins=bins, histtype="step", lw=1.6, color=c, label=label, density=True)
    ax.set_xlabel("Mean top-3 Jaccard per person")
    ax.set_ylabel("Density")
    ax.set_title(f"{dataset}: agreement with real models", fontsize=9, loc="left")
    ax.legend(fontsize=7)
    ax = axes[1]
    for g in gens:
        d = person[f"D_{metric}__{g}"].dropna()
        ax.hist(d, bins=np.linspace(-0.6, 0.8, 36), histtype="step", lw=1.6, color=GEN_COLORS[g], label=GEN_LABEL[g], density=True)
    ax.axvline(0, color=GRAY_R, lw=1)
    ax.set_xlabel("Displacement D_g(i) = A_BR - A_SR (Jaccard)")
    ax.set_title("displacement beyond bootstrap baseline", fontsize=9, loc="left")
    ax.legend(fontsize=7)
    _save(fig, path)


def fig_h3(long: pd.DataFrame, subgroups: pd.DataFrame, path: Path, dataset: str):
    """Figure 4: binned D by rarity and boundary proximity, per generator; subgroup displaced shares."""
    gens = _gens(long)
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.2))
    for ax, pred, lab in ((axes[0], "rarity", "Rarity (mean 10-NN distance), decile"),
                          (axes[1], "boundary", "Boundary proximity |p - 0.5|, decile")):
        for g in gens:
            sub = long[long.generator == g].copy()
            if sub.empty:
                continue
            sub["bin"] = pd.qcut(sub[pred], 10, labels=False, duplicates="drop")
            m = sub.groupby("bin").D.mean()
            ax.plot(m.index + 1, m.values, marker="o", ms=4, lw=1.6, color=GEN_COLORS.get(g, INK), label=GEN_LABEL.get(g, g))
        ax.axhline(0, color=GRAY_R, lw=0.8)
        ax.set_xlabel(lab)
        ax.set_ylabel("Mean D_g(i)")
        ax.grid(True, axis="y")
    axes[0].legend(fontsize=7)
    ax = axes[2]
    if subgroups is not None and not subgroups.empty:
        sg = subgroups.copy()
        sg["key"] = sg.subgroup + "=" + sg.level.astype(str)
        keys = list(dict.fromkeys(sg.key))
        width = 0.8 / max(len(gens), 1)
        for gi, g in enumerate(gens):
            s = sg[sg.generator == g].set_index("key").reindex(keys)
            x = np.arange(len(keys)) + gi * width
            ax.bar(x, s.displaced_share, width=width * 0.9, color=GEN_COLORS.get(g, INK),
                   yerr=[s.displaced_share - s.ci_low, s.ci_high - s.displaced_share], error_kw={"lw": 0.8, "ecolor": MUTED})
        ax.set_xticks(np.arange(len(keys)) + width * (len(gens) - 1) / 2)
        ax.set_xticklabels(keys, rotation=45, ha="right", fontsize=7)
        ax.set_ylabel("Displaced share")
        ax.grid(True, axis="y")
    fig.suptitle(f"{dataset}: who is displaced", fontsize=9, x=0.01, ha="left")
    _save(fig, path)


def fig_worked_example(ex: dict, path: Path, dataset: str):
    """Figure 5: the same rejected applicant, top reasons under a real and a synthetic-trained model."""
    if not ex:
        return
    fig, axes = plt.subplots(1, 2, figsize=(8.5, 2.8), sharex=True)
    fig.subplots_adjust(wspace=0.85, top=0.78)
    for ax, key, color in ((axes[0], "real", GRAY_R), (axes[1], "synthetic", GEN_COLORS.get(ex["generator"], INK))):
        reasons = ex[key]["reasons"]
        names = [r[0] for r in reasons][::-1]
        vals = [r[1] for r in reasons][::-1]
        ax.barh(names, vals, color=color, height=0.55)
        ax.set_title(f"{key} model ({ex[key]['model']}), p(adverse)={ex[key]['prob']:.2f}", fontsize=8, loc="left")
        ax.set_xlabel("SHAP (log-odds toward rejection)")
        ax.tick_params(axis="y", labelsize=7)
    fig.suptitle(f"{dataset}: applicant {ex['person']}, generator {GEN_LABEL.get(ex['generator'], ex['generator'])}",
                 fontsize=9, x=0.01, y=0.99, ha="left")
    _save(fig, path)


def fig_generator_dependence(overlap: pd.DataFrame, slopes: pd.DataFrame, path: Path, dataset: str):
    """Figure 6: (a) overlap of displaced sets across generators, (b) per-generator Spearman slopes."""
    fig, axes = plt.subplots(1, 2, figsize=(8.4, 3.4), gridspec_kw={"width_ratios": [1.1, 1]})
    ax = axes[0]
    gens = [g for g in GEN_ORDER if g in overlap.index]
    M = overlap.loc[gens, gens].astype(float)
    _heat(ax, M.values, [GEN_LABEL[g] for g in gens])
    ax.set_title("(a) Jaccard between displaced sets", fontsize=9, loc="left")
    ax = axes[1]
    if slopes is not None and not slopes.empty:
        preds = list(dict.fromkeys(slopes.predictor))
        width = 0.8 / max(len(gens), 1)
        for gi, g in enumerate(gens):
            s = slopes[slopes.generator == g].set_index("predictor").reindex(preds)
            ax.bar(np.arange(len(preds)) + gi * width, s.spearman_rho, width=width * 0.9, color=GEN_COLORS[g], label=GEN_LABEL[g])
        ax.set_xticks(np.arange(len(preds)) + width * (len(gens) - 1) / 2)
        ax.set_xticklabels(preds)
        ax.axhline(0, color=GRAY_R, lw=0.8)
        ax.set_ylabel("Spearman rho with D_g(i)")
        ax.legend(fontsize=7)
        ax.grid(True, axis="y")
    ax.set_title("(b) who is displaced, by generator", fontsize=9, loc="left")
    fig.suptitle(dataset, fontsize=9, x=0.01, ha="left")
    _save(fig, path)


def fig_validity(validity: dict, strict: dict, path: Path, dataset: str):
    """Recourse validity by source condition: share of real-trained models accepting a counterfactual, among
    counterfactuals found (bars with 95% person-bootstrap intervals) and with failures counted as invalid (ticks)."""
    order = ["R", "B"] + [g for g in GEN_ORDER if g in validity]
    labels = {"R": "Real", "B": "Bootstrap", **GEN_LABEL}
    fig, ax = plt.subplots(figsize=(5.2, 2.9))
    x = np.arange(len(order))
    vals = [validity[k]["validity"] for k in order]
    err = np.clip(np.array([[validity[k]["validity"] - validity[k]["ci_low"], validity[k]["ci_high"] - validity[k]["validity"]] for k in order]).T, 0, None)
    colors = [GRAY_R if k == "R" else GRAY_B if k == "B" else GEN_COLORS.get(k, INK) for k in order]
    ax.bar(x, vals, color=colors, width=0.62, yerr=err, error_kw={"elinewidth": 0.9, "capsize": 2, "ecolor": INK})
    for i, k in enumerate(order):
        if k in strict and not np.isnan(strict[k]):
            ax.plot([i - 0.31, i + 0.31], [strict[k], strict[k]], color=INK, lw=1.2)
    ax.plot([], [], color=INK, lw=1.2, label="failures counted as invalid")
    ax.set_xticks(x); ax.set_xticklabels([labels.get(k, k) for k in order], rotation=20, ha="right", fontsize=8)
    ax.set_ylim(0, 1); ax.set_ylabel("Share of real-trained models accepting")
    ax.grid(True, axis="y"); ax.legend(fontsize=7, loc="upper right")
    ax.set_title(dataset.upper() if dataset == "heloc" else dataset.capitalize(), fontsize=9, loc="left")
    _save(fig, path)


def fig_overlap(overlap: pd.DataFrame, path: Path, dataset: str):
    """Jaccard overlap between the sets of displaced applicants under each pair of generators."""
    gens = [g for g in GEN_ORDER if g in overlap.index]
    M = overlap.loc[gens, gens].astype(float)
    fig, ax = plt.subplots(figsize=(3.3, 3.0))
    _heat(ax, M.values, [GEN_LABEL[g] for g in gens])
    ax.set_title(dataset.upper() if dataset == "heloc" else dataset.capitalize(), fontsize=9, loc="left")
    _save(fig, path)


def fig_displacement(person: pd.DataFrame, metric: str, path: Path, dataset: str):
    """Distribution of per-applicant displacement D_g(i) under each generator, with the zero line."""
    gens = [g for g in GEN_ORDER if f"D_{metric}__{g}" in person]
    fig, ax = plt.subplots(figsize=(3.6, 2.6))
    bins = np.linspace(-0.5, 0.9, 29)
    for g in gens:
        d = person[f"D_{metric}__{g}"].dropna()
        ax.hist(d, bins=bins, histtype="step", lw=1.4, color=GEN_COLORS[g], label=GEN_LABEL[g], density=True)
    ax.axvline(0, color=INK, lw=0.8)
    ax.set_xlabel("Displacement $D_g(i)$")
    ax.set_ylabel("Density")
    ax.set_yticks([])
    ax.spines["left"].set_visible(False)
    ax.legend(fontsize=6.5, loc="upper right")
    ax.set_title(dataset.upper() if dataset == "heloc" else dataset.capitalize(), fontsize=9, loc="left")
    _save(fig, path)
