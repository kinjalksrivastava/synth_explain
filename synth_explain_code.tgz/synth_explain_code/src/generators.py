"""Stage 02: fit the five generators on real Train (inputs + target) and sample n_train rows (Spec 5)."""
from __future__ import annotations

import logging
import time
import warnings

import numpy as np
import pandas as pd

from .common import Timer, set_seed

log = logging.getLogger("generators")
for _noisy in ("rdt", "SingleTableSynthesizer", "sdv", "sdmetrics"):
    logging.getLogger(_noisy).setLevel(logging.WARNING)

SDV_GENERATORS = {"gaussian_copula", "copulagan", "ctgan", "tvae"}


def generator_table(train: pd.DataFrame, cols: dict) -> pd.DataFrame:
    """Inputs plus target; aux columns (e.g. SEX) are not generated."""
    return train[cols["inputs"] + [cols["target"]]].copy()


def column_kinds(cols: dict, meta: dict) -> dict[str, str]:
    """'categorical' or 'numerical' per generated column, from meta.yaml."""
    kinds = {}
    for c in cols["inputs"]:
        if c in cols["indicators"]:
            kinds[c] = "categorical"
        else:
            # ordinal codes (small integer domains such as MaxDelqEver, PAY_0) are generated as categorical so every
            # generator preserves their value set and marginals; parametric marginals put mass on codes that never occur
            kinds[c] = "categorical" if meta["features"][c]["type"] in ("categorical", "ordinal") else "numerical"
    kinds[cols["target"]] = "categorical"
    return kinds


def build_sdv_metadata(cols: dict, meta: dict):
    from sdv.metadata import SingleTableMetadata
    md = SingleTableMetadata()
    for c, kind in column_kinds(cols, meta).items():
        if kind == "categorical":
            md.add_column(c, sdtype="categorical")
        else:
            md.add_column(c, sdtype="numerical", computer_representation="Int64")
    return md


def _sdv_synthesizer(name: str, metadata, cfg: dict):
    from sdv.single_table import (CopulaGANSynthesizer, CTGANSynthesizer, GaussianCopulaSynthesizer,
                                  TVAESynthesizer)
    gcfg = cfg["generators"]
    epochs = int(gcfg["epochs"])
    gpu = bool(gcfg.get("cuda", True))
    if name == "gaussian_copula":
        return GaussianCopulaSynthesizer(metadata, enforce_min_max_values=True, enforce_rounding=True)
    if name == "copulagan":
        return CopulaGANSynthesizer(metadata, epochs=epochs, enable_gpu=gpu, enforce_min_max_values=True,
                                    enforce_rounding=True)
    if name == "ctgan":
        return CTGANSynthesizer(metadata, epochs=epochs, enable_gpu=gpu, enforce_min_max_values=True,
                                enforce_rounding=True)
    if name == "tvae":
        return TVAESynthesizer(metadata, epochs=epochs, enable_gpu=gpu, enforce_min_max_values=True,
                               enforce_rounding=True)
    raise ValueError(name)


def fit_sample_sdv(name: str, table: pd.DataFrame, cols: dict, meta: dict, cfg: dict, seed: int) -> tuple[pd.DataFrame, dict]:
    md = build_sdv_metadata(cols, meta)
    set_seed(seed)
    synth = _sdv_synthesizer(name, md, cfg)
    with Timer() as t_fit:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            synth.fit(table)
    # SDV.sample() silently uses a fixed internal seed (FIXED_RNG_SEED) unless a random state is set explicitly.
    set_seed(seed)
    synth._set_random_state(seed)
    with Timer() as t_sample:
        out = synth.sample(num_rows=len(table))
    info = {"fit_seconds": t_fit.seconds, "sample_seconds": t_sample.seconds, "epochs": cfg["generators"]["epochs"]}
    try:
        losses = synth.get_loss_values()
        info["final_loss"] = losses.tail(1).to_dict("records")[0]
    except Exception:
        pass
    return out[table.columns], info


def fit_sample_tabddpm(table: pd.DataFrame, cols: dict, meta: dict, cfg: dict, seed: int) -> tuple[pd.DataFrame, dict]:
    """TabDDPM through the synthcity 'ddpm' plugin. Requires the separate requirements-tabddpm.txt venv."""
    try:
        from synthcity.plugins import Plugins
        from synthcity.plugins.core.dataloader import GenericDataLoader
    except ImportError as e:
        raise ImportError("synthcity is not installed; run stage 02 for tabddpm from the .venv-ddpm environment "
                          "(see requirements-tabddpm.txt)") from e
    import functools
    import synthcity.plugins.core.models.tabular_ddpm as tddpm_mod
    from synthcity.plugins.core.models.tabular_encoder import TabularEncoder
    from synthcity.utils.dataframe import discrete_columns as _disc

    n_iter = int(cfg["generators"]["tabddpm"]["n_iter"])
    # synthcity decides "categorical" as nunique <= 10 in two places (its encoder and the diffusion model). The encoder
    # quantile-transforms the rest, which can collapse an 11-level column to 10 unique values, so the diffusion model
    # then treats quantile floats as class indices and crashes. We raise the limit so that every column we declare
    # categorical/ordinal (Spec 16.10) plus indicators and the target is categorical in both places, remap those
    # columns to contiguous codes 0..K-1 (negative codes crash one_hot), and verify both decisions agree.
    kinds = column_kinds(cols, meta)
    disc = [c for c in table.columns if kinds[c] == "categorical"]
    limit = max(10, max(int(table[c].nunique()) for c in disc))
    num_low = [c for c in table.columns if c not in disc and table[c].nunique() <= limit]
    if num_low:
        raise ValueError(f"numerical columns with <= {limit} unique values would be categorical for TabDDPM: {num_low}")
    maps = {c: {v: i for i, v in enumerate(sorted(table[c].unique()))} for c in disc}
    t2 = table.copy()
    for c in disc:
        t2[c] = t2[c].map(maps[c]).astype(int)
    set_seed(seed)
    loader = GenericDataLoader(t2, target_column=cols["target"])
    plugin = Plugins().get("ddpm", n_iter=n_iter, is_classification=True, random_state=seed)
    plugin.encoder = TabularEncoder(continuous_encoder="quantile", cont_encoder_params={"random_state": seed},
                                    categorical_encoder="none", cat_encoder_params={}, categorical_limit=limit)
    tddpm_mod.discrete_columns = functools.partial(_disc, max_classes=limit)
    df_chk, _ = loader.unpack()
    enc = TabularEncoder(continuous_encoder="quantile", cont_encoder_params={"random_state": seed},
                         categorical_encoder="none", cat_encoder_params={}, categorical_limit=limit).fit_transform(df_chk)
    seen = sorted(c for c, _ in _disc(enc, max_classes=limit, return_counts=True))
    want = sorted(c for c in disc if c != cols["target"])
    if seen != want:
        raise ValueError(f"TabDDPM categorical mismatch: encoder/diffusion see {seen}, expected {want}")
    with Timer() as t_fit:
        plugin.fit(loader)
    set_seed(seed)
    with Timer() as t_sample:
        out = plugin.generate(count=len(table)).dataframe()
    for c in disc:
        inv = {i: v for v, i in maps[c].items()}
        codes = np.clip(np.round(out[c].to_numpy(dtype=float)), 0, len(inv) - 1).astype(int)
        out[c] = pd.Series(codes).map(inv).to_numpy()
    info = {"fit_seconds": t_fit.seconds, "sample_seconds": t_sample.seconds, "n_iter": n_iter,
            "ddpm_categorical_columns": disc, "ddpm_categorical_limit": limit}
    return out[table.columns], info


def postprocess(synth: pd.DataFrame, table: pd.DataFrame, cols: dict, meta: dict, cfg: dict) -> tuple[pd.DataFrame, dict]:
    """Clip to valid ranges, round integers, enforce categorical domains; log changes (Spec 5)."""
    pcfg = cfg["generators"]["postprocess"]
    out = synth.copy()
    changes = {}
    ranges = cols["ranges"]
    for c in cols["inputs"]:
        before = out[c].to_numpy(dtype=float)
        if c in cols["indicators"]:
            new = np.where(before >= 0.5, 1, 0).astype(float)
        else:
            m = meta["features"][c]
            new = before.copy()
            if m["type"] == "categorical":
                if pcfg["enforce_categorical_domain"]:
                    dom = np.array(m["domain"], dtype=float)
                    idx = np.abs(new[:, None] - dom[None, :]).argmin(axis=1)
                    new = dom[idx]
            else:
                if pcfg["round_integers"] and m["type"] in ("integer", "ordinal"):
                    new = np.round(new)
                if pcfg["clip_to_range"]:
                    new = np.clip(new, ranges[c]["min"], ranges[c]["max"])
        n_changed = int(np.sum(~np.isclose(before, new, equal_nan=True) | np.isnan(before)))
        new = np.where(np.isnan(new), np.nanmedian(table[c].to_numpy(dtype=float)), new)
        out[c] = new.astype(table[c].dtype) if np.issubdtype(table[c].dtype, np.integer) else new
        if n_changed:
            changes[c] = n_changed
    # Keep the impute+indicator relation deterministic (Spec 16.1): where <f>_na == 1 the value must equal the
    # train imputation value, as in real data. Otherwise a detector separates real from synthetic trivially.
    n_fixed = 0
    for ind in cols["indicators"]:
        f = ind[:-3]
        real_imputed = table.loc[table[ind] == 1, f]
        if real_imputed.empty:
            continue
        fill = float(real_imputed.iloc[0])
        mask = out[ind].to_numpy() == 1
        n_fixed += int((mask & ~np.isclose(out[f].to_numpy(dtype=float), fill)).sum())
        out.loc[mask, f] = fill
    if n_fixed:
        changes["_indicator_consistency"] = n_fixed
    y = cols["target"]
    out[y] = (out[y].to_numpy(dtype=float) >= 0.5).astype(int)
    out = out.astype({c: table[c].dtype for c in table.columns})
    return out, {"n_values_changed": int(sum(changes.values())), "changed_by_column": changes}


def run_generator(name: str, train: pd.DataFrame, cols: dict, meta: dict, cfg: dict, seed: int) -> tuple[pd.DataFrame, dict]:
    table = generator_table(train, cols)
    t0 = time.time()
    if name in SDV_GENERATORS:
        synth, info = fit_sample_sdv(name, table, cols, meta, cfg, seed)
    elif name == "tabddpm":
        synth, info = fit_sample_tabddpm(table, cols, meta, cfg, seed)
    else:
        raise ValueError(f"unknown generator {name}")
    synth, pinfo = postprocess(synth, table, cols, meta, cfg)
    info.update(pinfo)
    info.update({"generator": name, "seed": seed, "n_rows": len(synth), "total_seconds": time.time() - t0,
                 "real_class_ratio": float(table[cols["target"]].mean()),
                 "synthetic_class_ratio": float(synth[cols["target"]].mean())})
    return synth, info
