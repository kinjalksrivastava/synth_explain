"""Stage 05: DiCE counterfactuals per source model and the recourse transfer test (Spec 7.2, 8.4, 16.4)."""
from __future__ import annotations

import logging
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import Parallel, delayed

from .common import load_split, parse_model_id
from .models import load_model

log = logging.getLogger("recourse")


def recourse_sample(expl: dict, thr: dict, rule: str, cfg: dict) -> np.ndarray:
    """300 audit persons adverse under the mean R model, stratified by its probability decile (Spec 16.4)."""
    rc = cfg["recourse"]
    model_ids = list(expl["model_ids"])
    R = [i for i, m in enumerate(model_ids) if parse_model_id(m)["condition"] == "R"]
    p_mean = expl["prob"][R].mean(axis=0)
    t = cfg["decision"]["fixed_threshold"] if rule == "fixed" else float(np.quantile(p_mean, 1 - thr["_reject_share_R"]))
    adverse = np.where(p_mean >= t)[0]
    if len(adverse) <= rc["n_persons"]:
        return expl["person_ids"][adverse]
    dec = pd.qcut(p_mean[adverse], rc["stratify_deciles"], labels=False, duplicates="drop")
    rng = np.random.default_rng(rc["sample_seed"])
    chosen = []
    per = rc["n_persons"] / len(adverse)
    for d in np.unique(dec):
        pool = adverse[dec == d]
        n = int(round(per * len(pool)))
        chosen.extend(rng.choice(pool, size=min(n, len(pool)), replace=False))
    return expl["person_ids"][np.array(sorted(chosen))]


def constraints_for(x: pd.Series, cols: dict, meta: dict, lock_imputed: bool = True,
                    bounds: dict | None = None) -> tuple[list[str], dict]:
    """features_to_vary and per-person permitted ranges implementing directional constraints (Spec 16.4, 16.13).
    A feature whose missing indicator is 1 holds an imputed value, not a fact about the applicant, and is held fixed.
    meta recourse_min / recourse_max (optional) bound the permitted range for recourse only."""
    vary, rng = [], {}
    ranges = cols["ranges"]
    for f in cols["features"]:
        m = meta["features"][f]
        rec = m["recourse"]
        if rec == "immutable" or m["type"] == "categorical":
            continue
        if lock_imputed and f"{f}_na" in cols["indicators"] and float(x[f"{f}_na"]) >= 0.5:
            continue
        lo, hi = ranges[f]["min"], ranges[f]["max"]
        if m.get("recourse_min") is not None:
            lo = max(lo, float(m["recourse_min"]))
        if m.get("recourse_max") is not None:
            hi = min(hi, float(m["recourse_max"]))
        if bounds is not None and f in bounds:          # plausibility band from the training data (Spec 16.14)
            lo, hi = max(lo, float(bounds[f][0])), min(hi, float(bounds[f][1]))
        xi = float(x[f])
        if rec == "increase_only":
            lo = xi
        elif rec == "decrease_only":
            hi = xi
        if hi <= lo:
            continue
        vary.append(f)
        rng[f] = [lo, hi]
    return vary, rng


def check_constraints(x: pd.Series, cf: pd.Series, cols: dict, meta: dict, tol: float = 1e-6) -> bool:
    for f in cols["inputs"]:
        if f not in cols["features"]:  # indicators immutable
            if abs(float(cf[f]) - float(x[f])) > tol:
                return False
            continue
        m = meta["features"][f]
        rec = m["recourse"]
        d = float(cf[f]) - float(x[f])
        if (rec == "immutable" or m["type"] == "categorical") and abs(d) > tol:
            return False
        if rec == "increase_only" and d < -tol:
            return False
        if rec == "decrease_only" and d > tol:
            return False
    return True


def _round_cf(cf: pd.Series, cols: dict, meta: dict) -> pd.Series:
    cf = cf.copy()
    for f in cols["features"]:
        if meta["features"][f]["type"] in ("integer", "ordinal", "categorical"):
            cf[f] = float(np.round(float(cf[f])))
    for f in cols["indicators"]:
        cf[f] = float(np.round(float(cf[f])))
    return cf


class _ThresholdCentred:
    """Monotone rescaling of a classifier so that the source model's own threshold maps to 0.5 (Spec 16.13).
    q = sigmoid(logit(p) - logit(t)). DiCE assumes a 0.5 decision boundary and clamps any stopping threshold above 0.5
    to 0.25 (dice_ml.explainer_interfaces.dice_random, v0.12); in the rescaled space the acceptance level
    0.8 x t always lies below 0.5, so the search criterion DiCE applies is exactly the one we check afterwards."""

    _estimator_type = "classifier"

    def __init__(self, model, threshold: float):
        self.model, self.shift = model, _logit(threshold)
        self.classes_ = np.array([0, 1])

    def rescale(self, p):
        p = np.clip(np.asarray(p, dtype=float), 1e-12, 1 - 1e-12)
        return 1.0 / (1.0 + np.exp(-(np.log(p / (1 - p)) - self.shift)))

    def predict_proba(self, X):
        q = self.rescale(self.model.predict_proba(X)[:, 1])
        return np.column_stack([1 - q, q])

    def predict(self, X):
        return (self.predict_proba(X)[:, 1] >= 0.5).astype(int)


def _logit(p: float) -> float:
    p = min(max(float(p), 1e-12), 1 - 1e-12)
    return float(np.log(p / (1 - p)))


def acceptance_level(source_thr: float, cfg: dict) -> float:
    """Spec 16.4 (revised): a counterfactual is accepted only if the SOURCE model's adverse probability falls to at most
    margin_ratio x its own decision threshold (0.8 x threshold by default, i.e. 0.4 when the threshold is 0.5).
    A fixed absolute margin would be confounded with the calibration shift the quantile rule removes."""
    rc = cfg["recourse"]
    ratio = float(rc.get("margin_ratio", float(rc["margin"]) / float(cfg["decision"]["fixed_threshold"])))
    return float(source_thr) * ratio


def _worker(model_path: str, source_id: str, X: pd.DataFrame, train: pd.DataFrame, cols: dict, meta: dict,
            cfg: dict, source_thr: float) -> list[dict]:
    import dice_ml
    rc = cfg["recourse"]
    accept = acceptance_level(source_thr, cfg)
    model = load_model(model_path)
    wrapped = _ThresholdCentred(model, source_thr)
    stop_q = float(wrapped.rescale(accept))          # acceptance level in the rescaled space, always < 0.5
    # every input is integer-valued (integers, ordinals, categorical codes, 0/1 indicators): declare precision 0 so
    # DiCE samples integers and validates exactly the row we score (Spec 16.13)
    precision = {f: (0 if meta["features"].get(f, {}).get("type", "integer") != "continuous" else 4)
                 for f in cols["inputs"]}
    # Spec 16.14: permitted ranges are bounded by a plausibility band of the training distribution, and among the
    # valid candidates DiCE returns the one closest to the applicant in standardised L1 distance is kept
    qs = rc.get("plausible_quantiles")
    bounds = {f: (float(train[f].quantile(qs[0])), float(train[f].quantile(qs[1]))) for f in cols["features"]} if qs else None
    std = train[cols["inputs"]].astype(float).std(ddof=0).replace(0, 1.0)
    d = dice_ml.Data(dataframe=train[cols["inputs"] + ["y"]].astype(float), continuous_features=cols["inputs"],
                     continuous_features_precision=precision, outcome_name="y")
    m = dice_ml.Model(model=wrapped, backend="sklearn", model_type="classifier")
    exp = dice_ml.Dice(d, m, method=rc["method"])
    rows = []
    for pid, x in X.iterrows():
        p0 = float(model.predict_proba(x.to_frame().T[cols["inputs"]])[0, 1])
        rec = {"source_id": source_id, "person": int(pid), "p_source_before": p0, "status": None,
               "source_threshold": float(source_thr), "accept_level": accept, "dice_stopping_q": stop_q}
        if p0 < source_thr:
            rec["status"] = "not_adverse"
            rows.append(rec)
            continue
        vary, prange = constraints_for(x, cols, meta, lock_imputed=bool(rc.get("lock_imputed", True)), bounds=bounds)
        rec["n_features_to_vary"] = len(vary)
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                kw = dict(total_CFs=rc["total_cfs"], desired_class=0, features_to_vary=vary, permitted_range=prange,
                          stopping_threshold=stop_q, verbose=False)
                if rc["method"] == "genetic":
                    kw["maxiterations"] = int(rc["max_iterations"])
                elif rc["method"] == "random":
                    kw["random_seed"] = int(pid)
                    kw["sample_size"] = int(rc.get("random_sample_size", 1000))
                res = exp.generate_counterfactuals(x.to_frame().T[cols["inputs"]].astype(float), **kw)
            if abs(float(exp.stopping_threshold) - stop_q) > 1e-9:   # guard against the library override
                raise RuntimeError(f"DiCE changed the stopping threshold: {exp.stopping_threshold} != {stop_q}")
            ex0 = res.cf_examples_list[0]
            cf_df = ex0.final_cfs_df_sparse if (rc.get("use_sparse", True) and getattr(ex0, "final_cfs_df_sparse", None) is not None) \
                else ex0.final_cfs_df
            if cf_df is None or len(cf_df) == 0:
                rec["status"] = "no_cf"
                rows.append(rec)
                continue
            # score every candidate; keep the closest valid one (Spec 16.14)
            cands = []
            for j in range(len(cf_df)):
                cf_j = _round_cf(cf_df.iloc[j][cols["inputs"]].astype(float), cols, meta)
                p_j = float(model.predict_proba(cf_j.to_frame().T[cols["inputs"]])[0, 1])
                if not check_constraints(x, cf_j, cols, meta):
                    st = "constraint_violation"
                elif p_j > accept:
                    st = "margin_fail"
                else:
                    st = "ok"
                dist = float((np.abs(cf_j[cols["inputs"]].to_numpy(dtype=float) - x[cols["inputs"]].to_numpy(dtype=float)) / std.to_numpy()).sum())
                cands.append((st != "ok", dist, j, st, p_j, cf_j))
            cands.sort(key=lambda t: (t[0], t[1], t[2]))
            _, dist, j, st, p1, cf = cands[0]
            rec["status"] = st
            rec["p_source_after"] = p1
            rec["n_candidates"] = int(len(cf_df))
            rec["n_candidates_ok"] = int(sum(1 for c in cands if c[3] == "ok"))
            rec["l1_std_chosen"] = dist
            for f in cols["inputs"]:
                rec[f"cf_{f}"] = float(cf[f])
        except RuntimeError:
            raise
        except Exception as e:  # DiCE raises when it finds nothing
            rec["status"] = "no_cf"
            rec["error"] = str(e)[:200]
        rows.append(rec)
    return rows


def generate_all(cfg: dict, dataset: str, registry: pd.DataFrame, persons: np.ndarray, thr: dict, rule: str,
                 cols: dict, meta: dict) -> pd.DataFrame:
    rc = cfg["recourse"]
    train = load_split(cfg, dataset, "train")
    audit = load_split(cfg, dataset, "audit").set_index("id")
    X = audit.loc[persons, cols["inputs"]].astype(float)
    jobs = []
    n_jobs = rc["n_jobs"]
    for _, r in registry.iterrows():
        src_thr = float(thr[rule][r.model_id])
        # split persons into chunks so each source model uses several workers
        for idx in np.array_split(np.arange(len(X)), 4):
            if len(idx):
                jobs.append(delayed(_worker)(r.path, r.model_id, X.iloc[idx], train, cols, meta, cfg, src_thr))
    log.info("recourse: %d source models x %d persons, %d jobs", len(registry), len(persons), len(jobs))
    results = Parallel(n_jobs=n_jobs, verbose=5)(jobs)
    df = pd.DataFrame([row for rows in results for row in rows])
    return df


def transfer_test(cfs: pd.DataFrame, registry: pd.DataFrame, thr: dict, rule: str, cols: dict, train: pd.DataFrame,
                  audit: pd.DataFrame) -> pd.DataFrame:
    """Apply each accepted counterfactual to every R model other than its source (Spec 7.2)."""
    R = registry[registry.condition == "R"]
    targets = {r.model_id: load_model(r.path) for _, r in R.iterrows()}
    ok = cfs[cfs.status == "ok"].copy()
    if ok.empty:
        return pd.DataFrame()
    cf_cols = [f"cf_{f}" for f in cols["inputs"]]
    Xcf = ok[cf_cols].to_numpy(dtype=float)
    Xcf = pd.DataFrame(Xcf, columns=cols["inputs"])
    X0 = audit.set_index("id").loc[ok.person, cols["inputs"]].to_numpy(dtype=float)
    std = train[cols["inputs"]].std().replace(0, 1).to_numpy()
    ok["l1_std"] = (np.abs(Xcf.to_numpy() - X0) / std).sum(axis=1)
    ok["n_changed"] = (np.abs(Xcf.to_numpy() - X0) > 1e-9).sum(axis=1)
    valid = np.zeros(len(ok))
    n_t = np.zeros(len(ok))
    for tid, model in targets.items():
        p = model.predict_proba(Xcf)[:, 1]
        t = float(thr[rule][tid])
        is_valid = (p < t).astype(float)
        mask = (ok.source_id != tid).to_numpy()
        valid += is_valid * mask
        n_t += mask
    ok["n_targets"] = n_t
    ok["valid_share"] = valid / np.maximum(n_t, 1)
    info = ok.source_id.map(parse_model_id)
    ok["condition"] = info.map(lambda d: d["condition"])
    ok["generator"] = info.map(lambda d: d["generator"] or "")
    ok["gen_seed"] = info.map(lambda d: d["gen_seed"])
    return ok


def recourse_summary(cfs: pd.DataFrame, transfer: pd.DataFrame) -> pd.DataFrame:
    """V_RR, V_BR, V_SR_g, failure shares and cost gaps (Spec 8.4)."""
    info = cfs.source_id.map(parse_model_id)
    cfs = cfs.assign(condition=info.map(lambda d: d["condition"]), generator=info.map(lambda d: d["generator"] or ""))
    attempted = cfs[cfs.status != "not_adverse"]
    fail = attempted.groupby(["condition", "generator"]).apply(
        lambda g: pd.Series({"n_attempted": len(g), "share_no_cf": (g.status == "no_cf").mean(),
                             "share_margin_fail": (g.status == "margin_fail").mean(),
                             "share_constraint_violation": (g.status == "constraint_violation").mean(),
                             "share_ok": (g.status == "ok").mean()})).reset_index()
    if transfer.empty:
        return fail
    v = transfer.groupby(["condition", "generator"]).agg(validity=("valid_share", "mean"), l1_std=("l1_std", "mean"),
                                                         n_changed=("n_changed", "mean"), n_cfs=("valid_share", "size"),
                                                         valid_sum=("valid_share", "sum")).reset_index()
    out = fail.merge(v, on=["condition", "generator"], how="left")
    # strict validity: every attempted counterfactual counts, failures (no_cf, margin_fail, violation) as invalid
    out["validity_strict"] = out["valid_sum"].fillna(0.0) / out["n_attempted"]
    out = out.drop(columns=["valid_sum"])
    base = out.loc[out.condition == "B", "validity"]
    base_rr = out.loc[out.condition == "R", "validity"]
    out["recourse_displacement"] = (float(base.iloc[0]) if len(base) else np.nan) - out["validity"]
    out["recourse_displacement_seed"] = (float(base_rr.iloc[0]) if len(base_rr) else np.nan) - out["validity"]
    return out
