"""Stage 07: RQ1-RQ3 statistics and the generator-dependence analyses (Spec 9, 16.7, 16.8)."""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy.stats import spearmanr
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

from .common import load_split, parse_model_id

log = logging.getLogger("analysis")


# ----------------------------------------------------------------------------- RQ1
def rq1_table(person: pd.DataFrame, displaced: pd.DataFrame, displaced_seed: pd.DataFrame, flips: pd.DataFrame,
              quality: pd.DataFrame, recourse: pd.DataFrame | None, metric: str, overlap: str) -> pd.DataFrame:
    gens = sorted(displaced.generator.unique())
    rows = []
    for g in gens:
        d = displaced[displaced.generator == g]
        ds = displaced_seed[displaced_seed.generator == g]
        q = quality[quality.generator == g]
        row = {"generator": g,
               "A_RR": person[f"{metric}__RR"].mean(), "A_BR": person[f"{metric}__BR"].mean(),
               "A_SR": person[f"{metric}__SR_{g}"].mean(),
               "O_RR": person[f"{overlap}__RR"].mean(), "O_BR": person[f"{overlap}__BR"].mean(),
               "O_SR": person[f"{overlap}__SR_{g}"].mean(),
               "D_mean": person[f"D_{metric}__{g}"].mean(), "D_seed_mean": person[f"Dseed_{metric}__{g}"].mean(),
               "n_testable": int(d.testable.sum()),
               "displaced_share": d.loc[d.testable, "displaced"].mean(),
               "displaced_share_bh": d.loc[d.testable, "displaced_bh"].mean(),
               "displaced_share_seedbase": ds.loc[ds.testable, "displaced"].mean(),
               "flip_RR": flips.loc[flips.pair_type == "RR", "flip_rate"].mean(),
               "flip_BR": flips.loc[flips.pair_type == "BR", "flip_rate"].mean(),
               "flip_SR": flips.loc[(flips.pair_type == "SR") & (flips.generator == g), "flip_rate"].mean(),
               "tstr_auc_gap": q.tstr_auc_gap.mean(), "sdmetrics_score": q.sdmetrics_score.mean(),
               "detection_auc": q.detection_auc.mean(), "global_shap_distance": q.global_shap_distance.mean(),
               "pgi": q.pgi.mean(), "pgi_R": q.pgi_R.mean() if "pgi_R" in q else np.nan,
               "class_ratio_synth": q.synthetic_class_ratio.mean() if "synthetic_class_ratio" in q else np.nan}
        if recourse is not None and not recourse.empty and "validity" in recourse:
            rv = recourse.set_index(["condition", "generator"])["validity"]
            row["V_RR"] = rv.get(("R", ""), np.nan)
            row["V_BR"] = rv.get(("B", ""), np.nan)
            row["V_SR"] = rv.get(("S", g), np.nan)
            row["recourse_displacement"] = row["V_BR"] - row["V_SR"]
        rows.append(row)
    return pd.DataFrame(rows)


def mixed_model(pairs: pd.DataFrame, metric: str, min_pairs: int = 5) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Person x pair-type means with a person random intercept; BR is the reference level (Spec 16.8).
    Cells with fewer than min_pairs valid pairs are dropped, as in the person table (Spec 8.2).
    Returns (effects table, generator contrasts table)."""
    df = pairs.copy()
    df["key"] = np.where(df.pair_type == "SR", "SR_" + df.generator.astype(str), df.pair_type.astype(str))
    agg = df.groupby(["person", "key"])[metric].agg(["mean", "size"]).reset_index()
    d = agg[agg["size"] >= min_pairs].rename(columns={"mean": metric})[["person", "key", metric]].dropna()
    model = smf.mixedlm(f"{metric} ~ C(key, Treatment('BR'))", d, groups=d["person"]).fit(reml=True)
    ci = model.conf_int()
    eff = pd.DataFrame({"term": model.params.index, "estimate": model.params.values, "se": model.bse.values,
                        "ci_low": ci[0].values, "ci_high": ci[1].values, "p": model.pvalues.values})
    eff["term"] = eff.term.str.replace("C(key, Treatment('BR'))[T.", "", regex=False).str.rstrip("]")
    cov = model.cov_params()
    names = [n for n in model.params.index if "SR_" in n]
    rows = []
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            diff = model.params[a] - model.params[b]
            var = cov.loc[a, a] + cov.loc[b, b] - 2 * cov.loc[a, b]
            se = np.sqrt(max(var, 0))
            rows.append({"generator_a": a.split("SR_")[1].rstrip("]"), "generator_b": b.split("SR_")[1].rstrip("]"),
                         "difference": diff, "se": se, "ci_low": diff - 1.96 * se, "ci_high": diff + 1.96 * se})
    return eff, pd.DataFrame(rows)


# ----------------------------------------------------------------------------- RQ2
def rq2_table(quality: pd.DataFrame, displaced_by_seed: pd.DataFrame, cfg: dict) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Unit = dataset x generator x generator seed. Spearman of displaced share with each check (Spec 9.2)."""
    share = displaced_by_seed[displaced_by_seed.testable].groupby(["generator", "gen_seed"]).agg(
        displaced_share=("displaced", "mean"), D_mean=("D", "mean"), n_testable=("displaced", "size")).reset_index()
    t = quality.merge(share, on=["generator", "gen_seed"], how="left")
    if "synthetic_class_ratio" in t and "real_class_ratio" in t:
        t["class_ratio_gap"] = (t["synthetic_class_ratio"] - t["real_class_ratio"]).abs()   # Spec 16.11
    checks = ["tstr_auc_gap", "global_shap_distance", "sdmetrics_score", "detection_auc", "pgi", "class_ratio_gap"]
    rows = []
    for c in checks:
        if c not in t:
            continue
        sub = t[[c, "displaced_share"]].dropna()
        rho, p = spearmanr(sub[c], sub["displaced_share"]) if len(sub) > 2 else (np.nan, np.nan)
        rows.append({"check": c, "spearman_rho": rho, "p": p, "n": len(sub)})
    r2 = cfg["rq2"]
    hidden = t[(t.tstr_auc_gap < r2["hidden_failure_auc_gap"]) & (t.displaced_share > r2["hidden_failure_displaced_share"])]
    info = {"n_conditions": int(len(t)), "n_hidden_failures": int(len(hidden)),
            "hidden_failures": hidden[["generator", "gen_seed", "tstr_auc_gap", "displaced_share"]].to_dict("records")}
    return t, pd.DataFrame(rows), info


# ----------------------------------------------------------------------------- RQ3
def person_predictors(cfg: dict, dataset: str, cols: dict, meta: dict, expl: dict, coverage: pd.DataFrame | None) -> pd.DataFrame:
    """Boundary proximity, rarity, coverage and subgroup labels per audit person (Spec 9.3)."""
    train = load_split(cfg, dataset, "train")
    audit = load_split(cfg, dataset, "audit").set_index("id").loc[expl["person_ids"]]
    model_ids = list(expl["model_ids"])
    R = [i for i, m in enumerate(model_ids) if parse_model_id(m)["condition"] == "R"]
    p_mean = expl["prob"][R].mean(axis=0)
    df = pd.DataFrame({"person": expl["person_ids"], "p_meanR": p_mean,
                       "boundary": np.abs(p_mean - cfg["decision"]["fixed_threshold"])})
    sc = StandardScaler().fit(train[cols["inputs"]])
    nn = NearestNeighbors(n_neighbors=cfg["rq3"]["knn"]).fit(sc.transform(train[cols["inputs"]]))
    dist, _ = nn.kneighbors(sc.transform(audit[cols["inputs"]]))
    df["rarity"] = dist.mean(axis=1)
    # subgroups from meta.yaml
    for name, sg in meta.get("subgroups", {}).items():
        x = audit[sg["feature"]]
        if sg["rule"] == "categories":
            df[f"sg_{name}"] = x.astype(int).astype(str).to_numpy()
        elif sg["rule"] == "bins":
            df[f"sg_{name}"] = pd.cut(x, bins=sg["bins"], labels=sg["labels"]).astype(str).to_numpy()
        elif sg["rule"] == "bottom_quartile":
            q = train[sg["feature"]].quantile(0.25)
            df[f"sg_{name}"] = np.where(x <= q, "thin", "other")
        elif sg["rule"] == "quartiles":
            edges = np.array(train[sg["feature"]].quantile([0, 0.25, 0.5, 0.75, 1.0]).to_numpy(), dtype=float)  # copy: pandas 3 returns read-only
            edges[0], edges[-1] = -np.inf, np.inf
            df[f"sg_{name}"] = pd.cut(x, bins=np.unique(edges), labels=False).astype(str).to_numpy()
    if coverage is not None:
        df = df.merge(coverage, on="person", how="left")
    return df


def rq3_models(displaced: pd.DataFrame, person: pd.DataFrame, predictors: pd.DataFrame, metric: str) -> dict:
    """OLS of D_g(i) on predictors with generator fixed effects and person-clustered SE; per-generator slopes (Spec 9.3, 16.7)."""
    gens = sorted(displaced.generator.unique())
    long = []
    for g in gens:
        d = pd.DataFrame({"person": person.person, "D": person[f"D_{metric}__{g}"], "generator": g})
        if f"coverage_{g}" in predictors:
            d = d.merge(predictors[["person", f"coverage_{g}"]].rename(columns={f"coverage_{g}": "coverage"}), on="person")
        else:
            d["coverage"] = np.nan
        long.append(d)
    long = pd.concat(long).merge(predictors.drop(columns=[c for c in predictors.columns if c.startswith("coverage_")]),
                                 on="person").dropna(subset=["D", "boundary", "rarity"])
    long["person_code"] = pd.factorize(long.person)[0]
    for c in ["boundary", "rarity", "coverage"]:
        if long[c].notna().any():
            long[c + "_z"] = (long[c] - long[c].mean()) / long[c].std()
    has_cov = long["coverage"].notna().any()
    base = "D ~ boundary_z + rarity_z" + (" + coverage_z" if has_cov else "")
    m_main = smf.ols(base + " + C(generator)", long.dropna(subset=["coverage_z"] if has_cov else [])).fit(
        cov_type="cluster", cov_kwds={"groups": long.dropna(subset=["coverage_z"] if has_cov else [])["person_code"]})
    m_int = smf.ols(base.replace("D ~ ", "D ~ (") + ") * C(generator)", long.dropna(subset=["coverage_z"] if has_cov else [])).fit(
        cov_type="cluster", cov_kwds={"groups": long.dropna(subset=["coverage_z"] if has_cov else [])["person_code"]})

    def tab(m):
        ci = m.conf_int()
        return pd.DataFrame({"term": m.params.index, "estimate": m.params.values, "se": m.bse.values,
                             "ci_low": ci[0].values, "ci_high": ci[1].values, "p": m.pvalues.values})

    slopes = []
    for g in gens:
        sub = long[long.generator == g]
        for c in ["boundary", "rarity"] + (["coverage"] if has_cov else []):
            s = sub[[c, "D"]].dropna()
            rho, p = spearmanr(s[c], s["D"]) if len(s) > 5 else (np.nan, np.nan)
            slopes.append({"generator": g, "predictor": c, "spearman_rho": rho, "p": p, "n": len(s)})
    return {"main": tab(m_main), "interactions": tab(m_int), "spearman_by_generator": pd.DataFrame(slopes),
            "long": long, "r2_main": m_main.rsquared}


def subgroup_gaps(displaced: pd.DataFrame, predictors: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    """Displaced share per subgroup with bootstrap CI over persons (Spec 9.3)."""
    nb = cfg["rq3"]["subgroup_bootstrap"]
    rng = np.random.default_rng(0)
    sg_cols = [c for c in predictors.columns if c.startswith("sg_")]
    d = displaced[displaced.testable].merge(predictors[["person"] + sg_cols], on="person")
    rows = []
    for g in sorted(d.generator.unique()):
        dg = d[d.generator == g]
        for sg in sg_cols:
            for level, sub in dg.groupby(sg):
                x = sub.displaced.to_numpy(dtype=float)
                if len(x) < 10:
                    continue
                boots = np.array([rng.choice(x, len(x)).mean() for _ in range(nb)])
                rows.append({"generator": g, "subgroup": sg[3:], "level": level, "n": len(x), "displaced_share": x.mean(),
                             "ci_low": np.quantile(boots, 0.025), "ci_high": np.quantile(boots, 0.975),
                             "D_mean": sub.D.mean()})
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------- generator dependence (16.7)
def displaced_overlap(displaced: pd.DataFrame) -> pd.DataFrame:
    """Pairwise Jaccard between the sets of displaced individuals under each generator, restricted to applicants
    testable under both generators (Spec 16.13; an applicant untestable under b cannot be in b's set)."""
    sets = {g: set(d.loc[d.displaced, "person"]) for g, d in displaced.groupby("generator")}
    testable = {g: set(d.loc[d.testable, "person"]) for g, d in displaced.groupby("generator")}
    gens = sorted(sets)
    M = pd.DataFrame(index=gens, columns=gens, dtype=float)
    for a in gens:
        for b in gens:
            both = testable[a] & testable[b]
            u = (sets[a] | sets[b]) & both
            M.loc[a, b] = len(sets[a] & sets[b] & both) / len(u) if u else np.nan
    return M


def variance_decomposition(person: pd.DataFrame, metric: str) -> dict:
    """Two-way crossed decomposition of D_{g,s}(i): person, generator, person x generator, seed residual."""
    cols = [c for c in person.columns if c.startswith(f"Dgs_{metric}__")]
    gens = sorted({c.split("__")[1] for c in cols})
    # seeds are replicates within a generator and are indexed by rank, not by label: a generator whose seed list was
    # replaced (Spec 16.13 seed_overrides) has the same number of replicates under different labels
    seeds_of = {g: sorted({c.split("__")[2] for c in cols if c.split("__")[1] == g}, key=lambda t: int(t.lstrip("s"))) for g in gens}
    n_s = min(len(v) for v in seeds_of.values())
    Y = np.full((len(person), len(gens), n_s), np.nan)
    for gi, g in enumerate(gens):
        for si, s in enumerate(seeds_of[g][:n_s]):
            Y[:, gi, si] = person[f"Dgs_{metric}__{g}__{s}"].to_numpy()
    keep = ~np.isnan(Y).any(axis=(1, 2))
    Y = Y[keep]
    n_i, n_g, n_s = Y.shape
    if n_i < 5:
        return {"n_persons": int(n_i)}
    mu = Y.mean()
    m_i = Y.mean(axis=(1, 2))
    m_g = Y.mean(axis=(0, 2))
    m_ig = Y.mean(axis=2)
    ss_tot = ((Y - mu) ** 2).sum()
    ss_i = n_g * n_s * ((m_i - mu) ** 2).sum()
    ss_g = n_i * n_s * ((m_g - mu) ** 2).sum()
    ss_ig = n_s * ((m_ig - m_i[:, None] - m_g[None, :] + mu) ** 2).sum()
    ss_res = ((Y - m_ig[:, :, None]) ** 2).sum()
    # split the within-(person, generator) residual into the seed main effect within generator (seed means over
    # persons) and the remainder (person x seed interaction plus model-seed noise) (Spec 16.13)
    m_gs = Y.mean(axis=0)                                   # (n_g, n_s)
    ss_seed = n_i * ((m_gs - m_g[:, None]) ** 2).sum()
    ss_rem = ss_res - ss_seed
    within_gen_seed_sd = float(np.sqrt(ss_res / (n_i * n_g * (n_s - 1)))) if n_s > 1 else np.nan
    between_gen_sd = float(np.std(m_g, ddof=1)) if n_g > 1 else np.nan
    return {"n_persons": int(n_i), "n_generators": n_g, "n_seeds": n_s,
            "share_person": ss_i / ss_tot, "share_generator": ss_g / ss_tot,
            "share_person_x_generator": ss_ig / ss_tot, "share_seed_residual": ss_res / ss_tot,
            "share_seed_main_within_generator": ss_seed / ss_tot, "share_seed_remainder": ss_rem / ss_tot,
            "within_generator_seed_sd": within_gen_seed_sd, "between_generator_sd": between_gen_sd,
            "generator_means": dict(zip(gens, m_g.tolist()))}


def worked_example(expl: dict, displaced: pd.DataFrame, k: int, adverse: np.ndarray) -> dict:
    """Displaced person with the largest D under a generator; reasons under one R model and one S model of that
    generator, both of which must reject the person (Spec 7.1, 13)."""
    d = displaced[displaced.displaced].sort_values("D", ascending=False)
    model_ids = list(expl["model_ids"])
    feats = list(expl["features"])
    for _, row in d.iterrows():
        g = row.generator
        pi = int(np.where(expl["person_ids"] == row.person)[0][0])
        r_idx = [i for i, m in enumerate(model_ids) if m.startswith("R_") and adverse[i, pi]]
        s_idx = [i for i, m in enumerate(model_ids) if m.startswith(f"S_{g}_") and adverse[i, pi]]
        if not r_idx or not s_idx:
            continue
        out = {"person": int(row.person), "generator": g, "D": float(row.D)}
        for name, mi in (("real", r_idx[0]), ("synthetic", s_idx[0])):
            v = expl["values"][mi, pi]
            order = np.argsort(-v)[:k]
            out[name] = {"model": model_ids[mi], "prob": float(expl["prob"][mi, pi]),
                         "reasons": [(feats[j], float(v[j])) for j in order if v[j] > 0]}
        return out
    return {}
