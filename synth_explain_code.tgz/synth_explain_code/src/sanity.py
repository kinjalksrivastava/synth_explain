"""Spec 10 sanity checks. Each returns (ok, message). Scripts stop on failure unless --no-strict."""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd

from .common import load_split, row_hashes

log = logging.getLogger("sanity")


def check_auc_range(perf: pd.DataFrame, lo: float = 0.70, hi: float = 0.90) -> tuple[bool, str]:
    r = perf[perf.condition == "R"]["auc"]
    ok = bool(r.between(lo, hi).all())
    return ok, f"[1] R AUC range {r.min():.3f}-{r.max():.3f} (expected ~0.78-0.80, accept {lo}-{hi})"


def check_r_models_differ(person: pd.DataFrame, col: str) -> tuple[bool, str]:
    a = person[col].dropna()
    share = float((a < 1).mean()) if len(a) else 0.0
    return share > 0.1, f"[2] share of persons with A_RR < 1: {share:.3f} (need > 0.10, else seeds do nothing)"


def check_synthetic_schema(synth: pd.DataFrame, train: pd.DataFrame, cols: dict) -> tuple[bool, str]:
    want = cols["inputs"] + ["y"]
    msgs = []
    if list(synth.columns) != want:
        msgs.append(f"columns differ: {list(synth.columns)[:5]}... vs {want[:5]}...")
    for c in want:
        if synth[c].dtype != train[c].dtype:
            msgs.append(f"dtype {c}: {synth[c].dtype} vs {train[c].dtype}")
    for c, r in cols["ranges"].items():
        if "min" in r and (synth[c].min() < r["min"] - 1e-9 or synth[c].max() > r["max"] + 1e-9):
            msgs.append(f"range {c}: [{synth[c].min()}, {synth[c].max()}] outside [{r['min']}, {r['max']}]")
        if "domain" in r and not set(synth[c].unique()).issubset(set(r["domain"])):
            msgs.append(f"domain {c}: {sorted(synth[c].unique())[:10]}")
    return len(msgs) == 0, "[3] synthetic schema " + ("ok" if not msgs else "; ".join(msgs))


def check_no_audit_leakage(cfg: dict, dataset: str, cols: dict, synth_frames: list[pd.DataFrame] | None = None) -> tuple[bool, str]:
    train, val, audit = (load_split(cfg, dataset, s) for s in ("train", "validation", "audit"))
    ids_ok = not (set(audit.id) & (set(train.id) | set(val.id)))
    h_audit = set(row_hashes(audit, cols["inputs"]))
    overlap_train = len(h_audit & set(row_hashes(train, cols["inputs"])))
    n_synth = 0
    for s in synth_frames or []:
        n_synth += len(h_audit & set(row_hashes(s, cols["inputs"])))
    # identical feature rows across splits are duplicates present in the raw data (Taiwan has a few dozen);
    # leakage means shared ids. Fail only if duplicates are implausibly many.
    ok = ids_ok and overlap_train <= 0.01 * len(audit)
    return ok, (f"[4] audit ids disjoint={ids_ok}; audit rows with an identical train row={overlap_train} "
                f"(raw-data duplicates, must be <1% of audit); identical synthetic rows={n_synth} (coincidences allowed)")


def check_shap_additivity(values_inputs: np.ndarray, expected: float, logodds: np.ndarray, tol: float) -> tuple[bool, str]:
    err = np.abs(values_inputs.sum(axis=1) + expected - logodds).max()
    return err < tol, f"[5] SHAP additivity max error {err:.2e} (tol {tol})"


def check_reasons_are_inputs(reasons: pd.DataFrame, cols: dict) -> tuple[bool, str]:
    bad = set(reasons.feature) - set(cols["features"])
    return not bad, f"[6] reason features not model inputs: {sorted(bad) if bad else 'none'}"


def check_recourse_constraints(cfs: pd.DataFrame) -> tuple[bool, str]:
    n = int((cfs.status == "constraint_violation").sum())
    return n == 0, f"[7] counterfactuals violating immutability after rounding: {n} (these are excluded, logged as failures)"


def report(checks: list[tuple[bool, str]], strict: bool = True) -> bool:
    all_ok = True
    for ok, msg in checks:
        (log.info if ok else log.error)("%s %s", "PASS" if ok else "FAIL", msg)
        all_ok &= ok
    if not all_ok and strict:
        raise SystemExit("sanity check failed; see log (use --no-strict to continue)")
    return all_ok
