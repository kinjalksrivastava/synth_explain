"""Stage 01: load, clean, split and preprocess the two datasets (Spec 2, 3, 16.1)."""
from __future__ import annotations

import io
import logging
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import requests
from sklearn.model_selection import train_test_split

from .common import ROOT, data_dir, load_meta, write_json

log = logging.getLogger("data")


# ----------------------------------------------------------------------------- loading
def load_heloc_raw(cfg: dict) -> pd.DataFrame:
    hcfg = cfg["heloc"]
    raw_dir = ROOT / cfg["paths"]["raw"]
    raw_dir.mkdir(parents=True, exist_ok=True)
    errors = []
    for src in hcfg["sources"]:
        try:
            if src["type"] == "local":
                p = ROOT / src["path"]
                if p.exists():
                    log.info("HELOC from local file %s", p)
                    return pd.read_csv(p)
                continue
            if src["type"] == "openml":
                from sklearn.datasets import fetch_openml
                log.info("HELOC from OpenML name=%s", src["name"])
                ds = fetch_openml(name=src["name"], as_frame=True, parser="auto")
                df = ds.frame.copy()
                if hcfg["target"] not in df.columns and ds.target is not None:
                    df[hcfg["target"]] = ds.target
                df.to_csv(raw_dir / "heloc_dataset_v1.csv", index=False)
                return df
            if src["type"] == "url_renamed":
                log.info("HELOC from URL %s (renamed columns, restored positionally)", src["url"])
                r = requests.get(src["url"], timeout=120)
                r.raise_for_status()
                df = pd.read_csv(io.StringIO(r.text))
                meta = load_meta(cfg, "heloc")
                feats = list(meta["features"].keys())
                if df.shape[1] != len(feats) + 1 or src["target"] not in df.columns:
                    raise ValueError(f"unexpected HELOC layout {df.shape}, columns {list(df.columns)[:3]}")
                X = df.drop(columns=[src["target"]])
                X.columns = feats
                X[hcfg["target"]] = np.where(df[src["target"]].astype(int) == int(src["adverse_value"]), "Bad", "Good")
                X.to_csv(raw_dir / "heloc_dataset_v1.csv", index=False)
                return X
        except Exception as e:  # try next source
            errors.append(f"{src}: {e}")
            log.warning("HELOC source failed: %s", e)
    raise RuntimeError("Could not load HELOC from any source:\n" + "\n".join(errors))


def load_taiwan_raw(cfg: dict) -> pd.DataFrame:
    tcfg = cfg["taiwan"]
    raw_dir = ROOT / cfg["paths"]["raw"]
    raw_dir.mkdir(parents=True, exist_ok=True)
    cached = raw_dir / "taiwan_default.csv"
    if cached.exists():
        log.info("Taiwan from cached %s", cached)
        return pd.read_csv(cached)
    try:
        from ucimlrepo import fetch_ucirepo
        log.info("Taiwan from ucimlrepo id=%s", tcfg["uci_id"])
        ds = fetch_ucirepo(id=int(tcfg["uci_id"]))
        X = ds.data.features.copy()
        y = ds.data.targets.copy()
        df = pd.concat([X, y], axis=1)
        df = _rename_taiwan(df)
    except Exception as e:
        log.warning("ucimlrepo failed (%s); trying UCI static zip", e)
        r = requests.get(tcfg["fallback_url"], timeout=120)
        r.raise_for_status()
        z = zipfile.ZipFile(io.BytesIO(r.content))
        name = [n for n in z.namelist() if n.lower().endswith(".xls")][0]
        df = pd.read_excel(io.BytesIO(z.read(name)), header=1)
        df = df.drop(columns=[c for c in df.columns if str(c).upper() == "ID"])
        df = _rename_taiwan(df)
    df.to_csv(cached, index=False)
    return df


def _rename_taiwan(df: pd.DataFrame) -> pd.DataFrame:
    """ucimlrepo uses X1..X23 / Y; the xls uses the original names. Normalise to original names."""
    original = ["LIMIT_BAL", "SEX", "EDUCATION", "MARRIAGE", "AGE", "PAY_0", "PAY_2", "PAY_3", "PAY_4", "PAY_5",
                "PAY_6", "BILL_AMT1", "BILL_AMT2", "BILL_AMT3", "BILL_AMT4", "BILL_AMT5", "BILL_AMT6", "PAY_AMT1",
                "PAY_AMT2", "PAY_AMT3", "PAY_AMT4", "PAY_AMT5", "PAY_AMT6", "default payment next month"]
    cols = list(df.columns)
    if cols[:24] == original:
        return df
    if all(str(c).upper().startswith("X") or str(c).upper() == "Y" for c in cols[:24]):
        return df.rename(columns=dict(zip(cols[:24], original)))
    mapping = {}
    for c in cols:
        cu = str(c).strip()
        if cu in original:
            mapping[c] = cu
        elif cu.lower().replace("_", " ") in ("default payment next month", "default.payment.next.month"):
            mapping[c] = "default payment next month"
    return df.rename(columns=mapping)


# ----------------------------------------------------------------------------- cleaning
def clean_heloc(df: pd.DataFrame, cfg: dict, meta: dict) -> tuple[pd.DataFrame, dict]:
    hcfg = cfg["heloc"]
    target = hcfg["target"]
    feats = list(meta["features"].keys())
    df = df[feats + [target]].copy()
    for c in feats:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    n0 = len(df)
    specials = hcfg["special_values"]
    notes = {"n_raw": n0}
    if hcfg["drop_all_missing_rows"]:
        all_missing = (df[feats] == -9).all(axis=1)
        df = df.loc[~all_missing].copy()
        notes["n_dropped_all_minus9"] = int(all_missing.sum())
    special_mask = df[feats].isin(specials)
    notes["n_cells_special_to_nan"] = int(special_mask.values.sum())
    df[feats] = df[feats].mask(special_mask, np.nan)
    df["y"] = (df[target].astype(str).str.strip() == str(hcfg["adverse_label"])).astype(int)
    df = df.drop(columns=[target]).reset_index(drop=True)
    df.insert(0, "id", np.arange(len(df)))
    return df, notes


def clean_taiwan(df: pd.DataFrame, cfg: dict, meta: dict) -> tuple[pd.DataFrame, dict]:
    tcfg = cfg["taiwan"]
    target = tcfg["target"]
    feats = list(meta["features"].keys())
    aux = meta["aux"]
    df = df.copy()
    notes = {"n_raw": len(df)}
    df["EDUCATION"] = df["EDUCATION"].replace({0: 4, 5: 4, 6: 4})
    df["MARRIAGE"] = df["MARRIAGE"].replace({0: 3})
    df["y"] = (df[target].astype(int) == int(tcfg["adverse_label"])).astype(int)
    df = df[feats + aux + ["y"]].reset_index(drop=True)
    for c in feats + aux:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df.insert(0, "id", np.arange(len(df)))
    return df, notes


# ----------------------------------------------------------------------------- split + preprocess
def stratified_split(df: pd.DataFrame, cfg: dict) -> dict[str, pd.DataFrame]:
    s = cfg["split"]
    rest, audit = train_test_split(df, test_size=s["audit"], stratify=df["y"], random_state=s["seed"])
    val_frac = s["validation"] / (1.0 - s["audit"])
    train, val = train_test_split(rest, test_size=val_frac, stratify=rest["y"], random_state=s["seed"])
    return {"train": train.reset_index(drop=True), "validation": val.reset_index(drop=True),
            "audit": audit.reset_index(drop=True)}


def fit_preprocessor(train: pd.DataFrame, feats: list[str], cfg: dict) -> dict:
    """Train-only medians and the list of features that get a missing indicator (Spec 16.1)."""
    medians = train[feats].median().to_dict()
    na_feats = [c for c in feats if train[c].isna().any()] if cfg["preprocessing"]["missing_indicator"] else []
    return {"medians": {k: float(v) for k, v in medians.items()}, "indicator_features": na_feats}


def apply_preprocessor(df: pd.DataFrame, feats: list[str], pre: dict) -> pd.DataFrame:
    out = df.copy()
    for c in pre["indicator_features"]:
        out[f"{c}_na"] = out[c].isna().astype(int)
    for c in feats:
        out[c] = out[c].fillna(pre["medians"][c])
    return out


def prepare_dataset(cfg: dict, dataset: str, force: bool = False) -> dict:
    ddir = data_dir(cfg, dataset)
    meta = load_meta(cfg, dataset)
    feats = list(meta["features"].keys())
    aux = list(meta.get("aux", []))
    if (ddir / "audit.parquet").exists() and not force:
        log.info("%s already prepared (use --force to redo)", dataset)
        return {"columns": pd.read_json(ddir / "columns.json", typ="series").to_dict()}

    if dataset == "heloc":
        raw = load_heloc_raw(cfg)
        df, notes = clean_heloc(raw, cfg, meta)
    elif dataset == "taiwan":
        raw = load_taiwan_raw(cfg)
        df, notes = clean_taiwan(raw, cfg, meta)
    else:
        raise ValueError(dataset)

    splits = stratified_split(df, cfg)
    pre = fit_preprocessor(splits["train"], feats, cfg)
    input_cols = feats + [f"{c}_na" for c in pre["indicator_features"]]
    for name, part in splits.items():
        part = apply_preprocessor(part, feats, pre)
        part = part[["id"] + input_cols + aux + ["y"]]
        part.to_parquet(ddir / f"{name}.parquet", index=False)
        log.info("%s %s: n=%d adverse_rate=%.3f", dataset, name, len(part), part["y"].mean())

    # derive null ranges from train for meta consumers
    ranges = {}
    tr = splits["train"]
    for c in feats:
        m = meta["features"][c]
        lo = m.get("min")
        hi = m.get("max")
        if m.get("type") == "categorical":
            ranges[c] = {"domain": m["domain"]}
        else:
            ranges[c] = {"min": float(tr[c].min()) if lo is None else float(lo),
                         "max": float(tr[c].max()) if hi is None else float(hi)}
    cols = {"features": feats, "inputs": input_cols, "indicators": [f"{c}_na" for c in pre["indicator_features"]],
            "aux": aux, "target": "y", "ranges": ranges}
    write_json(cols, ddir / "columns.json")
    write_json(pre, ddir / "preprocess.json")
    notes.update({"n_train": len(splits["train"]), "n_validation": len(splits["validation"]),
                  "n_audit": len(splits["audit"]), "n_inputs": len(input_cols)})
    write_json(notes, ddir / "prepare_notes.json")
    log.info("%s notes: %s", dataset, notes)
    return {"columns": cols, "notes": notes}


def feature_ranges(cfg: dict, dataset: str) -> dict:
    from .common import columns_info
    return columns_info(cfg, dataset)["ranges"]
