"""Stage 06: individual-level agreement, displacement, displaced test, standard quality checks (Spec 8, 16.3, 16.5)."""
from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial.distance import cosine
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier

from .common import load_split, out_dir, parse_model_id
from .explain import reason_membership

log = logging.getLogger("metrics")


# ----------------------------------------------------------------------------- IO
def explanations_path(cfg: dict, dataset: str, variant: str) -> Path:
    return out_dir(cfg, "shap", dataset, variant) / "explanations.npz"


def load_explanations(cfg: dict, dataset: str, variant: str) -> dict:
    z = np.load(explanations_path(cfg, dataset, variant), allow_pickle=True)
    return {k: z[k] for k in z.files}


def decisions(prob: np.ndarray, model_ids: list[str], thr: dict, rule: str) -> np.ndarray:
    """(n_models, n_audit) boolean adverse decisions under a threshold rule."""
    t = np.array([thr[rule][m] for m in model_ids])[:, None]
    return prob >= t


# ----------------------------------------------------------------------------- pairs
def model_groups(model_ids: list[str]) -> dict:
    info = [parse_model_id(m) for m in model_ids]
    R = [i for i, d in enumerate(info) if d["condition"] == "R"]
    B = [i for i, d in enumerate(info) if d["condition"] == "B"]
    S = {}
    for i, d in enumerate(info):
        if d["condition"] == "S":
            S.setdefault(d["generator"], []).append(i)
    return {"R": R, "B": B, "S": S, "info": info}


def pair_list(groups: dict) -> list[tuple[str, str | None, int, int]]:
    """(pair_type, generator, a, b). RR unordered; BR and SR with R always on the b side (Spec 7.2, 8.2)."""
    pairs = []
    R = groups["R"]
    for i, a in enumerate(R):
        for b in R[i + 1:]:
            pairs.append(("RR", None, a, b))
    for a in groups["B"]:
        for b in R:
            pairs.append(("BR", None, a, b))
    for g, S in groups["S"].items():
        for a in S:
            for b in R:
                pairs.append(("SR", g, a, b))
    return pairs


def _rbo_from_ranks(ra: np.ndarray, rb: np.ndarray, p: float) -> np.ndarray:
    """Rank-biased overlap between two full rankings (ranks start at 1), vectorised over rows."""
    depth = ra.shape[1]
    out = np.zeros(ra.shape[0])
    for d in range(1, depth + 1):
        a_d = ((ra <= d) & (rb <= d)).sum(axis=1) / d
        out += (p ** (d - 1)) * a_d
    return (1 - p) * out


def pair_agreement(values: np.ndarray, adverse: np.ndarray, model_ids: list[str], person_ids: np.ndarray,
                   features: list[str], cfg: dict, families: dict[str, str]) -> pd.DataFrame:
    """Long table of agreement metrics for every pair and every person both models reject (Spec 8.2)."""
    rc = cfg["reasons"]
    k_list, k_main, min_shap, rbo_p = rc["k_list"], rc["k_main"], rc["min_shap"], rc["rbo_p"]
    n_models, n, p = values.shape
    fam_names = sorted(set(families.values()))
    fam_idx = np.array([fam_names.index(families[f]) for f in features])
    fam_mat = np.zeros((p, len(fam_names)), dtype=bool)
    fam_mat[np.arange(p), fam_idx] = True

    members = {k: [reason_membership(values[m], k, min_shap) for m in range(n_models)] for k in k_list}
    ranks = [np.argsort(np.argsort(-values[m], axis=1), axis=1) + 1 for m in range(n_models)]
    top1 = [np.where(values[m].max(axis=1) > min_shap, values[m].argmax(axis=1), -1) for m in range(n_models)]
    fam_members = [(members[k_main][m].astype(int) @ fam_mat) > 0 for m in range(n_models)]

    groups = model_groups(model_ids)
    frames = []
    for ptype, g, a, b in pair_list(groups):
        valid = adverse[a] & adverse[b]
        if not valid.any():
            continue
        idx = np.where(valid)[0]
        row = {"pair_type": ptype, "generator": g if g else "", "model_a": model_ids[a], "model_b": model_ids[b],
               "person": person_ids[idx]}
        for k in k_list:
            Ma, Mb = members[k][a][idx], members[k][b][idx]
            inter = (Ma & Mb).sum(1)
            union = (Ma | Mb).sum(1)
            row[f"jaccard_k{k}"] = np.where(union > 0, inter / np.maximum(union, 1), np.nan)
            row[f"overlap_k{k}"] = inter
        Fa, Fb = fam_members[a][idx], fam_members[b][idx]
        fu = (Fa | Fb).sum(1)
        row["jaccard_family"] = np.where(fu > 0, (Fa & Fb).sum(1) / np.maximum(fu, 1), np.nan)
        row["top1"] = ((top1[a][idx] == top1[b][idx]) & (top1[a][idx] >= 0)).astype(float)
        row["rbo"] = _rbo_from_ranks(ranks[a][idx], ranks[b][idx], rbo_p)
        frames.append(pd.DataFrame(row))
    df = pd.concat(frames, ignore_index=True)
    df["pair_type"] = df["pair_type"].astype("category")
    return df


def decision_flip_rates(adverse: np.ndarray, model_ids: list[str]) -> pd.DataFrame:
    """Share of audit individuals on which a and b disagree, averaged per pair type (Spec 8.3)."""
    rows = []
    for ptype, g, a, b in pair_list(model_groups(model_ids)):
        rows.append({"pair_type": ptype, "generator": g or "", "model_a": model_ids[a], "model_b": model_ids[b],
                     "flip_rate": float(np.mean(adverse[a] != adverse[b]))})
    df = pd.DataFrame(rows)
    return df


# ----------------------------------------------------------------------------- person aggregates
def person_aggregates(pairs: pd.DataFrame, cfg: dict, metric: str = None) -> pd.DataFrame:
    """A_RR, A_BR, A_SR_g per person (and per generator seed), D_g and D_seed_g, for every metric column."""
    min_pairs = cfg["agreement"]["min_valid_pairs"]
    metric_cols = [c for c in pairs.columns if c.startswith(("jaccard", "overlap", "top1", "rbo"))]
    pairs = pairs.copy()
    pairs["gen_seed"] = pairs["model_a"].map(lambda m: parse_model_id(m)["gen_seed"]).astype("Int64")
    pairs["key"] = np.where(pairs.pair_type == "SR", "SR_" + pairs.generator.astype(str), pairs.pair_type.astype(str))

    agg = pairs.groupby(["person", "key"])[metric_cols].mean()
    cnt = pairs.groupby(["person", "key"]).size().rename("n_pairs")
    agg = agg.join(cnt)
    agg.loc[agg.n_pairs < min_pairs, metric_cols] = np.nan
    wide = agg.unstack("key")
    wide.columns = [f"{m}__{k}" for m, k in wide.columns]
    wide = wide.reset_index()

    # per generator seed A_SR (for variance decomposition, Spec 16.7)
    sr = pairs[pairs.pair_type == "SR"]
    aggs = sr.groupby(["person", "generator", "gen_seed"])[metric_cols].mean()
    cnts = sr.groupby(["person", "generator", "gen_seed"]).size().rename("n_pairs")
    aggs = aggs.join(cnts)
    aggs.loc[aggs.n_pairs < min_pairs, metric_cols] = np.nan
    seed_level = aggs.reset_index()

    gens = sorted(set(pairs.loc[pairs.pair_type == "SR", "generator"]))
    for m in metric_cols:
        for g in gens:
            col = f"{m}__SR_{g}"
            if col not in wide:
                wide[col] = np.nan
            wide[f"D_{m}__{g}"] = wide[f"{m}__BR"] - wide[col]
            wide[f"Dseed_{m}__{g}"] = wide[f"{m}__RR"] - wide[col]
            sl = seed_level[seed_level.generator == g]
            sl = sl.pivot(index="person", columns="gen_seed", values=m)
            for s in sl.columns:
                wide = wide.merge((wide.set_index("person")[f"{m}__BR"] - sl[s]).rename(f"Dgs_{m}__{g}__s{s}"),
                                  left_on="person", right_index=True, how="left")
    return wide


# ----------------------------------------------------------------------------- displaced test (model bootstrap)
def _pair_matrix(pairs: pd.DataFrame, persons: np.ndarray, a_ids: list[str], b_ids: list[str], metric: str) -> np.ndarray:
    """(n_persons, len(a_ids), len(b_ids)) metric values, NaN where the pair is not valid for the person."""
    pi = {p: i for i, p in enumerate(persons)}
    ai = {m: i for i, m in enumerate(a_ids)}
    bi = {m: i for i, m in enumerate(b_ids)}
    M = np.full((len(persons), len(a_ids), len(b_ids)), np.nan)
    sub = pairs[pairs.model_a.isin(ai) & pairs.model_b.isin(bi)]
    M[sub.person.map(pi).to_numpy(), sub.model_a.map(ai).to_numpy(), sub.model_b.map(bi).to_numpy()] = sub[metric].to_numpy()
    return M


CI_TOL = 1e-9   # a bootstrap quantile is "above zero" only beyond floating-point noise (Spec 16.14)


def displaced_test(pairs: pd.DataFrame, model_ids: list[str], cfg: dict, metric_main: str, overlap_col: str,
                   baseline: str = "BR") -> pd.DataFrame:
    """Per person and generator: bootstrap over MODELS (Spec 16.3) of mean(baseline) - mean(SR_g)."""
    acfg = cfg["agreement"]
    nboot, level = acfg["n_bootstrap"], acfg["displaced_ci_level"]
    min_pairs, min_drop = acfg["min_valid_pairs"], acfg["displaced_min_overlap_drop"]
    rng = np.random.default_rng(acfg["bootstrap_seed"])
    groups = model_groups(model_ids)
    R = [model_ids[i] for i in groups["R"]]
    B = [model_ids[i] for i in groups["B"]]
    persons = np.array(sorted(pairs.person.unique()))
    alpha = (1 - level) / 2

    if baseline == "BR":
        Jb = _pair_matrix(pairs, persons, B, R, metric_main)
        Ob = _pair_matrix(pairs, persons, B, R, overlap_col)
    else:  # seed baseline: RR, symmetric with NaN diagonal
        Jb = _pair_matrix(pairs, persons, R, R, metric_main)
        Jb = np.where(np.isnan(Jb), np.transpose(Jb, (0, 2, 1)), Jb)
        Ob = _pair_matrix(pairs, persons, R, R, overlap_col)
        Ob = np.where(np.isnan(Ob), np.transpose(Ob, (0, 2, 1)), Ob)
    nb, nr = Jb.shape[1], Jb.shape[2]

    out = []
    for g, S_idx in groups["S"].items():
        S = [model_ids[i] for i in S_idx]
        Js = _pair_matrix(pairs, persons, S, R, metric_main)
        Os = _pair_matrix(pairs, persons, S, R, overlap_col)
        ns = Js.shape[1]
        point = np.nanmean(Jb, axis=(1, 2)) - np.nanmean(Js, axis=(1, 2))
        drop = np.nanmean(Ob, axis=(1, 2)) - np.nanmean(Os, axis=(1, 2))
        n_valid_b = (~np.isnan(Jb)).sum(axis=(1, 2))
        n_valid_s = (~np.isnan(Js)).sum(axis=(1, 2))
        boots = np.empty((nboot, len(persons)))
        with np.errstate(all="ignore"):
            for it in range(nboot):
                rR = rng.integers(0, nr, nr)
                rB = rR if baseline == "RR" else rng.integers(0, nb, nb)   # seed baseline: one R draw on both axes
                rS = rng.integers(0, ns, ns)
                mb = np.nanmean(Jb[:, rB][:, :, rR], axis=(1, 2))
                ms = np.nanmean(Js[:, rS][:, :, rR], axis=(1, 2))
                boots[it] = mb - ms
        lo = np.nanquantile(boots, alpha, axis=0)
        hi = np.nanquantile(boots, 1 - alpha, axis=0)
        p_two = 2 * np.minimum(np.nanmean(boots <= 0, axis=0), np.nanmean(boots >= 0, axis=0))
        p_two = np.clip(p_two, 1.0 / nboot, 1.0)
        ok = (n_valid_b >= min_pairs) & (n_valid_s >= min_pairs)
        df = pd.DataFrame({"person": persons, "generator": g, "D": point, "ci_low": lo, "ci_high": hi,
                           "p_boot": p_two, "overlap_drop": drop, "n_valid_baseline": n_valid_b, "n_valid_sr": n_valid_s,
                           "testable": ok})
        # statistics are kept for every person with at least one valid pair on each side, so that the sensitivity
        # of the displaced share to the minimum number of pairs can be read off the same table (Spec 16.14); only
        # persons without any pair on one side have no estimate
        none = (n_valid_b == 0) | (n_valid_s == 0)
        df.loc[none, ["D", "ci_low", "ci_high", "p_boot", "overlap_drop"]] = np.nan
        df["displaced"] = ok & (df.ci_low > CI_TOL) & (df.overlap_drop >= min_drop)
        df["bh_reject"] = False
        if ok.any():
            df.loc[ok, "bh_reject"] = bh_reject(df.loc[ok, "p_boot"].to_numpy(), acfg["bh_alpha"])
        df["displaced_bh"] = df.displaced & df.bh_reject
        out.append(df)
        log.info("displaced test %s baseline=%s: testable=%d displaced=%d (%.1f%%) bh=%d", g, baseline, ok.sum(),
                 df.displaced.sum(), 100 * df.displaced.sum() / max(ok.sum(), 1), df.displaced_bh.sum())
    return pd.concat(out, ignore_index=True)


def bh_reject(p: np.ndarray, alpha: float) -> np.ndarray:
    n = len(p)
    order = np.argsort(p)
    ranked = p[order] * n / (np.arange(n) + 1)
    passed = ranked <= alpha
    out = np.zeros(n, dtype=bool)
    if passed.any():
        kmax = np.max(np.where(passed)[0])
        out[order[: kmax + 1]] = True
    return out


# ----------------------------------------------------------------------------- standard quality checks (8.1)
def model_performance(prob: np.ndarray, adverse: np.ndarray, y: np.ndarray, model_ids: list[str]) -> pd.DataFrame:
    rows = []
    for i, m in enumerate(model_ids):
        d = parse_model_id(m)
        rows.append({"model_id": m, **d, "auc": roc_auc_score(y, prob[i]), "accuracy": accuracy_score(y, adverse[i]),
                     "f1": f1_score(y, adverse[i]), "reject_share": float(adverse[i].mean())})
    return pd.DataFrame(rows)


def tstr_table(perf: pd.DataFrame) -> pd.DataFrame:
    """Per generator and generator seed: mean R AUC minus mean S AUC (Spec 8.1)."""
    r_auc = perf.loc[perf.condition == "R", "auc"].mean()
    s = perf[perf.condition == "S"].groupby(["generator", "gen_seed"]).agg(auc=("auc", "mean"), accuracy=("accuracy", "mean"),
                                                                           f1=("f1", "mean")).reset_index()
    s["tstr_auc_gap"] = r_auc - s["auc"]
    s["r_auc"] = r_auc
    return s


def sdmetrics_score(real: pd.DataFrame, synth: pd.DataFrame, metadata) -> float:
    from sdmetrics.reports.single_table import QualityReport
    rep = QualityReport()
    rep.generate(real, synth, metadata.to_dict(), verbose=False)
    return float(rep.get_score())


def detection_auc(real: pd.DataFrame, synth: pd.DataFrame, audit: pd.DataFrame, cfg: dict) -> tuple[float, np.ndarray]:
    """XGBoost real-vs-synthetic classifier; returns held-out AUC and P(real) for each audit row (coverage, Spec 9.3)."""
    q = cfg["quality"]
    X = pd.concat([real, synth], ignore_index=True)
    y = np.r_[np.ones(len(real)), np.zeros(len(synth))]
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=q["detection_test_size"], stratify=y,
                                          random_state=q["detection_seed"])
    clf = XGBClassifier(n_estimators=300, max_depth=4, learning_rate=0.1, subsample=0.8, colsample_bytree=0.8,
                        random_state=q["detection_seed"], n_jobs=4, verbosity=0).fit(Xtr, ytr)
    auc = roc_auc_score(yte, clf.predict_proba(Xte)[:, 1])
    return float(auc), clf.predict_proba(audit[X.columns])[:, 1]


def global_shap_distance(values: np.ndarray, model_ids: list[str]) -> pd.DataFrame:
    """Cosine distance between mean |SHAP| of R models and of S_g models per generator seed (Spec 8.1)."""
    g = model_groups(model_ids)
    r_vec = np.abs(values[g["R"]]).mean(axis=(0, 1))
    rows = []
    for gen, S in g["S"].items():
        seeds = {}
        for i in S:
            seeds.setdefault(g["info"][i]["gen_seed"], []).append(i)
        for s, idx in seeds.items():
            rows.append({"generator": gen, "gen_seed": s, "global_shap_distance": float(cosine(r_vec, np.abs(values[idx]).mean(axis=(0, 1))))})
    return pd.DataFrame(rows)


def pgi(model, X: pd.DataFrame, values_feat: np.ndarray, adverse: np.ndarray, prob: np.ndarray, bg: pd.DataFrame,
        cols: dict, k: int) -> float:
    """OpenXAI-style prediction gap on important features: replace top-k reasons with background means (Spec 8.1)."""
    idx = np.where(adverse)[0]
    if len(idx) == 0:
        return np.nan
    feats = cols["features"]
    order = np.argsort(-values_feat[idx], axis=1)[:, :k]
    Xp = X.iloc[idx].astype(float).reset_index(drop=True)
    means = bg.astype(float).mean()
    for r in range(len(idx)):
        for j in order[r]:
            if values_feat[idx[r], j] <= 0:   # reasons are positive-SHAP features only (Spec 7.1)
                continue
            f = feats[j]
            Xp.at[r, f] = means[f]
            if f + "_na" in Xp.columns:
                Xp.at[r, f + "_na"] = means[f + "_na"]
    p_new = model.predict_proba(Xp[cols["inputs"]])[:, 1]
    return float(np.mean(prob[idx] - p_new))
