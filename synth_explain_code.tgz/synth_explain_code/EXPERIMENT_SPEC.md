# Experiment Specification: Same Decision, Different Reason

Explanation displacement in credit models trained on synthetic data.
Target: ECIS 2027 completed research paper. Submission deadline: 30 October 2026.

This file is the single source of truth for the pipeline. Build exactly this. Where a choice is marked CONFIGURABLE, keep it in `config.yaml`.

---

## 0. One-paragraph summary

We train credit-risk models on real data and on synthetic data from five generators. For every real applicant in a fixed audit set, we compare the top reasons (SHAP reason codes) and the recourse advice (counterfactuals) that each model gives. We first measure how much explanations vary between models trained on real data (normal randomness). Any extra variation when models are trained on synthetic data is **explanation displacement**. We then test whether standard synthetic data quality checks detect it, and which applicants are most affected.

---

## 1. Research questions and hypotheses

- **RQ1:** How much does training on synthetic data change the reasons and recourse individuals receive, beyond normal model variation?
- **RQ2:** Do standard quality checks (TSTR accuracy, global SHAP distance, statistical fidelity, detection AUC, XAI faithfulness) predict this displacement?
- **RQ3:** Which individuals are most affected?

- **H1:** Synthetic-trained models give individuals different reasons (and less transferable recourse) beyond the real-data baseline.
- **H2:** Aggregate quality metrics do not predict individual-level displacement.
- **H3:** Displacement concentrates on individuals with rare profiles, near the decision boundary, and in smaller subgroups.

---

## 2. Datasets

### 2.1 HELOC (FICO Explainable ML Challenge)
- Source: FICO xML Challenge release (or an OpenML mirror). Check the license and record the source in `data/README.md`.
- About 10,459 rows, 23 features, target `RiskPerformance` in {Good, Bad}.
- **Adverse outcome = Bad** (encode as y = 1).
- Special values:
  - Drop rows where all features equal -9 (no bureau record).
  - Remaining -7, -8, -9 values: replace with NaN. XGBoost handles NaN natively. For generators and LR, impute with the training median and add a binary missing indicator per affected feature. CONFIGURABLE.
- Protected attributes: none. For H3 use proxy groups (Section 9.3).

### 2.2 Taiwan Default of Credit Card Clients (UCI)
- Source: UCI repository (`ucimlrepo`, dataset id 350).
- 30,000 rows, 23 features, target `default payment next month`.
- **Adverse outcome = default** (y = 1).
- Cleaning:
  - `EDUCATION` values {0, 5, 6} map to 4 (other).
  - `MARRIAGE` value 0 maps to 3 (other).
- **Model inputs exclude `SEX` and `MARRIAGE`** (they cannot be lawful credit reasons). Keep them in the data for subgroup analysis only. CONFIGURABLE.
- Keep `AGE` and `EDUCATION` as inputs but mark them immutable for recourse.

### 2.3 Feature metadata (needed by generators and DiCE)
Create `data/<dataset>/meta.yaml` with, per feature: type (continuous, integer, ordinal, categorical), valid range, and recourse status (immutable, increase_only, decrease_only, free). Section 7.2 gives the starting lists. Claude Code should draft them and flag any doubtful ones for human review.

---

## 3. Splits

For each dataset, one fixed stratified split with seed 42:
- **Train 60%**: trains real models, fits generators, source for bootstrap resamples and SHAP background.
- **Validation 20%**: used once for hyperparameter tuning on real data. Never used again.
- **Audit 20%**: the fixed population of real individuals. Every model is evaluated and explained on exactly these rows. Generators never see it.

Robustness (only if time allows): repeat everything with split seeds 43 and 44.

**Leakage rules**
- Generators fit on Train only.
- Bootstrap resamples drawn from Train only.
- Preprocessing (imputers, scalers) fit on Train only.
- The audit set is never used for fitting anything.

---

## 4. Training conditions

| Condition | Training data | Seeds | Models per dataset |
|---|---|---|---|
| **R** (real, seed baseline) | Real Train | model seed 0 to 9 | 10 |
| **B** (real, bootstrap baseline) | Bootstrap resample of Train, size n_train, with replacement | resample seed b = 0 to 9, model seed = b | 10 |
| **S_g** (synthetic) | Synthetic data from generator g, size n_train | generator seed 0 to 2, model seed 0 to 2 | 9 per generator, 45 total |

Total per dataset: 65 XGBoost models (plus 65 LR models for robustness).

**Important:** XGBoost is deterministic when `subsample = 1` and `colsample_bytree = 1`. Set both to 0.8 so model seeds produce real variation. Without this, the R baseline is artificially perfect.

---

## 5. Generators

Five generators, each fit on real Train **including the target column** (the joint distribution of features and label). Synthetic size = n_train.

| Name | Family | Library | Settings |
|---|---|---|---|
| GaussianCopula | Statistical | SDV `GaussianCopulaSynthesizer` | defaults |
| CopulaGAN | GAN + copula | SDV `CopulaGANSynthesizer` | epochs = 300 |
| CTGAN | GAN | SDV `CTGANSynthesizer` | epochs = 300, cuda = True |
| TVAE | VAE | SDV `TVAESynthesizer` | epochs = 300, cuda = True |
| TabDDPM | Diffusion | synthcity plugin `ddpm` (or official TabDDPM repo) | n_iter as recommended by the implementation; log the value |

Notes:
- SDV synthesizers have no seed argument. Before each fit and sample call, set `random.seed`, `numpy.random.seed`, and `torch.manual_seed` (and CUDA seeds) to the generator seed.
- Pass explicit SDV metadata (column types) built from `meta.yaml`.
- Post-processing: clip to valid ranges, round integer columns, enforce categorical domains. Log how many values were changed.
- Log the class ratio of each synthetic dataset next to the real ratio. Do not rebalance in the main analysis (an organization would use the data as generated).
- Save every synthetic dataset to disk (`parquet`) with generator name, seed, and fit time.
- Optional extension if time allows: one DP generator (AIM or DP-CTGAN) at epsilon 1 and 10.

---

## 6. Downstream models

### 6.1 XGBoost (main model)
- `XGBClassifier`, objective `binary:logistic`, `tree_method = "hist"`, `subsample = 0.8`, `colsample_bytree = 0.8`.
- Tuning: once per dataset on real Train, scored by AUC on Validation. Small grid:
  - `max_depth` in {3, 4, 6}
  - `learning_rate` in {0.05, 0.1}
  - `n_estimators` in {200, 400}
- Freeze the best setting and use it for **every** model in every condition. Only the training data and seed change.
- Categorical columns (Taiwan `EDUCATION`) stay as integer codes. No one-hot encoding, so SHAP stays at the original feature level.

### 6.2 Logistic regression (robustness)
- Pipeline: median imputation, one-hot for categoricals, standard scaling, `LogisticRegression` (L2).
- Tune `C` in {0.01, 0.1, 1, 10} on Validation, then freeze.
- SHAP: exact linear SHAP. Sum one-hot components back to the original feature.

### 6.3 Decision rule
- Adverse decision if predicted probability of y = 1 is at least 0.5. CONFIGURABLE.
- Robustness: a quantile-matched threshold per model, so each model rejects the same share of the audit set as the mean R model.

---

## 7. Explanations

### 7.1 SHAP reason codes
- Explainer: `shap.TreeExplainer(model, data=background, feature_perturbation="interventional")`, output in log-odds.
- **Background:** 200 rows sampled once from real Train (seed 42). **The same background is used for every model.** This keeps explanations comparable across models and removes explainer randomness (interventional TreeSHAP is exact and deterministic).
- Compute SHAP for all audit rows under all models. Save as arrays shaped (n_models, n_audit, n_features) in `.npy` or `zarr`.
- If too slow: fall back to XGBoost native `pred_contribs=True` (path-dependent TreeSHAP, GPU-capable) and document the choice.

**Reason codes for person i under model m** (only if m predicts adverse for i):
- Sort features by SHAP value, descending. Positive values push toward the adverse outcome.
- Take the top k features with SHAP greater than 0. Main k = 3. Robustness k = 1 and k = 4.
- If fewer than k features have positive SHAP, take those available and log it.
- Taiwan: `SEX` and `MARRIAGE` are not model inputs, so they cannot appear as reasons.

### 7.2 Recourse (counterfactuals)
- Library: `dice-ml`, model-agnostic method (`random` or `genetic`), 1 counterfactual per person (robustness: 3).
- Run on a sample of adverse audit individuals: 300 per dataset, stratified by predicted probability decile. CONFIGURABLE.
- Constraints come from `meta.yaml`. Starting proposal (to be confirmed by a human):

**HELOC**
- Immutable: `ExternalRiskEstimate`, `MSinceOldestTradeOpen`, `MaxDelq2PublicRecLast12M`, `MaxDelqEver`, `NumTrades60Ever2DerogPubRec`, `NumTrades90Ever2DerogPubRec`, `NumTotalTrades`, `PercentTradesNeverDelq`.
- Free or decrease_only: `NetFractionRevolvingBurden`, `NetFractionInstallBurden`, `NumRevolvingTradesWBalance`, `NumInstallTradesWBalance`, `NumBank2NatlTradesWHighUtilization`, `PercentTradesWBalance`, `NumInqLast6M`, `NumInqLast6Mexcl7days`.
- Increase_only: `MSinceMostRecentInqexcl7days`, `MSinceMostRecentTradeOpen`, `AverageMInFile`.

**Taiwan**
- Immutable: `AGE`, `EDUCATION`, `LIMIT_BAL` (set by the bank), `PAY_0` and `PAY_2` to `PAY_6` (past repayment status).
- Decrease_only: `BILL_AMT1` to `BILL_AMT6`.
- Increase_only: `PAY_AMT1` to `PAY_AMT6`.

**Recourse transfer test**
- Generate a counterfactual x' from source model a, so that a no longer predicts adverse.
- Apply x' to target model b. **Valid** if b also predicts non-adverse.
- Pairs:
  - R to R (baseline): source R_j, target R_l with l not equal to j.
  - B to R.
  - S_g to R (treatment).
- Log DiCE failures (no counterfactual found) separately. They are a result, not an error.

---

## 8. Metrics

### 8.1 Standard quality checks (what practice uses today)
Per generator and generator seed:
- **TSTR AUC gap:** mean audit AUC of R models minus mean audit AUC of S_g models with that generator seed.
- **Accuracy and F1** on audit, for completeness.
- **SDMetrics QualityReport overall score** (real Train vs synthetic).
- **Detection AUC:** XGBoost classifier trained to separate real Train from synthetic, evaluated on a held-out 30% split. Higher means more detectable.
- **Global SHAP distance:** cosine distance between the mean absolute SHAP vector of the R models (averaged) and that of the S_g models (averaged), computed on the audit set.
- **XAI faithfulness (OpenXAI-style PGI):** for each model and adverse person, replace the top-k reason features with background means and measure the drop in predicted probability. Report the mean per model. This checks that synthetic-trained explanations are faithful to their own model.

### 8.2 Individual-level explanation metrics (our contribution)
For a model pair (a, b) and person i, **only if both a and b predict adverse for i**:
- **Overlap O_ab(i)** = number of shared reasons, from 0 to k. Interpretable: "how many of the 3 reasons match".
- **Jaccard J_ab(i)** = |R_a intersect R_b| / |R_a union R_b|. Main metric.
- **Top-1 match M_ab(i)** = 1 if the main reason is the same.
- **RBO_ab(i)** over the full SHAP ranking, p = 0.9 (robustness, order-aware).

Per person i, average over valid pairs:
- **A_RR(i):** over all R-R pairs (45 pairs).
- **A_BR(i):** over all B-R pairs (100 pairs).
- **A_SR,g(i):** over all S_g-R pairs (90 pairs per generator).

Require at least 5 valid pairs; otherwise set to NaN and log the count.

**Explanation displacement for generator g:**
- **D_g(i) = A_BR(i) - A_SR,g(i)** (main, conservative baseline)
- **D_seed,g(i) = A_RR(i) - A_SR,g(i)** (reported alongside)

**Displaced individual:**
- Bootstrap over model pairs (1,000 resamples) for the difference in mean Jaccard.
- Displaced if the 95% CI lower bound is above 0 **and** the mean overlap drops by at least 0.5 reasons (out of 3).
- Report the **displaced share** per dataset and generator, with Benjamini-Hochberg correction across individuals as a robustness check.

### 8.3 Decision-level metric (kept separate)
- **Decision flip rate:** share of audit individuals where a and b disagree on the decision, averaged per condition pair type (R-R, B-R, S_g-R).

### 8.4 Recourse metrics
- **V_RR, V_BR, V_SR,g:** share of valid transferred counterfactuals.
- **Recourse displacement:** V_BR minus V_SR,g (main), V_RR minus V_SR,g (alongside).
- **Cost gap:** L1 distance of the change (on standardized features) and number of changed features, compared between source types.

---

## 9. Analyses

### 9.1 RQ1 / H1
- Table: per dataset and generator, mean A_RR, A_BR, A_SR, mean D, displaced share, decision flip rate, recourse validity.
- Mixed-effects model on pair-level Jaccard:
  `jaccard ~ pair_type + (1 | person) + (1 | model_a) + (1 | model_b)`
  with pair_type in {RR, BR, SR_g}. Use `statsmodels` MixedLM, or `pymer4` / R `lme4` if crossed effects are needed.
- Report effect sizes with confidence intervals, not only p-values.

### 9.2 RQ2 / H2
- Unit: dataset by generator by generator seed (2 x 5 x 3 = 30 points).
- Spearman correlation between displaced share and each standard check: TSTR AUC gap, global SHAP distance, SDMetrics score, detection AUC, mean PGI.
- **Main figure:** displaced share (y) vs TSTR AUC gap (x), colored by generator, shaped by dataset.
- **Hidden failures:** count conditions with TSTR AUC gap below 0.02 that still have a displaced share above 10%. CONFIGURABLE thresholds.

### 9.3 RQ3 / H3
Person-level predictors of D_g(i):
- **Boundary proximity:** |mean R predicted probability - 0.5|.
- **Rarity:** mean distance to the 10 nearest neighbors in real Train (standardized features).
- **Coverage by generator:** detection-model probability that person i is real (high = region underrepresented in synthetic data), following Kapar et al.
- **Subgroups:**
  - Taiwan: `SEX`, `AGE` bins (under 30, 30 to 45, over 45), `EDUCATION`.
  - HELOC: thin-file (low `NumTotalTrades`, bottom quartile) vs others, `ExternalRiskEstimate` quartiles.
- Model: OLS of D_g(i) on predictors with generator fixed effects and robust standard errors, plus Spearman correlations and binned plots.
- Subgroup gaps in displaced share with bootstrap CIs.

### 9.4 Robustness checks (appendix)
- k = 1 and k = 4.
- Logistic regression instead of XGBoost.
- Quantile-matched threshold.
- RBO instead of Jaccard.
- Seed baseline (D_seed) instead of bootstrap baseline.
- Optional: extra split seeds 43 and 44.

---

## 10. Sanity checks (stop and report if any fails)

1. R models reach a typical AUC for each dataset (roughly 0.78 to 0.80 for XGBoost on both). Large deviations suggest a bug.
2. R models are not identical. Check that A_RR is below 1 for a meaningful share of people. If A_RR is 1 everywhere, seeds are not affecting training (check subsample and colsample).
3. Every synthetic dataset has the same columns, dtypes, and valid ranges as real Train.
4. No audit row appears in any training or generator input (hash check).
5. SHAP additivity holds: SHAP sum plus expected value equals model log-odds output within 1e-4 for a random sample.
6. Reason codes never include features that are not model inputs.
7. DiCE counterfactuals respect immutability constraints (assert on every counterfactual).

---

## 11. Repository layout

```
synth-xai/
  config.yaml                 # all settings, seeds, thresholds
  data/
    raw/                      # original files (not committed)
    heloc/meta.yaml
    taiwan/meta.yaml
    README.md                 # sources and licenses
  src/
    data.py                   # load, clean, split, preprocessing
    generators.py             # fit and sample all generators
    models.py                 # tuning, training R, B, S models
    explain.py                # SHAP, reason codes
    recourse.py               # DiCE and transfer tests
    metrics.py                # agreement, displacement, quality checks
    analysis.py               # RQ1 to RQ3 stats, tables
    plots.py                  # figures
    sanity.py                 # checks from Section 10
  scripts/
    01_prepare_data.py
    02_generate.py            # GPU stage
    03_train_models.py
    04_explain.py
    05_recourse.py
    06_quality_checks.py
    07_analysis.py
    08_figures.py
  outputs/
    synthetic/<dataset>/<generator>/seed<k>.parquet
    models/<dataset>/<condition>/<id>.json
    shap/<dataset>/<model_id>.npy
    reasons/<dataset>.parquet       # long format: person, model, rank, feature
    pairs/<dataset>.parquet         # pair-level agreement
    person/<dataset>.parquet        # A_RR, A_BR, A_SR, D, flags, predictors
    recourse/<dataset>.parquet
    quality/<dataset>.parquet
    tables/  figures/  logs/
```

Rules:
- Every stage reads from disk and writes to disk, so stages can rerun independently.
- Cache: skip a step if its output exists, unless `--force`.
- Every output records dataset, condition, generator, generator seed, model seed, and code version (git hash).
- Log library versions (`pip freeze`) at the start of every run.

---

## 12. Compute plan

- **GPU needed only for stage 02** (CTGAN, TVAE, CopulaGAN, TabDDPM). One mid-range GPU (for example an L4, A10, or A100) is enough.
- Generator runs: 5 generators x 3 seeds x 2 datasets = 30 fits. Expect a few GPU hours in total. Log fit time per run.
- Stages 03 to 07 run on CPU. SHAP on about 2,000 (HELOC) and 6,000 (Taiwan) audit rows for 65 models each is fine on a multi-core machine. Parallelize over models with `joblib`.
- DiCE is the slowest CPU step. Parallelize per person and cap time per counterfactual. CONFIGURABLE.
- Run order on the rented machine: 01, 02 (GPU), then download the synthetic data and run 03 to 08 anywhere.

---

## 13. Deliverables for the paper

**Tables**
1. Datasets, generators, and setup.
2. Main results per dataset and generator: TSTR AUC gap, SDMetrics score, detection AUC, global SHAP distance, PGI, A_RR, A_BR, A_SR, displaced share, decision flip rate, recourse validity.
3. H3 regression results.
4. Appendix: robustness checks.

**Figures**
1. Research design diagram (manual).
2. Displaced share vs TSTR AUC gap (H2 money plot).
3. Distribution of D_g(i) per generator, with the R and B baselines.
4. Displacement by rarity, boundary proximity, and subgroup (H3).
5. One worked example: the same rejected applicant, reasons under a real model vs a synthetic model.

---

## 14. Timeline (fits the 30 October deadline)

| Day | Work |
|---|---|
| 1 | Stage 01, meta.yaml, sanity checks on real models |
| 2 | Stage 02 on GPU (all generators, both datasets) |
| 3 | Stages 03 and 04 (models, SHAP, reason codes) |
| 4 | Stages 05 and 06 (recourse, quality checks) |
| 5 | Stage 07 and 08 (analysis, figures) |
| 6 | Review results. Decide completed paper vs short paper. |
| 7 to 15 | Writing |
| 16 to 18 | Feedback, polish, submit |

---

## 15. Open decisions for a human to confirm

1. HELOC source and license.
2. Recourse feature constraints in Section 7.2.
3. Missing-value handling for HELOC special values.
4. Displacement thresholds (0.5 reasons, 10% hidden-failure threshold).
5. Whether to add the DP generator extension.

---

## 16. Amendments adopted after design review (15 October 2026)

These override earlier sections where they conflict. All are in `config.yaml`.

**16.1 Missing values (replaces 2.1 handling).** One representation everywhere. Special values -7, -8, -9 become NaN, then every model and every generator receives the same table: train-median imputation plus one binary `<feature>_na` indicator per affected feature. The feature space is identical across conditions, which is a precondition for comparing SHAP across models. For reason codes, the indicator's SHAP is added to its parent feature before ranking (`reasons.merge_missing_indicators: true`), so reasons stay at the original feature level. Indicators are immutable for recourse.

**16.2 Decision rule (replaces 6.3 main/robustness order).** Main rule is the quantile-matched threshold: each model rejects the same share of the audit set as the mean R model does at 0.5. Fixed 0.5 is the robustness rule. Reason: generators shift the class ratio, and under a fixed threshold decision flips and the count of valid pairs would be driven by calibration shift rather than by changed reasoning.

**16.3 Displaced-individual test (replaces 8.2 bootstrap).** Bootstrap resamples **models**, not pairs. Each iteration draws the 10 R, 10 B and 9 S_g models with replacement, rebuilds the B-R and S-R pairs, and recomputes the mean Jaccard difference. Pairs that share a model are correlated, so resampling pairs understates variance. The R draw is shared between the B-R and S-R sides within an iteration.

**16.4 Recourse (amends 7.2).** DiCE method is `random` (model-agnostic sampling with post-hoc sparsity). The `genetic` method was tried first and found counterfactuals for under 20% of applicants under the directional constraints, versus about 100% for `random`; `genetic` remains available in `config.yaml`. The random method is seeded with the applicant id, so results are reproducible. A counterfactual is accepted from the source model only if the source's predicted adverse probability falls to at most 0.8 times that model's own decision threshold (`recourse.margin_ratio`; equals 0.4 under a 0.5 threshold). The margin is relative to each model's threshold because, under the quantile rule (16.2), thresholds range from about 0.2 to 0.7 across synthetic-trained models; a fixed absolute margin was found in review to accept counterfactuals that never flipped low-threshold sources and to penalise high-threshold sources. Counterfactuals that do not reach the level are logged as margin failures and not transferred. Directional constraints are implemented as per-person permitted ranges (increase_only: [x_i, max], decrease_only: [min, x_i]). The recourse sample is drawn from individuals adverse under the mean R model, stratified by its probability decile.

**16.5 Feature-family agreement (adds to 8.2).** `meta.yaml` assigns each feature a family (for example the two inquiry counts share one family). Family-level Jaccard is reported as a robustness metric so that swapping near-duplicate features is not counted as displacement.

**16.6 Seed-noise sensitivity (adds to 9.4).** The size of the R baseline depends on `subsample` and `colsample_bytree`. Variants `sub06` (0.6) and `sub10` (1.0) retrain all conditions and recompute D. The logistic-regression robustness is the `lr` variant of the same mechanism.

**16.7 Generator-dependence analyses (adds to 9 and 13).** To separate "the same people are displaced under every generator" from "different generators displace different people":
- Overlap of displaced sets across generators: pairwise Jaccard between the sets of displaced individuals, as a heatmap (new Figure 6, panel a).
- Variance decomposition of D_{g,s}(i), computed per generator seed: shares of variance attributable to person, generator, person-by-generator interaction, and seed residual (new Table 5). The interaction share is the quantity that says "who is displaced depends on the generator".
- Pairwise contrasts between SR_g levels in the mixed model, with confidence intervals (Table 5).
- Within-generator stability: variance of D across seeds of one generator versus across generators.
- H3 regressions with generator interactions, and per-generator rarity and boundary slopes (Figure 6, panel b).

**16.8 Mixed model (amends 9.1).** The main mixed model is fit on person-by-pair-type means with a person random intercept (`statsmodels` MixedLM). Model-level random effects are handled by the model bootstrap in 16.3. A full crossed model on the pair-level table is provided as an optional R `lme4` script.

**16.10 Generator metadata for ordinal codes.** Features typed `ordinal` in `meta.yaml` (HELOC `MaxDelqEver`, `MaxDelq2PublicRecLast12M`; Taiwan `PAY_0`..`PAY_6`) are passed to every generator as categorical, not numerical. With numerical marginals the GaussianCopula placed 19% of rows on a `MaxDelq2PublicRecLast12M` code that never occurs in real data, and the detection classifier reached AUC 0.999 on that alone. The choice applies to all generators. For TabDDPM (synthcity), whose categorical rule is hard-coded as at most 10 unique values, the pipeline raises that limit to cover every declared categorical/ordinal column, remaps them to contiguous codes (synthcity crashes on negative codes such as Taiwan `PAY_*` = -2) and maps back after sampling; the fit log records the columns and the limit used.

**16.11 Rebalanced variant (prevalence control).** Generators shift the class ratio (on Taiwan, CTGAN seeds range from 28% to 44% defaults against 22% real). To show that displacement is not only a prevalence effect, variant `rebal` trains the synthetic-trained models on each synthetic set resampled to the real class ratio at n_train rows (without replacement within a class where possible; the share of duplicated rows is logged). Everything else is identical to `main`. RQ2 additionally reports the Spearman correlation between displaced share and the absolute class-ratio gap.

**16.12 TabDDPM training budget.** synthcity's default of 1,000 iterations (batch 1,024) produced collapsed output on HELOC: after clipping to valid ranges, 75% of rows carried the minimum `ExternalRiskEstimate`, mean KS distance to real was 0.42, and 937 of 5,922 rows were duplicates, while the same setting was the most faithful generator on Taiwan (KS 0.045). At 10,000 iterations HELOC reached KS 0.073 with 101 duplicates. Both datasets use 10,000 iterations; the 1,000-iteration sets are kept under `outputs/synthetic_tabddpm_1k/` for reference and are not used.

**16.9 Variants.** A variant is a model family plus a subsample setting: `main` (XGBoost, 0.8), `rebal` (16.11), `sub06`, `sub10`, `lr`. Every stage from 03 onward takes `--variant`. Metric-level robustness (k = 1, 3, 4; both threshold rules; RBO; family Jaccard) is computed in one pass for every variant.

**16.13 Corrections after the independent code review of 2 November 2026.** (a) Recourse: the source model is wrapped by a monotone rescaling that maps its own decision threshold to 0.5 before it is handed to DiCE, because DiCE (dice-ml 0.12, random explainer) clamps any stopping threshold above 0.5 to 0.25; this had affected 12 HELOC and 3 Taiwan synthetic-trained source models. The acceptance check on the raw probability (16.4) is unchanged. DiCE is told that every input is integer-valued (precision 0), so it validates exactly the row that is scored; the sparse counterfactual DiCE returns is used, as 16.4 states; a feature whose missing indicator is 1 is held fixed; `meta.yaml` may give `recourse_min`/`recourse_max`, used only to bound the permitted range (Taiwan bill amounts: 0). The summary reports validity among found and strict validity (failures counted as invalid). (b) SHAP: the 200-row background is passed as an explicit `shap.maskers.Independent(..., max_samples=200)`; the library default had silently used 100 of the rows (identically for every model). (c) Generator seeds: `generators.seed_overrides` lists the seeds used per dataset and generator; a run that fails the collapse gate in `verify_synthetic.py` (more than 5% exact duplicate rows, or a numeric feature with fewer than 3 levels) is discarded before any downstream stage and replaced by the next seed; Taiwan TabDDPM uses seeds 1, 2, 3. (d) Analysis: the overlap of displaced sets is restricted to applicants testable under both generators; the variance decomposition reports the seed main effect within generator separately from the remainder of the residual; the family-level displaced share (16.5) is no longer reported, correlated features are addressed with k = 1, k = 4 and rank-biased overlap. (e) Stage 09 (`scripts/09_review_quantities.py`) produces every remaining quantity the paper cites: generator-level mean displacement with model-bootstrap intervals, generator-level correlations, validity intervals and validity at margin ratios 0.7/0.8/0.9, the sensitivity of the displaced share to the criterion, the minimum number of pairs and k, hidden-failure counts under alternative gates, the worked example by a stated rule, and the validity and overlap figures. (f) All stages from 03 onward are recomputed on one machine (`scripts/run_recompute.sh`), with the environment recorded in `outputs/logs/pip_freeze_recompute.txt`.

**16.14 Corrections after the second independent review of 3 November 2026.** (a) Recourse search: DiCE's random method draws candidate values uniformly over the permitted range and returns a random valid candidate; without a plausibility bound this produced counterfactuals far outside the data (Taiwan payment amounts of several hundred thousand). The permitted range of every feature is now also bounded by the 1st and 99th percentiles of the training distribution (`recourse.plausible_quantiles`), intersected with the directional constraints of 16.4 and the `recourse_min`/`recourse_max` bounds of 16.13; DiCE returns one valid candidate (`recourse.total_cfs: 1`), as before. A closest-of-10 selection (DiCE asked for up to 10 valid candidates, the one closest to the applicant in standardised L1 distance kept) was specified at 14:00 on 3 November and withdrawn at 16:40 the same day before any result was used: it multiplied the search time on the Taiwan data by about fifteen (DiCE keeps widening the number of features it varies until ten valid candidates exist), which did not fit the compute budget. The code path remains and is exercised when `total_cfs` > 1; with `total_cfs: 1` it selects the single candidate. `n_candidates`, `n_candidates_ok` and `l1_std_chosen` are recorded either way. The acceptance rule (16.4) and the transfer test (7.2) are unchanged. (b) Displaced test: statistics are kept for every person with at least one valid pair on each side (testability is still the >= 5 rule), so the minimum-pairs sensitivity in stage 09 re-derives the flag from the same bootstrap; "interval lower bound above zero" is evaluated with a tolerance of 1e-9 against floating-point noise. (c) Stage 09: generator-level correlations use the generator-level displaced share of Table 2 (nine-model test); validity intervals come from a two-way cluster bootstrap over persons and source models; validity at margin ratios is reported for 0.7 and 0.8 only, since a ratio looser than the search target cannot be assessed by rescoring; a permutation null for agreement (an applicant's reasons under one real model against another rejected applicant's reasons under a second real model) is reported next to the uniform null. (d) Tuning: the tree configuration is chosen once per dataset on the main variant and reused by every tree variant (`get_tuned`); the logistic variant selects its own regularisation. (e) The environment record is written with importlib.metadata (uv environments have no pip). (f) XGBoost's histogram method is deterministic on one machine but not bit-for-bit across platforms (the cross-platform difference in predicted probabilities is of the same order as one model-seed change); this is a further reason all stages from training onward run on one machine.
