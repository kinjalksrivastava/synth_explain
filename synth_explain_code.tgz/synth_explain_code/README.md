# Same Decision, Different Reason: explanation displacement in credit models trained on synthetic data

Code for the FAccT 2027 submission. The design is in [EXPERIMENT_SPEC.md](EXPERIMENT_SPEC.md); Section 16 lists the
decisions adopted after review. `config.yaml` holds every setting, seed and threshold.

## What the pipeline does

1. **Data** (`01`): downloads HELOC and the Taiwan credit-card data, cleans them, makes one stratified 60/20/20
   split (train / validation / audit) with seed 42, imputes train medians and adds `<feature>_na` indicators.
2. **Generators** (`02`, GPU): fits GaussianCopula, CopulaGAN, CTGAN, TVAE (SDV) and TabDDPM (synthcity) on
   train (features + label), 3 seeds each, samples n_train rows, post-processes, logs class ratios and fit times.
3. **Models** (`03`): tunes XGBoost once on real data, freezes the setting, then trains 10 real-seed models (R),
   10 bootstrap models (B) and 9 models per generator (S, 3 generator seeds x 3 model seeds).
4. **Explanations** (`04`): interventional TreeSHAP with one shared 200-row real background for every model;
   quantile-matched and fixed-0.5 decisions; top-3 reason codes for rejected applicants.
5. **Recourse** (`05`): DiCE counterfactuals from every model for 300 rejected applicants, under immutability and
   directional constraints, then transferred to the real models to test whether the advice still works.
6. **Metrics** (`06`): per-person agreement between model pairs (Jaccard, overlap, top-1, RBO, family Jaccard),
   the bootstrap baseline, displacement D_g(i), the displaced-individual test (bootstrap over models), decision
   flips, and the standard quality checks (TSTR gap, SDMetrics, detection AUC, global SHAP distance, PGI).
7. **Analysis** (`07`): RQ1 table and mixed model, RQ2 correlations and hidden failures, RQ3 regressions and
   subgroups, generator-dependence analyses (overlap of displaced sets, variance decomposition, contrasts).
8. **Figures** (`08`): the figures in the paper.

## Setup

```bash
python3.11 -m venv .venv && .venv/bin/pip install -r requirements.txt
# TabDDPM needs synthcity, whose pins conflict with SDV: give it its own environment
python3.11 -m venv .venv-ddpm && .venv-ddpm/bin/pip install -r requirements-tabddpm.txt
```

On the GPU machine install a CUDA build of torch into both environments before the requirements.
Pinned on purpose: `xgboost<3` (shap 0.49 cannot read XGBoost 3 model files), `scikit-learn<1.7`
(the XGBoost 2 sklearn wrapper needs an attribute removed in sklearn 1.8), `pyarrow<20` (needs numpy 2).

## Running

```bash
scripts/run_all.sh                      # full pipeline, variant "main"
VARIANT=sub06 scripts/run_all.sh        # seed-noise sensitivity (subsample 0.6); also sub10, lr
.venv/bin/python scripts/02_generate.py --dataset heloc --generators ctgan --seeds 0   # any stage alone
```

Every stage caches its outputs and skips work unless `--force` is given. Stage 02 is the only GPU stage; run
01 and 02 on the rented machine, copy `outputs/synthetic/`, and run the rest anywhere. Stages 05 and 06 both
depend only on 04 and can run in parallel. Recourse is the slowest CPU stage; it is parallelised with joblib.

Smoke test (CPU, a few minutes, two generators at 3 epochs, 16 models, writes to `outputs_smoke/`):

```bash
for s in 01_prepare_data 02_generate 03_train_models 04_explain 06_quality_checks 05_recourse 07_analysis 08_figures; do
  .venv/bin/python scripts/$s.py --config smoke/config_smoke.yaml; done
```

## Outputs

| Path | Content |
|---|---|
| `data/<ds>/{train,validation,audit}.parquet`, `columns.json` | processed splits, input/aux/target columns, valid ranges |
| `outputs/synthetic/<ds>/<gen>/seed<k>.{parquet,json}` | synthetic data and fit log (time, class ratio, values post-processed) |
| `outputs/models/<ds>/<variant>/<model_id>.json` + `registry_<variant>.parquet` | models and their condition / seeds |
| `outputs/shap/<ds>/<variant>/explanations.npz`, `thresholds.json` | SHAP (models x audit x features), probabilities, thresholds |
| `outputs/reasons/<ds>_<variant>.parquet` | long-format top-k reason codes |
| `outputs/pairs/<ds>_<variant>_<rule>.parquet` | pair-level agreement for every (model a, model b, person) both reject |
| `outputs/person/<ds>_<variant>_<rule>.parquet` | A_RR, A_BR, A_SR_g, D_g, D_seed_g per person and metric |
| `outputs/metrics/<ds>/<variant>/displaced_<rule>_{BR,RR}.parquet` | displaced test per person and generator |
| `outputs/metrics/<ds>/<variant>/quality.parquet`, `coverage.parquet` | standard checks per generator seed; P(real) per audit person |
| `outputs/recourse/<ds>/<variant>/` | counterfactuals, transfer results, summary (V_RR, V_BR, V_SR_g) |
| `outputs/tables/<variant>/` | Table 2 (`table2_main_*`), mixed model, contrasts, RQ2 points and Spearman, Table 3 (H3), subgroups, Table 5 (overlap, variance decomposition), worked example |
| `outputs/figures/<variant>/` | fig2 money plot, fig3 distributions, fig4 H3, fig5 worked example, fig6 generator dependence |
| `outputs/logs/` | per-stage logs and `pip freeze` |

Model ids: `R_m<seed>`, `B_b<resample>_m<seed>`, `S_<generator>_g<genseed>_m<seed>`.

## Decisions that move the numbers (read before interpreting results)

- **Bootstrap baseline (B-R) is the main reference.** Bootstrap models see about 63% unique rows, so this
  baseline is wider than the seed baseline and D is conservative. D_seed is reported alongside.
- **Quantile-matched threshold is the main rule.** Generators shift the class ratio; under a fixed 0.5 threshold,
  decision flips and the set of valid pairs would be driven by calibration shift. Fixed 0.5 is the robustness rule.
- **Subsample 0.8 sets the size of the seed baseline.** Variants `sub06` and `sub10` show the sensitivity.
- **Both models must reject a person for a pair to count.** People near the boundary lose pairs and can drop to
  NaN; `n_valid_*` columns and the `testable` flag make this visible. Report it.
- **One shared real background for SHAP**, not each model's own training data. Needed for comparability.
- **Impute + indicator everywhere**, and synthetic rows are forced to keep the indicator/value relation
  (`_indicator_consistency` in the fit log), otherwise a detector separates real from synthetic trivially.
- **DiCE `random`, not `genetic`.** Genetic found counterfactuals for under 20% of applicants under the
  directional constraints; random finds nearly all. Counterfactuals must bring the source model to at most 0.4.
- **Displaced test bootstraps models, not pairs**, because pairs sharing a model are correlated.
- **Detection AUC saturates near 1.0 on HELOC** for every generator, because real HELOC rows obey deterministic
  relations (for example the two inquiry counts) that generators do not reproduce. It then carries no ranking
  information across generators; this is a result, not a bug.

## Things a human still has to confirm (Spec 15)

HELOC license acceptance on FICO's site (the loader uses a public mirror of the same file); the recourse
constraints marked `review: true` in `data/heloc/meta.yaml`; the displacement thresholds in `config.yaml`
(`displaced_min_overlap_drop`, `rq2.*`); whether to add a DP generator.

## Not yet exercised locally

TabDDPM through synthcity has not been run here (no synthcity environment on this machine). The code path is
written; run `scripts/02_generate.py --generators tabddpm` from `.venv-ddpm` on the GPU box and check the
schema sanity check passes. Everything else has been run end to end on the smoke configuration for both
datasets and for the `lr` variant.
